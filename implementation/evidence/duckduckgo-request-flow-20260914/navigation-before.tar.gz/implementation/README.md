# Implementation overview

Start here. Historical handoffs are stored as evidence; the work queue is in [tasks/README.md](../tasks/README.md). This overview was reconciled on 13 September 2026 and does not resume paused implementation or duration testing.

## What still needs doing

| Work | Current status | Start here |
|---|---|---|
| Artifact and change-review closeout | Remaining: reconcile current coverage, finish actual presentation gaps, and verify non-file outputs, large diffs, focus/drafts and Undo/recovery. Much of the implementation already exists. | [Task 1](../tasks/01-ARTIFACT-REVIEW.md) |
| Combined chat presentation cleanup | Remaining: review nesting, result/error clarity, accessibility, preserved drafts and history behavior across existing cards and panels. | [Task 3](../tasks/03-CHAT-CLEANUP.md) |
| Combined feature verification | Remaining after the above work. The completed nine-scenario harness exercise covers a narrower scope and does not close this task. | [Task 4](../tasks/04-FINAL-VERIFICATION.md) |
| Broader P14 release | Separate, paused backlog: reconcile remaining model comparisons/quality, packaged performance, other platforms, signing and release gates. Duration work requires a separately resumed scope; no eight-hour run is authorized by these documents. | [Release phase](../phases/P14-release-and-long-horizon-gates.md), [historical custody record](evidence/implementation-records/phases/P14-RESUME-HANDOFF.md) |

No pending overnight-fix implementation is established by the old handoffs. Read newer completion evidence before treating an old checklist as outstanding work. Old candidate paths and runtime observations must be reconciled with the current machine before reuse.

## Latest completed work

- **DuckDuckGo integration repair:** [implementation and checks](evidence/duckduckgo-fix-20260914/REPORT.md). Installed; 302 automated checks passed. HTML/lite parsing, blocked-search errors, cooldown, explicit queries and suggestion/source separation repaired. Live DuckDuckGo still requires human verification; improved live result quality is unproven. No alternate engine added.

- **Bounded 35B / OpenCode comparison:** [results and screenshots](evidence/bounded-comparison-20260913/REPORT.md). Sequential short runs; AG1 16/18 vs OpenCode 17/18 held-out repair checks, neither fully correct. Favicons and thinking placement worked; research exposed weak extraction and failed-fetch classification. Production unchanged.

- **Thinking placement and website icons:** [implementation and verification report](evidence/chat-activity-20260913/REPORT.md). Source/build complete; 561 final automated checks and two bounded 35B visual exercises. Production package installed systemwide; all 1,144 installed payload files verified. Empty live search responses remain an identified limitation.

- **Fixed harness scenarios:** [validation report](evidence/scenario-validation-20260913/REPORT.md). All nine scenarios passed within stated new/retained coverage; 295 final targeted checks, live cap-7/cap-5 repairs, task/evidence retrieval, and isolated native MCP UI. No new regression or production change; no screenshots or duration run. Cross-model/endurance and native WebKit history performance remain outside that coverage.
- **Overnight harness fixes:** [final implementation record](evidence/implementation-records/overnight/HANDOFF-OVERNIGHT-FINAL-FIXES-20260913.md). Completion/recovery, verifier guidance, work actions, request preparation, retained custody and related fixes were delivered. The scenario test handoff is completed, not a new assignment.
- **MCP:** [core acceptance and limits](evidence/implementation-records/mcp/MCP-INTEGRATION-ACCEPTANCE.md), followed by [Discover loading repair](evidence/implementation-records/mcp/MCP-DISCOVER-LOADING-20260913.md). Core phases A–F are complete; optional compatibility limits remain documented.
- **GitHub and desktop:** [GitHub workflow improvements](evidence/implementation-records/github/GITHUB-IMPROVEMENTS-20260913.md), [capability ledger](evidence/implementation-records/github/P14-GITHUB-CAPABILITIES.md), and [display refresh repair](evidence/implementation-records/desktop/DISPLAY-REFRESH-20260913.md). Earlier interface and UI changes are indexed with their evidence.
- **Storage cleanup:** [cleanup report](evidence/storage-cleanup-20260913/REPORT.md). Historical references can point to retired packages; check availability rather than recreating them automatically.

Latest verified installed release: `/opt/ag1/releases/7bb6bc55e5cc4d06a5c3e554e19f1b54`; see the DuckDuckGo repair report. Resolve `/opt/ag1/current` before a future build-dependent claim. Documentation reorganization did not rebuild, install or restart AG1.

## Finding evidence

- [Evidence index](evidence/README.md): current reports and historical evidence families.
- [Archived implementation records](evidence/implementation-records/README.md): all 76 former top-level Markdown files, grouped by topic and marked historical.
- [Relocation manifest](evidence/implementation-records/manifest.json): old paths, original hashes and new locations. Original documents are also preserved in its linked recovery archive. Existing historical receipts were not rewritten.

`P12-HANDOFF.md` and `P13-HANDOFF.md` remain here only as compatibility symlinks. Release tools and accepted manifests depend on their original paths and exact bytes. Read their indexed archival copies for historical context; neither is a current work assignment.
