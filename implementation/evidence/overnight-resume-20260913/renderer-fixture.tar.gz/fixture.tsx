import React from 'react';
import {createRoot} from 'react-dom/client';
import {flushSync} from 'react-dom';
import {NativeConversation} from '../../product/apps/desktop/src/NativeConversation';
import '../../product/apps/desktop/src/app.css';
import '../../product/apps/desktop/src/redesign.css';
const root=createRoot(document.getElementById('root')!);
document.head.insertAdjacentHTML('beforeend','<style>html,body,#root{height:100%;margin:0}body{--chat-font-size:15px;--chat-font:system-ui;--chat-line-height:1.7}</style>');
let turns=0, generation=0, messages:any[]=[];
function turn(i:number) {return [{id:`u-${i}`,role:'user',blocks:[{kind:'text',text:`Question ${i}: Explain the verifier results.`}]},{id:`a-${i}`,role:'assistant',blocks:[{kind:'thinking',text:`Retained thinking ${i}`},{kind:'text',text:`Response ${i}. The executed verifier passed.\n\n- Preserved **evidence** and state.\n- Check boundaries when needed.\n\n\`exact marker ${i}\``}]}];}
const run=async(command:any)=>{
 if(command.kind==='session'&&command.action==='messages') {const before=command.args.before,start=Math.max(0,before-100);return {messages:Array.from({length:(before-start)/2},(_,i)=>turn(start/2+i)).flat(),next_before:start||null,start,total:turns*2};}
 throw Error('Unexpected bridge call');
};
function render(){const start=performance.now();flushSync(()=>root.render(<NativeConversation key={generation} details={{messages,activity:{}} as any} snapshot={{status:'idle',message_count:turns*2,pending:[]} as any} run={run}/>));return performance.now()-start;}
(window as any).benchmark={window(total:number,visible:number){generation++;turns=total;messages=Array.from({length:visible},(_,i)=>turn(total-visible+i)).flat();return render();},reset(n:number){generation++;turns=n;messages=Array.from({length:n},(_,i)=>turn(i)).flat();return render();},append(n:number){for(let i=0;i<n;i++)messages=[...messages,...turn(turns++)];return render();}};
