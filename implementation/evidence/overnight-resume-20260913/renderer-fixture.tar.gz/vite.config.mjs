import {defineConfig} from '../../product/apps/desktop/node_modules/vite/dist/node/index.js';
import react from '../../product/apps/desktop/node_modules/@vitejs/plugin-react/dist/index.js';
export default defineConfig({root:import.meta.dirname,plugins:[react()],resolve:{dedupe:['react','react-dom']},build:{target:'es2022',outDir:'dist'}});
