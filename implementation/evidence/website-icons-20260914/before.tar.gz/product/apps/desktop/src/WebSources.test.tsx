import { afterEach, expect, test, vi } from "vitest";
import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { SiteIcons, SourceList, webSources } from "./WebSources";
import type { ClientMessage } from "./generated/protocol";
afterEach(cleanup);
const message: ClientMessage = { id: "result", role: "toolResult", tool: { name: "webSearch", call_id: "call", failed: false }, blocks: [{ kind: "unknown", value: { kind: "web_result", sources: [{ url: "https://example.com/a", title: "First page" }, { url: "https://example.com/b", title: "Second page" }, { url: "javascript:alert(1)", title: "Bad" }] } }] };
test("source URLs are validated, icons deduplicate and use only native raster data", async () => {
  const run = vi.fn(async () => ({ dataUrl: "data:image/png;base64,aGVsbG8=" }));
  const sources = webSources(message); expect(sources).toHaveLength(2);
  const { container } = render(<><SiteIcons sources={sources} run={run} /><SourceList sources={sources} run={run} /></>);
  await waitFor(() => expect(container.querySelectorAll('img')).toHaveLength(3));
  expect(run).toHaveBeenCalledTimes(1);
  expect(run).toHaveBeenCalledWith({ kind: "runtime", action: "website_icon", args: { entry: "result", url: "https://example.com/a" } });
  expect(screen.getByRole('link', { name: /First page/ }).getAttribute('href')).toBe('https://example.com/a');
  fireEvent.error(container.querySelector('img')!); expect(container.querySelectorAll('img')).toHaveLength(2);
  expect(webSources({ ...message, tool: { ...message.tool!, failed: true } })).toEqual([]);
});
test("failed or unsafe icon responses leave an offline-friendly fallback", async () => {
  const run = vi.fn(async () => ({ dataUrl: "https://tracker.example/icon.svg" }));
  const { container } = render(<SiteIcons sources={webSources(message)} run={run} />);
  await waitFor(() => expect(run).toHaveBeenCalledTimes(1));
  expect(container.querySelector('img')).toBeNull();expect(screen.getByText('E')).toBeTruthy();
});
