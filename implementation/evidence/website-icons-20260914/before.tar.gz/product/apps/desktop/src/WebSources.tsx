import { useEffect, useRef, useState } from "react";
import { Globe } from "lucide-react";
import type { ClientMessage } from "./generated/protocol";
import type { ImageRun } from "./ImageAttachment";
export type WebSource = { entry: string; url: string; title: string; host: string };
export function webSources(message: ClientMessage): WebSource[] {
  if (message.tool?.failed || !["webSearch", "webFetch"].includes(message.tool?.name ?? "")) return [];
  const block = message.blocks.find(b => b.kind === "unknown" && (b.value as any)?.kind === "web_result");
  const rows = block?.kind === "unknown" ? (block.value as any)?.sources : null;
  if (!Array.isArray(rows)) return [];
  return rows.slice(0, 4).flatMap(row => {
    try {
      const url = new URL(row.url);
      if (!["https:", "http:"].includes(url.protocol) || url.username || url.password) return [];
      return [{ entry: message.id, url: url.href, title: String(row.title || url.hostname).slice(0, 240), host: url.hostname.replace(/^www\./, "") }];
    } catch { return []; }
  });
}
const caches = new WeakMap<ImageRun, Map<string, Promise<string | null>>>();
function load(source: WebSource, run: ImageRun) {
  let cache = caches.get(run); if (!cache) { cache = new Map(); caches.set(run, cache); }
  const key = new URL(source.url).origin;
  let promise = cache.get(key);
  if (!promise) {
    promise = run({ kind: "runtime", action: "website_icon", args: { entry: source.entry, url: source.url } }).then(result => {
      const data = (result as any)?.dataUrl;
      return typeof data === "string" && data.length <= 33000 && /^data:image\/png;base64,[A-Za-z0-9+/=]+$/.test(data) ? data : null;
    }).catch(() => null);
    cache.set(key, promise); if (cache.size > 128) cache.delete(cache.keys().next().value!);
  }
  return promise;
}
function SiteIcon({ source, run }: { source: WebSource; run: ImageRun }) {
  const [image, setImage] = useState<string | null>(null), [failed, setFailed] = useState(false);
  const element = useRef<HTMLSpanElement>(null);
  useEffect(() => {
    let current = true; setImage(null); setFailed(false);
    const show = () => { void load(source, run).then(data => { if (current) setImage(data); }); };
    const observer = typeof IntersectionObserver === "undefined" ? null : new IntersectionObserver(entries => { if (entries.some(e => e.isIntersecting)) { observer?.disconnect(); show(); } });
    if (observer && element.current) observer.observe(element.current); else show();
    return () => { current = false; observer?.disconnect(); };
  }, [source.entry, source.url, run]);
  return <span className="site-icon" ref={element} title={source.host} aria-hidden="true">{image && !failed ? <img src={image} width={16} height={16} alt="" onError={() => setFailed(true)} /> : source.host ? source.host[0].toUpperCase() : <Globe size={14} />}</span>;
}
export function SiteIcons({ sources, run }: { sources: WebSource[]; run: ImageRun }) {
  const unique = sources.filter((s, i) => sources.findIndex(other => other.host === s.host) === i).slice(0, 3);
  return <span className="site-icons" aria-label={unique.map(s => s.host).join(", ")}>{unique.map(source => <SiteIcon key={source.host} source={source} run={run} />)}</span>;
}
export function SourceList({ sources, run }: { sources: WebSource[]; run: ImageRun }) {
  return <div className="web-sources" aria-label="Web sources">{sources.map(source => <a key={source.url} className="web-source" href={source.url} target="_blank" rel="noopener noreferrer"><SiteIcon source={source} run={run} /><span><strong>{source.title}</strong><small>{source.host}</small></span></a>)}</div>;
}
