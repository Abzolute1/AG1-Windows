"""Additional independent transfer/load experiments. Start only after prior queues exit."""
import json,shutil,statistics,subprocess
from bench import ROOT as R,EVID as E,run
from pathlib import Path

# Do not start a build while any inference server is active, including outside
# this experiment. This script is intentionally not an unattended parallel job.
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:name=(p/'exe').resolve(strict=True).name
 except OSError:continue
 assert name not in ['llama-server','llama-bench','nvcc','ninja','cc1plus'],(p.name,name)
def launch(c):
 (R/(c['name']+'.json')).write_text(json.dumps(c,indent=2));return run(c)

subprocess.run(['python',str(R/'turbo-combined-followup.py')],check=True)

# A17-token verification can reuse expert weights across candidates. Test
# whether one5900X CCD's six cores/L3 beat twelve cores spanning both CCDs.
# Decode remains12threads; only the verification/batch pool changes.
for cycle,order in enumerate([[(6,'0-5'),(12,'0-11')],[(12,'0-11'),(6,'0-5')]]):
 for threads,affinity in order:
  launch({'name':f'ngram-ccd-t{threads}-{cycle}',
   'flags':{'--threads-batch':str(threads),'--cpu-range-batch':affinity,
            '--spec-type':'ngram-mod','--spec-ngram-mod-n-max':'16',
            '--spec-ngram-mod-n-min':'2','--spec-ngram-mod-n-match':'24','--verbosity':'4'},
   'workloads':['edit','prose','repetitive'],'repetitions':1,'n_predict':256,'api_smoke':True})

subprocess.run(['python',str(R/'prepare-ngram-rs.py')],check=True)
for cycle,order in enumerate([[(4,0),(4,1),(8,0),(8,1)],[(8,1),(8,0),(4,1),(4,0)]]):
 for depth,enabled in order:
  launch({'name':f'ngram-rs-{depth}-enabled{enabled}-{cycle}',
   'binary':str(R/'bundle-new-ngram-rs/llama-server'),
   'environment':{'AG1_FLASH_NGRAM_RS':str(enabled)},
   'flags':{'--n-cpu-moe':'44','--spec-type':'ngram-mod','--spec-ngram-mod-n-max':str(depth),
            '--spec-ngram-mod-n-min':'2','--spec-ngram-mod-n-match':'24','--verbosity':'4'},
   'workloads':['edit','prose','repetitive'],'repetitions':1,'n_predict':256,'api_smoke':True,
   'state_equivalence':enabled==1 and cycle==0})

subprocess.run(['python',str(R/'prepare-ngram-adaptive.py')],check=True)
for cycle,order in enumerate([['none','fixed16','adaptive16'],['adaptive16','fixed16','none']]):
 for label in order:
  flags={'--threads-batch':'12','--cpu-range-batch':'0-11','--verbosity':'4'}
  if label!='none':flags.update({'--spec-type':'ngram-mod','--spec-ngram-mod-n-max':'16',
                               '--spec-ngram-mod-n-min':'2','--spec-ngram-mod-n-match':'24'})
  launch({'name':f'ngram-adaptive-{label}-{cycle}','binary':str(R/'bundle-new-ngram-adaptive/llama-server'),
   'environment':{'AG1_FLASH_NGRAM_ADAPTIVE':str(int(label=='adaptive16')),'AG1_FLASH_NGRAM_RS':'0'},
   'flags':flags,'workloads':['edit','repetitive','copy_source','copy_repetitive','prose'],
   'prepare_extra':True,'repetitions':1,'n_predict':256,'api_smoke':True})

for script in ['prepare-cow-prefault.py','prepare-bulkcopy.py']:
 subprocess.run(['python',str(R/script)],check=True)

# Same COW weights and driver registration; only prefault worker count changes.
loads={n:[] for n in [0,6,12]}
for cycle,order in enumerate([[0,6,12],[12,0,6],[6,12,0]]):
 for n in order:
  result=launch({'name':f'cow-prefault-{n}-{cycle}','binary':str(R/'bundle-new-cow-prefault/llama-server'),
   'environment':{'AG1_FLASH_REGISTER_COW':'1','AG1_FLASH_COW_PREFAULT_THREADS':str(n)},
   'prewarm_weights':True,'workloads':['prose'],'n_predict':64,'repetitions':1})
  if result['status']=='passed':loads[n].append(result['load_seconds'])
best=min([n for n,v in loads.items() if len(v)==3],key=lambda n:statistics.median(loads[n]))
(E/'cow-prefault-load-comparison.json').write_text(json.dumps({'seconds':loads,'provisional_fastest_workers':best},indent=2))
# Distinguish allocator strategy from unequal starting page-cache warmth. The
# driver may still evict source pages when it allocates a second full host copy.
for cycle,order in enumerate([['original','cuda-host'],['cuda-host','original']]):
 for label in order:
  c={'name':f'{label}-controlled-load-{cycle}','prewarm_weights':True,
     'workloads':['prose'],'n_predict':64,'repetitions':1}
  if label=='cuda-host':c.update(binary=str(R/'bundle-new-cow-prefault/llama-server'),
    environment={},flags={'--load-mode':'none','--lazy-mode':'on'})
  launch(c)


# Combine the independent prefill and decode improvements in the same fork.
subprocess.run(['python',str(R/'prepare-turbo-cow.py')],check=True)
cache_config=json.loads((E/'runs/turbo-combined-control/result.json').read_text())['config']
for enabled in [0,1]:
 c={**cache_config,'name':f'turbo-cow-enabled{enabled}',
    'binary':str(R/'bundle-turbo-cow/llama-server'),
    'environment':{**cache_config['environment'],'AG1_FLASH_TURBO_COW':str(enabled),
                   'AG1_FLASH_COW_PREFAULT_THREADS':str(best)},
    'prewarm_weights':True,'workloads':['review','prose','edit'],'repetitions':3,
    'api_smoke':True,'teacher_force':['prose','edit'],'teacher_force_count':32}
 launch(c)
cow_result=json.loads((E/'runs/turbo-cow-enabled1/result.json').read_text())
if cow_result['status']=='passed' and cow_result.get('api_smoke',{}).get('tool_call_pass') and all(r.get('quality_content_pass',False) for r in cow_result['requests'] if r['workload']=='edit'):
 c=cow_result['config'];c={**c,'name':'turbo-cow-ngram16-t12',
   'flags':{**c['flags'],'--threads-batch':'12','--cpu-range-batch':'0-11',
     '--spec-type':'ngram-mod','--spec-ngram-mod-n-max':'16','--spec-ngram-mod-n-min':'2','--spec-ngram-mod-n-match':'24'},
   'workloads':['prose','edit','repetitive'],'repetitions':2}
 c.pop('teacher_force',None);c.pop('teacher_force_count',None)
 launch(c)

for cycle,order in enumerate([['base','bulk'],['bulk','base']]):
 for label in order:
  launch({'name':f'bulkcopy-{label}-{cycle}','binary':str(R/'bundle-new-bulkcopy/llama-server'),
    'environment':{'AG1_FLASH_BULK_EXPERT_MIN_TOKENS':str(512 if label=='bulk' else 0)},
    'workloads':['review','prose','edit'],'repetitions':2,'n_predict':256,'api_smoke':True,
    'teacher_force':['prose','edit'],'teacher_force_count':32})

# Both overlays derive from Unsloth329b6160f, ggml-base ABI0.23.0. The COW
# private libllama is retained with its own CPU/backend bundle; only the
# unchanged-ABI ggml-base implementation is replaced in a separate directory.
combined=R/'bundle-new-cow-bulkcopy';shutil.copytree(R/'bundle-new-cow-prefault',combined,symlinks=True)
library='libggml-base.so.0.23.0'
assert (combined/library).is_file() and (R/'bundle-new-bulkcopy'/library).is_file()
shutil.copy2(R/'bundle-new-bulkcopy'/library,combined/library)
for cycle,order in enumerate([['base','bulk'],['bulk','base']]):
 for label in order:
  launch({'name':f'cow-bulkcopy-{label}-{cycle}','binary':str(combined/'llama-server'),
   'environment':{'AG1_FLASH_REGISTER_COW':'1','AG1_FLASH_COW_PREFAULT_THREADS':str(best),
                  'AG1_FLASH_BULK_EXPERT_MIN_TOKENS':str(512 if label=='bulk' else 0)},
   'workloads':['review','prose','edit'],'repetitions':2,'n_predict':256,'api_smoke':True})

# Existing bounded staging has only been tested with8MiB slots. Increasing the
# ring to192MiB tests whether frequent waits were hiding the intended overlap.
for mib in [8,64]:
 launch({'name':f'stage-slot{mib}-repeat','binary':str(R/'bundle-new-stage/llama-server'),
  'environment':{'AG1_FLASH_STAGE':'1','AG1_FLASH_STAGE_MIB':str(mib)},
  'workloads':['review','prose','edit'],'repetitions':3,'n_predict':256,'api_smoke':True})
(E/'further-source-screen-done.json').write_text(json.dumps({'status':'finished'}))
