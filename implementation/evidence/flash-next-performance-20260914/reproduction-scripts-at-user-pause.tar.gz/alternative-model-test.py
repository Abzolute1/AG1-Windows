"""Separate higher-precision model experiment, never a same-file speed claim."""
import hashlib,json,os,shutil,subprocess,time,urllib.request
from pathlib import Path
from bench import run,ROOT as R,EVID as E
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:name=(p/'exe').resolve(strict=True).name
 except OSError:continue
 assert name not in ['llama-server','llama-bench','nvcc','ninja','cc1plus'],(p.name,name)
cat=json.loads((E/'atomic-model-catalog.json').read_text());assessment=json.loads((E/'alternative-427-assessment.json').read_text())
assert assessment['all_shapes_identical'] and assessment['names_identical']
assert set((x['original_type'],x['alternative_type']) for x in assessment['changes']) <= {(29,22),(39,20),(22,21),(29,21)}, 'Unexpected quantization change'
files=[x for x in cat['siblings'] if '4.27bpw' in x['rfilename'] and x['rfilename'].endswith('.gguf')]
D=R/'models/AtomicChat-Flash-Next-4.27bpw';D.mkdir(parents=True,exist_ok=True)
needed=sum(x['size'] for x in files if not (D/Path(x['rfilename']).name).exists())
assert shutil.disk_usage(D).free>needed+80*2**30,'Insufficient disk reserve for separate higher-precision model'
records=[]
for item in files:
 dest=D/Path(item['rfilename']).name;partial=dest.with_suffix('.gguf.partial');expected=item['lfs']['sha256'];size=item['size']
 if dest.exists():
  assert dest.stat().st_size==size
  with dest.open('rb') as f:actual=hashlib.file_digest(f,'sha256').hexdigest()
  assert actual==expected
 else:
  for attempt in range(5):
   try:
    offset=partial.stat().st_size if partial.exists() else 0
    assert offset<=size
    if offset<size:
     url='https://huggingface.co/AtomicChat/Qwen3.8-Flash-Next-GGUF/resolve/'+cat['sha']+'/'+item['rfilename']+'?download=true'
     headers={'Range':f'bytes={offset}-'} if offset else {}
     with urllib.request.urlopen(urllib.request.Request(url,headers=headers),timeout=120) as response:
      if offset:assert response.status==206 and response.headers.get('Content-Range','').startswith(f'bytes {offset}-'), 'Server did not honor resume range'
      with partial.open('ab' if offset else 'wb') as f:
       while chunk:=response.read(4*1024*1024):f.write(chunk)
    assert partial.stat().st_size==size
    with partial.open('rb') as f:actual=hashlib.file_digest(f,'sha256').hexdigest()
    assert actual==expected,'Downloaded shard hash mismatch'
    partial.rename(dest);break
   except Exception:
    if attempt==4:raise
    time.sleep(3)
 records.append({'path':str(dest),'size':size,'sha256':actual,'expected_sha256':expected})
 (E/'alternative-427-download.json').write_text(json.dumps({'repository':'AtomicChat/Qwen3.8-Flash-Next-GGUF','revision':cat['sha'],'materials':records,'disk_free_gib':shutil.disk_usage(D).free/2**30},indent=2))
 print('Verified',dest.name,flush=True)
model=D/Path(files[0]['rfilename']).name
# A/B are different quantizations and are always reported separately. CPU44
# reserves GPU room for larger experts; the preserved model gets the same flags.
for cycle,order in enumerate([['original','higherprecision'],['higherprecision','original']]):
 for label in order:
  flags={'--n-cpu-moe':'44'}
  if label=='higherprecision':flags.update({'--model':str(model),'--alias':'Qwen3.8-Flash-Next-AD-4.27bpw-Q4_K_M-M64'})
  c={'name':f'alternative427-{label}-{cycle}','flags':flags,'validate_tokenizer':True,
     'workloads':['review','prose','edit','reasoning','conversation'],'repetitions':2,'n_predict':256,'api_smoke':True,
     'comparison_kind':'different higher-precision expert quantization; no same-model execution speed claim'}
  (R/(c['name']+'.json')).write_text(json.dumps(c,indent=2));result=run(c)
  if result['status']!='passed':raise RuntimeError('Alternative model screen failed; inspect before any further tests')
(E/'alternative-model-test-done.json').write_text(json.dumps({'status':'finished','model':str(model)}))
