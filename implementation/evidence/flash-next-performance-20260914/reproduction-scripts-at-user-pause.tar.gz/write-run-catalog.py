"""Generate the audit table without turning screened candidates into recommendations."""
import collections,json,statistics,time
from pathlib import Path
E=Path('/home/alex/Projects/AG1/implementation/evidence/flash-next-performance-20260914')
invalid={x['run']:x['reason'] for x in json.loads((E/'invalid-runs.json').read_text())}
prompts=json.loads((E/'prompts.json').read_text())
if (E/'prompts-additional.json').exists():prompts.update(json.loads((E/'prompts-additional.json').read_text()))
lines=['# Real-model experiment catalog','',
 'Generated '+time.strftime('%Y-%m-%d %H:%M:%S UTC',time.gmtime())+'. Investigation remains active.', '',
 'Each row is one workload within one server configuration. Values are medians across the listed requests, not pooled averages across tasks. Initial page-cache misses, expert-cache warm-up and thermal/background effects remain in raw telemetry. These screens identify candidates; they do not establish a final recommendation.', '',
 'Exact-edit content checks ignore outer whitespace. The separate byte column includes the trailing newline. Native text generation is not an actual AG1 file-write check. Health endpoint latency is recorded in raw results and is not presented as end-to-end AG1 readiness.', '',
 'Native decode timing definitions differ: the original excludes the first token (produced by prefill), while the fork includes it in its rate numerator. Common decode recomputes `(predicted_n - 1) * 1000 / predicted_ms` for every build. Native values remain archived. The correction is about0.39% for256-token screens and0.11% for938-token edits.', '',
 '| Run / workload | State | Reps | Prefill tok/s | Decode native | Decode common | TTFT s | Response s | Content / bytes |',
 '|---|---|---:|---:|---:|---:|---:|---:|---|']
counts=collections.Counter();runs=[]
def med(rows,key):
 values=[key(x) for x in rows if key(x) is not None]
 return statistics.median(values) if values else None
def fmt(x):return '—' if x is None else f'{x:.3f}'
for path in sorted((E/'runs').glob('*/result.json')):
 d=json.loads(path.read_text());name=d['name'];status=d.get('status','running')
 if name in invalid:status='excluded'
 if d['config'].get('cupti') or d['config'].get('perf'):status='instrumented'
 counts[status]+=1;groups=collections.defaultdict(list)
 for row in d['requests']:groups[row['workload']].append(row)
 runs.append((path,d,status))
 if not groups:lines.append(f'| [{name}](runs/{name}/result.json) | {status} | 0 | — | — | — | — | — | — |')
 for workload,rows in groups.items():
  content='—';byte='—'
  if 'expected_output' in prompts.get(workload,{}):
   expected=prompts[workload]['expected_output']
   content=f"{sum(r['output'].strip()==expected.strip() for r in rows)}/{len(rows)}"
   byte=f"{sum(r['output'].encode()==expected.encode() for r in rows)}/{len(rows)}"
  elif any('quality_pass' in r for r in rows):content=f"{sum(r.get('quality_pass',False) for r in rows)}/{len(rows)}"
  values=[med(rows,lambda r:r['timings']['prompt_per_second']),med(rows,lambda r:r['timings']['predicted_per_second']),med(rows,lambda r:1000*max(0,r['timings']['predicted_n']-1)/r['timings']['predicted_ms'] if r['timings']['predicted_ms']>0 else None),med(rows,lambda r:r['ttft_seconds']),med(rows,lambda r:r['wall_seconds'])]
  lines.append(f'| [{name}](runs/{name}/result.json) / {workload} | {status} | {len(rows)} | '+' | '.join(fmt(v) for v in values)+f' | {content} / {byte} |')
lines+=['','## Load and peak process resources','',
 'Load measurements reflect the observed OS page-cache state, not standardized cold boots. RSS includes file-backed mappings and is not equivalent to unreclaimable RAM. Total GPU memory includes the desktop. Review per-phase telemetry and smaps for interpretation.','',
 '| Run | Load s | Peak GPU MiB | Process RSS high-water MiB | Exit / errors |','|---|---:|---:|---:|---|']
for path,d,status in runs:
 name=d['name'];error=d.get('error','').replace('|','/').replace('\n',' ')
 lines.append(f"| [{name}](runs/{name}/launch.json) ({status}) | {fmt(d.get('load_seconds'))} | {fmt(d.get('peak_vram_mib'))} | {fmt(d.get('peak_rss_hwm_mib'))} | {d.get('exit_code','—')} {error} |")
lines+=['','## Exclusions','']
for name,reason in invalid.items():lines.append(f'- `{name}`: {reason}')
lines+=['','Process status counts: '+', '.join(f'{k}={v}' for k,v in sorted(counts.items()))+'.',
 'All original source/runtime/model preservation checks and final recommendations remain separate from this generated catalog.','']
(E/'RUNS.md').write_text('\n'.join(lines))
print(json.dumps({'run_status_counts':counts,'requests':sum(len(d['requests']) for _,d,_ in runs)}))
