"""Run only after discovery queues exit, with a selected primary-model config.
Usage: python final-validation-suite.py candidate-config.json
This does not cut over AG1. It creates fresh baseline/config-only/candidate runs.
"""
import json,sys
from bench import ROOT as R,EVID as E,run
from pathlib import Path
candidate=json.loads(Path(sys.argv[1]).read_text())
assert not candidate.get('cupti') and not candidate.get('perf')
assert '--model' not in candidate.get('flags',{}), 'Primary validation must preserve the original model file'
assert candidate.get('flags',{}).get('--ctx-size','90000')=='90000'
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:name=(p/'exe').resolve(strict=True).name
 except OSError:continue
 assert name not in ['llama-server','llama-bench','nvcc','ninja','cc1plus'],(p.name,name)
config_only={'flags':{'--threads-batch':'12','--cpu-range-batch':'0-11',
 '--spec-type':'ngram-mod','--spec-ngram-mod-n-max':'16','--spec-ngram-mod-n-min':'2','--spec-ngram-mod-n-match':'24'}}
profiles={'original':{},'config-only':config_only,'candidate':candidate}
def launch(c):
 (R/(c['name']+'.json')).write_text(json.dumps(c,indent=2));return run(c)
# Three balanced process orders. Full prose/review/reasoning answers rather
# than the truncated discovery screens. Exact-edit budgets remain fixture-owned.
for cycle,order in enumerate([['original','config-only','candidate'],['candidate','original','config-only'],['config-only','candidate','original']]):
 for label in order:
  c={**profiles[label],'name':f'final-{label}-{cycle}',
    'workloads':['review','edit','prose','tool','conversation','repetitive','reasoning'],
    'repetitions':1,'n_predict':1800,'api_smoke':True}
  for key in ['state_equivalence','teacher_force','teacher_force_count','prepare_long','prepare_extra']:c.pop(key,None)
  launch(c)
# Long context is mandatory even if the earlier masked-warp fixture found no win.
for cycle,order in enumerate([['original','candidate'],['candidate','original']]):
 for label in order:
  launch({**profiles[label],'name':f'final-long80k-{label}-{cycle}',
   'prepare_long':True,'workloads':['long80k'],'repetitions':1,'n_predict':768,'api_smoke':True})
(E/'final-validation-suite-done.json').write_text(json.dumps({'status':'finished','candidate_configuration':candidate}))
