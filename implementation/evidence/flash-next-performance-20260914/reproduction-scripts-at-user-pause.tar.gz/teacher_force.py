import json,hashlib

def run(post,prompts,evidence,out,workloads,count=96):
 gold_path=evidence/'teacher-force-gold.json'
 if gold_path.exists():gold=json.loads(gold_path.read_text())
 else:
  baseline=json.loads((evidence/'runs/baseline-01/result.json').read_text());gold={}
  for name in workloads:
   text=next(r['output'] for r in baseline['requests'] if r['workload']==name)
   tokens=post('/tokenize',{'content':text,'add_special':False})['tokens']
   gold[name]={'tokens':tokens,'source':'baseline-01 first response, canonical output-text tokenization','text_sha256':hashlib.sha256(text.encode()).hexdigest()}
  gold_path.write_text(json.dumps(gold,indent=2))
 results={}
 for name in workloads:
  if name not in gold or len(gold[name]['tokens'])<count:
   raise RuntimeError('Canonical teacher-force suffix is missing or shorter than the requested comparison: '+name)
  suffix=[];rows=[]
  for i,expected in enumerate(gold[name]['tokens'][:count]):
   payload={'prompt':prompts[name]['tokens']+suffix,'stream':False,'n_predict':1,'temperature':0,'top_k':1,'top_p':1,'min_p':0,'repeat_penalty':1,'seed':777,'cache_prompt':True,'id_slot':0,'n_probs':32,'post_sampling_probs':False,'return_tokens':True}
   response=post('/completion',payload);probs=response.get('completion_probabilities',[])
   if not probs:raise RuntimeError('Teacher-force response has no probabilities')
   if i and response['timings']['prompt_n']>2:raise RuntimeError('Teacher-force prefix was not reused; this would measure prefill instead of decode')
   rows.append({'position':i,'gold_token':expected,'timings':response['timings'],'probabilities':probs,'content':response.get('content'),'tokens':response.get('tokens')})
   suffix.append(expected)
  results[name]=rows
 (out/'teacher-force.json').write_text(json.dumps(results,indent=2));return {'workloads':list(results),'positions':sum(len(v) for v in results.values()),'scope':'Diagnostic canonical teacher-forced suffixes; top32 pre-sampling probabilities, not a timed throughput comparison.'}
