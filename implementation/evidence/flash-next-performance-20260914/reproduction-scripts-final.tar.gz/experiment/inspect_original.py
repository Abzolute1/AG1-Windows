import json,hashlib,subprocess,os,struct,math,collections
from pathlib import Path
R=Path('/home/alex/Projects/flash-next-perf-20260914');E=Path('/home/alex/Projects/AG1/implementation/evidence/flash-next-performance-20260914');E.mkdir(exist_ok=True)
def save(n,d):(E/n).write_text(json.dumps(d,indent=2)+'\n')
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
capture=Path('/home/alex/.local/state/ag1/desktop/configuration/runtime-configuration-vision-20260909.json');req=json.loads(capture.read_text())['request'];m=next(m for m in req['models'] if 'Flash' in m['model_id']);model=Path(m['model_path'])
env={k:v for k,v in os.environ.items() if k in ['PATH','HOME','USER','LANG','LC_ALL','TMPDIR']}
env.update({k:v for k,v in m['expected']['environment'].items() if k.startswith(('GGML_','LLAMA_','OMP_','GOMP_','CUDA_')) or k in ['LD_LIBRARY_PATH','LD_PRELOAD']})
base={'command':m['expected']['command'],'args':m['expected']['args'],'environment':env,'model_id':m['model_id'],'model_path':str(model),'installed_ag1':str(Path('/opt/ag1/current').resolve())};save('original-launch.json',base)
files=[model.parent/p.name for p in sorted(model.parent.glob('*.gguf'))]
expected={x['path']:x['sha256'] for x in m['materials'] if x['kind']=='weight'}
protected=set(Path(p) for p in json.loads(Path('/home/alex/Projects/AG1/implementation/evidence/llama-performance-20260914/protected-after.json').read_text()))
protected.update(p for p in Path(base['command']).parent.rglob('*') if p.is_file())
protected.update([capture,Path('/home/alex/.ag1/agent/llamacpp-model-profiles.json')])
for key in ['profile','inherited_environment']:
 protected.add(Path(req[key]['path']))
protected_data={str(p):{'size':p.stat().st_size,'sha256':sha(p),'symlink':os.readlink(p) if p.is_symlink() else None} for p in sorted(protected)};save('protected-before.json',protected_data)
roots=['/home/alex/Projects/llama-cpp-qwen4exp','/home/alex/Projects/llama-cpp-turboquant'];git={}
for root in roots:
 git[root]={k:subprocess.check_output(['git','-C',root,*cmd],text=True).strip() for k,cmd in [('commit',['rev-parse','HEAD']),('status',['status','--porcelain']),('remotes',['remote','-v'])]}
save('original-source.json',git)
layouts=[];summaries=[]
for p in files:
 with p.open('rb') as f:
  def unpack(fmt):return struct.unpack('<'+fmt,f.read(struct.calcsize('<'+fmt)))[0]
  def string():return f.read(unpack('Q')).decode('utf8')
  formats={0:'B',1:'b',2:'H',3:'h',4:'I',5:'i',6:'f',7:'?',10:'Q',11:'q',12:'d'}
  def value(t):
   if t==8:return string()
   if t==9:
    st=unpack('I');n=unpack('Q');a=[value(st) for _ in range(n)];return a if n<=256 else {'length':n,'type':st}
   return unpack(formats[t])
  assert f.read(4)==b'GGUF';version=unpack('I');nt=unpack('Q');nk=unpack('Q');meta={}
  for _ in range(nk):
   k=string();v=value(unpack('I'))
   if not k.startswith('tokenizer.'):meta[k]=v
  ts=[]
  for _ in range(nt):
   n=string();nd=unpack('I');dims=[unpack('Q') for _ in range(nd)];typ=unpack('I');offset=unpack('Q');ts.append({'name':n,'dims':dims,'type':typ,'offset':offset,'parameters':math.prod(dims)})
  align=meta.get('general.alignment',32);data_offset=(f.tell()+align-1)//align*align
  for i,t in enumerate(ts):t.update(file=str(p),absolute_offset=data_offset+t['offset'],bytes=(ts[i+1]['offset'] if i+1<len(ts) else p.stat().st_size-data_offset)-t['offset'])
  layouts+=ts;summaries.append({'path':str(p),'size':p.stat().st_size,'version':version,'tensor_count':nt,'data_offset':data_offset,'metadata':meta})
save('model-layout.json',layouts);save('model-info.json',summaries)
print('Metadata saved:',len(files),'shards',sum(p.stat().st_size for p in files)/2**30,'GiB',len(layouts),'tensors',flush=True)
print('Hashing original model shards; no inference will run concurrently.',flush=True)
materials=[]
for p in files:
 h=sha(p);materials.append({'path':str(p),'size':p.stat().st_size,'sha256':h,'sealed_expected':expected.get(str(p)),'matches_capture':h==expected.get(str(p))});save('model-materials-before.json',materials)
 print('Hashed',p.name,'matches capture',materials[-1]['matches_capture'],flush=True)
assert all(x['matches_capture'] for x in materials)
print('Preservation inventory complete.',flush=True)
