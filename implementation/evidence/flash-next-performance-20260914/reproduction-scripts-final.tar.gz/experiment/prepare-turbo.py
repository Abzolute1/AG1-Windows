import json,subprocess,time,hashlib,urllib.request,tarfile
from pathlib import Path
R=Path('/home/alex/Projects/flash-next-perf-20260914');E=Path('/home/alex/Projects/AG1/implementation/evidence/flash-next-performance-20260914')
while not (E/'fourth-screen-done.json').exists():time.sleep(3)
sha=json.loads((E/'turboquant-latest.json').read_text())['sha'];archive=R/'turbo-latest-source.tar.gz';url='https://api.github.com/repos/TheTom/llama-cpp-turboquant/tarball/'+sha
print('Downloading pinned TurboQuant source',sha,flush=True)
with urllib.request.urlopen(url) as response,archive.open('wb') as f:
 while block:=response.read(1024*1024):f.write(block)
with archive.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
root=R/'turbo-latest-source';root.mkdir()
with tarfile.open(archive) as t:t.extractall(root,filter='data')
src=next(p for p in root.iterdir() if p.is_dir())
assert (src/'AGENTS.md').read_text()==(R/'source-reference/turbo-latest-AGENTS.md').read_text()
(E/'turbo-source-manifest.json').write_text(json.dumps({'revision':sha,'archive_sha256':digest,'archive_bytes':archive.stat().st_size,'url':url,'source':str(src)},indent=2))
print('Source extracted',src,flush=True)
while not (E/'fifth-preparation-done.json').exists():time.sleep(3)
base=json.loads((E/'cow-build-command.json').read_text())['configure'];build=R/'build-turbo-latest'
cmd=base.copy();cmd[cmd.index('-S')+1]=str(src);cmd[cmd.index('-B')+1]=str(build);cmd.remove('-DGGML_CUDA=OFF');cmd.remove('-DLLAMA_BUILD_TESTS=OFF')
cmd+=['-DCMAKE_C_COMPILER=/usr/bin/gcc-15','-DCMAKE_CXX_COMPILER=/usr/bin/g++-15','-DCMAKE_CUDA_HOST_COMPILER=/usr/bin/g++-15','-DCMAKE_CUDA_COMPILER=/opt/cuda/bin/nvcc','-DCMAKE_CUDA_ARCHITECTURES=89','-DGGML_CUDA=ON','-DGGML_CUDA_GRAPHS=ON','-DGGML_CUDA_FA_ALL_QUANTS=ON','-DGGML_CUDA_NCCL=OFF','-DLLAMA_BUILD_TESTS=ON']
(E/'turbo-build-command.json').write_text(json.dumps({'configure':cmd},indent=2))
try:
 with (E/'turbo-configure.log').open('w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
 print('Building TurboQuant for sm89',flush=True)
 with (E/'turbo-build.log').open('w') as f:subprocess.run(['cmake','--build',str(build),'--target','llama-server','test-moe-cache','test-backend-ops','test-quantize-fns','test-turbo-quant','-j8'],stdout=f,stderr=subprocess.STDOUT,check=True)
 result={'status':'built','binary':str(build/'bin/llama-server')}
except subprocess.CalledProcessError as e:result={'status':'failed','error':str(e)}
(E/'turbo-build-result.json').write_text(json.dumps(result,indent=2));(E/'turbo-preparation-done.json').write_text(json.dumps(result));print(result,flush=True)
