import json,subprocess,time
from pathlib import Path
R=Path('/home/alex/Projects/flash-next-perf-20260914')
E=Path('/home/alex/Projects/AG1/implementation/evidence/flash-next-performance-20260914')
parent=1850869;started=time.time()
while True:
 try:state=Path(f'/proc/{parent}/status').read_text()
 except FileNotFoundError:state='State:\tZ'
 if 'State:\tZ' in state:break
 time.sleep(3)
marker=E/'further-source-screen-done.json'
assert marker.exists() and marker.stat().st_mtime>started,'Prior source screen exited without a fresh completion marker; no model download started'
with (E/'alternative-model-test-console.log').open('w') as log:
 result=subprocess.run(['python',str(R/'alternative-model-test.py')],stdout=log,stderr=subprocess.STDOUT)
(E/'alternative-model-test-dispatch-result.json').write_text(json.dumps({'returncode':result.returncode}))
raise SystemExit(result.returncode)
