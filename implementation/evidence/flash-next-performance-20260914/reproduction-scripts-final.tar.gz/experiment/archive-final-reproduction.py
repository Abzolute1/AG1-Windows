"""Archive reproduction code after timed work, without models or private captures."""
import hashlib
import json
import tarfile
from datetime import datetime, timezone
from pathlib import Path

R = Path('/home/alex/Projects/flash-next-perf-20260914')
A = Path('/home/alex/Projects/AG1/.local/ag1-flash-validation-20260914')
E = Path('/home/alex/Projects/AG1/implementation/evidence/flash-next-performance-20260914')
for p in Path('/proc').iterdir():
    if not p.name.isdigit():
        continue
    try:
        name = (p / 'exe').resolve(strict=True).name
    except OSError:
        continue
    assert name not in {'llama-server', 'llama-bench', 'nvcc', 'ninja', 'cc1plus', 'rustc'}, (p.name, name)

destination = E / 'reproduction-scripts-final.tar.gz'
manifest_path = E / 'reproduction-scripts-final.json'
assert not destination.exists() and not manifest_path.exists()
files = []
for directory, prefix, patterns in [
    (R, 'experiment', ['*.py', '*.sh', '*.cpp', '*.cu']),
    (A, 'private-ag1-harness', ['*.py']),
    (E, 'patches-and-builds', ['*.patch', '*build-command.json']),
]:
    for path in sorted({p for pattern in patterns for p in directory.glob(pattern)}):
        assert path.is_file() and not path.is_symlink()
        files.append((path, prefix + '/' + path.name))
records = [{'path': str(p), 'archive_path': name, 'bytes': p.stat().st_size,
            'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p, name in files]
manifest = {'created_at': datetime.now(timezone.utc).isoformat(),
            'scope': 'Reproduction source scripts, source patches and build commands. No model weights, private profiles, authority keys or inherited-environment captures. Run configurations, evidence and pinned source/build trees remain at their recorded paths.',
            'warning': 'Historical controllers are included for audit, not automatic replay. Never run prepare_runner.py, inspect_original.py, write-report-foundation.py, old controllers or existing-name benchmark configurations blindly. Read the handoff and current report. Fresh run names and serialized GPU/build/download/hash work are required.',
            'files': records}
manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
with tarfile.open(destination, 'x:gz') as archive:
    archive.add(manifest_path, arcname='MANIFEST.json')
    for path, name in files:
        archive.add(path, arcname=name, recursive=False)
with tarfile.open(destination, 'r:gz') as archive:
    assert set(archive.getnames()) == {'MANIFEST.json', *(x['archive_path'] for x in records)}
    for row in records:
        with archive.extractfile(row['archive_path']) as stream:
            assert hashlib.file_digest(stream, 'sha256').hexdigest() == row['sha256']
print(json.dumps({'archive': str(destination), 'files': len(records),
                  'bytes': destination.stat().st_size,
                  'sha256': hashlib.sha256(destination.read_bytes()).hexdigest()}))
