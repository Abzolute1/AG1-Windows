"""Run only after discovery queues exit, with a selected primary-model config.
Usage: python final-validation-suite.py candidate-config.json
This does not cut over AG1. It creates fresh baseline/config-only/candidate runs.
"""
import argparse,json
from bench import ROOT as R,EVID as E,run
from pathlib import Path
parser=argparse.ArgumentParser()
parser.add_argument('candidate',type=Path)
parser.add_argument('--config-only',type=Path,help='Optional best measured original-runtime configuration-only control')
parser.add_argument('--focused-closeout',action='store_true',help='Two balanced full-answer cycles and one original/candidate long-context pair; discovery already has six long-context runs')
args=parser.parse_args()
candidate=json.loads(args.candidate.read_text())
assert not candidate.get('cupti') and not candidate.get('perf')
assert '--model' not in candidate.get('flags',{}), 'Primary validation must preserve the original model file'
assert candidate.get('flags',{}).get('--ctx-size','90000')=='90000'
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:name=(p/'exe').resolve(strict=True).name
 except OSError:continue
 assert name not in ['llama-server','llama-bench','nvcc','ninja','cc1plus'],(p.name,name)
config_only={'flags':{'--threads-batch':'12','--cpu-range-batch':'0-11',
 '--spec-type':'ngram-mod','--spec-ngram-mod-n-max':'16','--spec-ngram-mod-n-min':'2','--spec-ngram-mod-n-match':'24'}}
if args.config_only:
 config_only=json.loads(args.config_only.read_text())
 assert not any(config_only.get(k) for k in ['binary','environment','remove','cupti','perf']), 'Configuration-only control must use the untouched original runtime'
 assert '--model' not in config_only.get('flags',{})
 assert config_only.get('flags',{}).get('--ctx-size','90000')=='90000'
profiles={'original':{},'config-only':config_only,'candidate':candidate}
def launch(c):
 (R/(c['name']+'.json')).write_text(json.dumps(c,indent=2))
 result=run(c)
 if result['status']!='passed':
  raise RuntimeError(f"Final validation process failed: {c['name']}: {result.get('error')}")
 return result
# Three balanced process orders. Full prose/review/reasoning answers rather
# than the truncated discovery screens. Exact-edit budgets remain fixture-owned.
orders=[['original','config-only','candidate'],['candidate','config-only','original']] if args.focused_closeout else [['original','config-only','candidate'],['candidate','original','config-only'],['config-only','candidate','original']]
for cycle,order in enumerate(orders):
 for label in order:
  c={**profiles[label],'name':f'final-{label}-{cycle}',
    'workloads':['review','edit','prose','tool','conversation','repetitive','reasoning'],
    'repetitions':1,'n_predict':1800,'api_smoke':True}
  for key in ['state_equivalence','teacher_force','teacher_force_count','prepare_long','prepare_extra']:c.pop(key,None)
  launch(c)
# Long context is mandatory even if the earlier masked-warp fixture found no win.
long_orders=[['original','candidate']] if args.focused_closeout else [['original','candidate'],['candidate','original']]
for cycle,order in enumerate(long_orders):
 for label in order:
  launch({**profiles[label],'name':f'final-long80k-{label}-{cycle}',
   'prepare_long':True,'workloads':['long80k'],'repetitions':1,'n_predict':768,'api_smoke':True})
(E/'final-validation-suite-done.json').write_text(json.dumps({'status':'finished','candidate_configuration':candidate,'config_only_configuration':config_only,'focused_closeout':args.focused_closeout,'full_answer_process_orders':orders,'long_context_process_orders':long_orders}))
