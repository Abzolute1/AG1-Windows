import urllib.request,subprocess,json
from pathlib import Path
R=Path('/home/alex/Projects/flash-next-perf-20260914');p=R/'downloads/perf-7.1.8-1-x86_64.pkg.tar.zst';url='https://archive.archlinux.org/packages/p/perf/'+p.name
if not p.exists():
 try:urllib.request.urlretrieve(url,p)
 except Exception as e:print('Perf package unavailable:',str(e));raise SystemExit(0)
target=R/'tools/perf';target.mkdir(parents=True,exist_ok=True)
subprocess.run(['tar','--zstd','-xf',str(p),'-C',str(target)],check=True)
check=subprocess.run(['ldd',str(target/'usr/bin/perf')],text=True,capture_output=True)
(R/'tools/perf-dependencies.txt').write_text(check.stdout+check.stderr)
print(check.stdout)
