#include <cuda_runtime_api.h>
#include <cstdio>
#include <initializer_list>
#include <cstdlib>
#include <sys/mman.h>
#include <sys/resource.h>
#include <fcntl.h>
#include <unistd.h>
static void check(const char * label, void * p, size_t size, unsigned flags) {
    cudaError_t e=cudaHostRegister(p,size,flags);
    printf("%s flags=%u result=%d %s\n",label,flags,int(e),cudaGetErrorString(e));
    if(e==cudaSuccess)cudaHostUnregister(p);
    cudaGetLastError();
}
int main(int argc,char ** argv) {
    if(argc!=2)return 2;
    rlimit r{};getrlimit(RLIMIT_MEMLOCK,&r);printf("memlock=%llu/%llu\n",(unsigned long long)r.rlim_cur,(unsigned long long)r.rlim_max);
    for(auto a:{cudaDevAttrHostRegisterSupported,cudaDevAttrHostRegisterReadOnlySupported,cudaDevAttrPageableMemoryAccess,cudaDevAttrPageableMemoryAccessUsesHostPageTables}) {
        int x=-1;auto e=cudaDeviceGetAttribute(&x,a,0);printf("attr=%d value=%d status=%d\n",int(a),x,int(e));
    }
    void * anon=mmap(nullptr,8192,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);
    check("anonymous-rw",anon,8192,cudaHostRegisterPortable);
    mprotect(anon,8192,PROT_READ);check("anonymous-ro",anon,8192,cudaHostRegisterPortable|cudaHostRegisterReadOnly);munmap(anon,8192);
    int fd=open(argv[1],O_RDONLY|O_CLOEXEC);if(fd<0)return 3;
    void * file=mmap(nullptr,8192,PROT_READ,MAP_PRIVATE,fd,0);
    check("file-private-ro",file,8192,cudaHostRegisterPortable|cudaHostRegisterReadOnly);munmap(file,8192);
    file=mmap(nullptr,8192,PROT_READ,MAP_SHARED,fd,0);
    check("file-shared-ro",file,8192,cudaHostRegisterPortable|cudaHostRegisterReadOnly);munmap(file,8192);
    file=mmap(nullptr,8192,PROT_READ|PROT_WRITE,MAP_PRIVATE,fd,0);
    check("file-private-cow",file,8192,cudaHostRegisterPortable);munmap(file,8192);close(fd);
}
