#!/usr/bin/env python3
import resource,ctypes,argparse,hashlib,json,os,signal,statistics,subprocess,threading,time,urllib.request,urllib.error
from pathlib import Path
ROOT=Path('/home/alex/Projects/flash-next-perf-20260914')
EVID=Path('/home/alex/Projects/AG1/implementation/evidence/flash-next-performance-20260914')
BASE=json.loads((EVID/'original-launch.json').read_text())
PORT=18438
URL=f'http://127.0.0.1:{PORT}'
class NvmlProcessInfoV2(ctypes.Structure):
 _fields_=[('pid',ctypes.c_uint),('usedGpuMemory',ctypes.c_ulonglong),
           ('gpuInstanceId',ctypes.c_uint),('computeInstanceId',ctypes.c_uint)]
def api(path,data=None,timeout=900):
 req=urllib.request.Request(URL+path,data=json.dumps(data).encode() if data is not None else None,headers={'Content-Type':'application/json'})
 return urllib.request.urlopen(req,timeout=timeout)
def get(path):
 with api(path,timeout=2) as r:return json.load(r)
def post(path,data):
 with api(path,data) as r:return json.load(r)
def median(xs):return statistics.median(xs) if xs else None

def build_prompts():
 from workloads import build
 return build(post,EVID/'prompts.json')

def run(config):
 resource.setrlimit(resource.RLIMIT_CORE,(0,0))
 competing=[]
 blocked={'cc1','cc1plus','cmake','gcc','g++','g++-15','nvcc','ninja','make','check-dot','test-mmid-single','test-backend-ops','llama-perplexity','llama-bench','test-q5-extract'}
 for process in Path('/proc').iterdir():
  if not process.name.isdigit():continue
  try: executable=(process/'exe').resolve(strict=True).name
  except OSError:continue
  if executable in blocked:competing.append({'pid':int(process.name),'executable':executable})
 if competing:raise RuntimeError('Refusing timed inference while CPU/build tests are active: '+json.dumps(competing))
 name=config['name'];out=EVID/'runs'/name;out.mkdir(parents=True,exist_ok=False)

 args=BASE['args'].copy();overrides={'--port':str(PORT),**config.get('flags',{})}
 for k,v in overrides.items():
  if k in args:
   i=args.index(k);args[i+1]=str(v)
  else:args += [k,str(v)]
 for k in config.get('remove',[]):
  if k in args:
   i=args.index(k);args.pop(i)
   if i<len(args) and not args[i].startswith('-'):args.pop(i)
 args+=config.get('extra',[])
 command=config.get('binary',BASE['command']);env=BASE['environment'].copy();env.update(config.get('environment',{}))
 if 'binary' in config:env['LD_LIBRARY_PATH']=str(Path(command).parent)
 if config.get('cupti'):
  env['LD_PRELOAD']=str(ROOT/'libcupti-trace.so');env['AG1_PERF_TRACE_DIR']=str(out)

 pre=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
 background=[]
 for pid in pre.splitlines():
  try: exe=Path(f'/proc/{int(pid)}/exe').resolve().name
  except (ValueError,OSError):continue
  if exe.lower() not in ['discord','chrome','chromium','electron','codex']:raise RuntimeError('Another GPU compute process is active: '+exe)
  background.append({'pid':int(pid),'executable':exe})
 (out/'background.json').write_text(json.dumps(background))
 if config.get('prewarm_weights'):
  if args[args.index('--model')+1]!=BASE['model_path']:
   raise RuntimeError('Prewarm manifest only covers the preserved primary model')
  layout=json.loads((EVID/'model-layout.json').read_text())
  ple_files={x['file'] for x in layout if x['name']=='per_layer_token_embd.weight'}
  files=sorted({x['file'] for x in layout}-ple_files)
  before=time.monotonic();read_bytes=0
  for filename in files:
   with open(filename,'rb') as f:
    while data:=f.read(8*1024*1024):read_bytes+=len(data)
  (out/'prewarm.json').write_text(json.dumps({'scope':'Read all non-PLE primary-model shards before starting the load timer. No weights changed; PLE remains demand-paged.','files':files,'bytes':read_bytes,'seconds':time.monotonic()-before},indent=2))
 if config.get('evict_ple_before_load'):
  from ple_cache import residency
  ple=next(Path(BASE['model_path']).parent.glob('*-00002-of-00028.gguf'))
  (out/'ple-cache-before.json').write_text(json.dumps(residency(ple,True),indent=2))

 (out/'launch.json').write_text(json.dumps({'binary':command,'args':args,'environment':env,'configuration':config},indent=2))
 monitor_stop=threading.Event();phase=['load'];samples=[];proc=None;perf_proc=None;perf_log=None
 def monitor():
  previous=None
  nvml=ctypes.CDLL('libnvidia-ml.so.1');dev=ctypes.c_void_p()
  nvml_ok=nvml.nvmlInit_v2()==0 and nvml.nvmlDeviceGetHandleByIndex_v2(0,ctypes.byref(dev))==0
  while not monitor_stop.is_set():
   now=time.monotonic();row={'time':now,'phase':phase[0]}
   try:
    lines=subprocess.check_output(['nvidia-smi','--query-gpu=utilization.gpu,utilization.memory,memory.used,temperature.gpu,power.draw,clocks.sm,clocks.mem','--format=csv,noheader,nounits'],text=True,timeout=2).strip().split(', ')
    row.update(dict(zip(['gpu_pct','gpu_memory_pct','vram_mib','gpu_temp','gpu_watts','sm_mhz','memory_mhz'],map(float,lines))))
    if nvml_ok:
     for counter,label in [(0,'pcie_tx_kibs'),(1,'pcie_rx_kibs')]:
      value=ctypes.c_uint()
      if nvml.nvmlDeviceGetPcieThroughput(dev,counter,ctypes.byref(value))==0:row[label]=value.value
     if proc:
      entries=(NvmlProcessInfoV2*64)();count=ctypes.c_uint(64)
      if nvml.nvmlDeviceGetComputeRunningProcesses_v2(dev,ctypes.byref(count),entries)==0:
       own=next((x.usedGpuMemory for x in entries[:count.value] if x.pid==proc.pid),None)
       if own is not None and own<2**63:
        row['process_vram_mib']=own/1048576
        row['other_vram_mib']=row['vram_mib']-row['process_vram_mib']
    if proc:
     stat=Path(f'/proc/{proc.pid}/stat').read_text().rsplit(')',1)[1].split();ticks=int(stat[11])+int(stat[12]);rss=int(stat[21])*os.sysconf('SC_PAGE_SIZE')/1048576
     row['rss_mib']=rss
     if previous:row['cpu_pct']=(ticks-previous[1])/os.sysconf('SC_CLK_TCK')/(now-previous[0])*100
     previous=(now,ticks)
     status=Path(f'/proc/{proc.pid}/status').read_text();row['threads']=int(next(l for l in status.splitlines() if l.startswith('Threads:')).split()[1])
     row['rss_hwm_mib']=int(next(l for l in status.splitlines() if l.startswith('VmHWM:')).split()[1])/1024
     row['minor_faults']=int(stat[7]);row['major_faults']=int(stat[9])
     for line in Path(f'/proc/{proc.pid}/io').read_text().splitlines():
      k,v=line.split(':');row['io_'+k]=int(v)
     row['diskstats_sda']=[int(x) for x in next(l for l in Path('/proc/diskstats').read_text().splitlines() if l.split()[2]=='sda').split()[3:]]
    meminfo={l.split(':',1)[0]:int(l.split()[1]) for l in Path('/proc/meminfo').read_text().splitlines()}
    row['sys_available_mib']=meminfo['MemAvailable']/1024
    row['sys_swap_used_mib']=(meminfo['SwapTotal']-meminfo['SwapFree'])/1024
    try:
     row['cpu_mhz_by_core']=[int(Path(f'/sys/devices/system/cpu/cpu{i}/cpufreq/cpuinfo_avg_freq').read_text())/1000 for i in range(12)]
     limits=args[args.index('--cpu-range')+1].split('-');first,last=int(limits[0]),int(limits[-1])
     row['cpu_active_range_mhz']=median(row['cpu_mhz_by_core'][first:last+1])
     row['cpu_temp_tctl']=int(Path('/sys/class/hwmon/hwmon3/temp1_input').read_text())/1000
    except (OSError,ValueError):pass

   except (Exception,) as e:row['monitor_error']=type(e).__name__
   samples.append(row);monitor_stop.wait(.5)
  if nvml_ok:nvml.nvmlShutdown()
 def summary_samples(label):
  rows=[r for r in samples if r['phase']==label]
  return {k:{'median':median([r[k] for r in rows if k in r]),'max':max([r[k] for r in rows if k in r],default=None)} for k in ['gpu_pct','gpu_memory_pct','vram_mib','process_vram_mib','other_vram_mib','rss_mib','cpu_pct','gpu_temp','gpu_watts','sm_mhz','pcie_rx_kibs','pcie_tx_kibs','rss_hwm_mib','sys_available_mib','sys_swap_used_mib','cpu_active_range_mhz','cpu_temp_tctl']}
 start=time.monotonic();summary={'name':name,'config':config,'requests':[],'started_at':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}
 summary['model_path']=args[args.index('--model')+1];summary['model_alias']=args[args.index('--alias')+1]
 log=(out/'server.log').open('w');t=threading.Thread(target=monitor,daemon=True)
 try:
  proc=subprocess.Popen([command]+args,env=env,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);(out/'pid').write_text(str(proc.pid));t.start()
  while True:
   if proc.poll() is not None:raise RuntimeError(f'Server exited during load: {proc.returncode}')
   try:
    if get('/health').get('status')=='ok':break
   except Exception:pass
   if time.monotonic()-start>900:raise TimeoutError('model load exceeded 900s')
   time.sleep(.2)
  summary['load_seconds']=time.monotonic()-start;phase[0]='idle';(out/'props.json').write_text(json.dumps(get('/props'),indent=2));prompts=build_prompts()
  if config.get('validate_tokenizer'):
   checked=[]
   for key,fixture in prompts.items():
    if 'prompt' not in fixture or 'tokens' not in fixture:continue
    actual=post('/tokenize',{'content':fixture['prompt'],'add_special':False})['tokens']
    if actual!=fixture['tokens']:raise RuntimeError('Alternate model tokenizer does not match frozen prompt: '+key)
    checked.append(key)
   summary['tokenizer_equivalence']=checked
  readiness=[]
  for _ in range(10):
   h=time.monotonic();get('/health');readiness.append(time.monotonic()-h)
  summary['warm_health_seconds']=readiness
  maps=Path(f'/proc/{proc.pid}/maps').read_text()
  (out/'smaps-ready.txt').write_text(Path(f'/proc/{proc.pid}/smaps').read_text())
  (out/'loaded-libraries.json').write_text(json.dumps(sorted({line.split()[-1] for line in maps.splitlines() if '/' in line and any(lib in line for lib in ['libggml','libllama','libcuda','libag1perf','libmmap'])}),indent=2))
  if config.get('perf'):
   perf_log=(out/'perf.log').open('w')
   perf_env={**os.environ,'LD_LIBRARY_PATH':str(ROOT/'tools/perf/usr/lib'),'DEBUGINFOD_URLS':''}
   perf_proc=subprocess.Popen([str(ROOT/'tools/perf/usr/bin/perf'),'record','-o',str(out/'perf.data'),'-F','99','-e','cycles:u','--call-graph','dwarf,4096','-p',str(proc.pid)],env=perf_env,stdout=perf_log,stderr=subprocess.STDOUT)
  if config.get('prepare_extra'):
   from extra_workload import extend
   prompts=extend(prompts,post,EVID/'prompts.json')
  if config.get('prepare_code'):
   from source_workload import extend
   prompts=extend(prompts,post,EVID/'prompts.json')
  if config.get('prepare_long'):
   from long_workload import extend
   prompts=extend(prompts,post,EVID/'prompts-long-context.json')
  for workload in config.get('workloads',['review','prose']):
   for repeat in range(config.get('repetitions',3)):
    phase[0]=f'{workload}-{repeat}-prefill';payload={'prompt':prompts[workload]['tokens'],'stream':True,'n_predict':config.get('n_predict',256),'temperature':0,'seed':777,'top_k':1,'top_p':1,'min_p':0,'repeat_penalty':1,'cache_prompt':False,'id_slot':0}
    if workload=='quality' or 'expected' in prompts[workload]:payload['n_predict']=768
    if 'expected_output' in prompts[workload]:payload['n_predict']=prompts[workload].get('max_tokens',2048)
    payload.update(prompts[workload].get('payload',{}))
    payload.update(config.get('payload',{}))
    if workload=='conversation':
     payload['cache_prompt']=True
     # Prefill a persistent conversation, then append a new user turn.
     warm={**payload,'prompt':prompts[workload]['prefix_tokens'],'stream':False,'n_predict':1}
     post('/completion',warm)
    if config.get('diagnostic_n_probs'):
     payload['n_probs']=config['diagnostic_n_probs'];payload['return_tokens']=True
    started=time.monotonic();first=None;parts=[];final={};events=[]
    with api('/completion',payload) as response:
     for line in response:
      if not line.startswith(b'data: '):continue
      event=json.loads(line[6:]);events.append(event)
      if event.get('content'):
       if first is None:first=time.monotonic();phase[0]=f'{workload}-{repeat}-decode'
       parts.append(event['content'])
      if event.get('stop'):final=event
      if 'error' in event:raise RuntimeError(str(event['error']))
    ended=time.monotonic();phase[0]='idle';text=''.join(parts)
    row={'workload':workload,'repeat':repeat,'ttft_seconds':None if first is None else first-started,'wall_seconds':ended-started,'timings':final.get('timings'),'output':text,'prompt_tokens':len(prompts[workload]['tokens']),'prompt_sha256':prompts[workload]['sha256'],'prefill_resources':summary_samples(f'{workload}-{repeat}-prefill'),'decode_resources':summary_samples(f'{workload}-{repeat}-decode'),'stop_type':final.get('stop_type')}
    if not row['timings']:raise RuntimeError('Missing native timing record')
    # The original excludes the prefill-produced first token from decode TPS;
    # the older fork includes it. Preserve native fields and add one common rule.
    n_steps=max(0,row['timings']['predicted_n']-1)
    row['decode_common_tokens_per_second']=1000*n_steps/row['timings']['predicted_ms'] if row['timings']['predicted_ms']>0 else None
    row['decode_observed_tokens_per_second']=n_steps/(ended-first) if first is not None and ended>first else None
    if workload=='quality' or 'expected' in prompts[workload]:
     expected={f'svc-{i:03d}':{'replicas':2+i%7,'timeout_ms':300+i%11*50,'retry_budget':i%4,'owner':f'team-{i%13}','deploy':f'rev-{9000+i}'} for i in [3,21,47,75,89]}
     expected=prompts[workload].get('expected',expected)
     try:row['quality_pass']=json.loads(text)==expected
     except:row['quality_pass']=False
    if 'expected_output' in prompts[workload]:
     row['quality_pass']=text.strip()==prompts[workload]['expected_output'].strip()
     row['quality_content_pass']=row['quality_pass']
     row['quality_exact_bytes_pass']=text.encode()==prompts[workload]['expected_output'].encode()
     row['quality_rule']='legacy quality_pass ignores outer whitespace; quality_exact_bytes_pass does not'
    (out/f'{workload}-{repeat}-smaps.txt').write_text(Path(f'/proc/{proc.pid}/smaps').read_text())
    row['memory_snapshot_kib']={}
    for line in Path(f'/proc/{proc.pid}/smaps_rollup').read_text().splitlines()[1:]:
     key,_,value=line.partition(':')
     if value.strip():row['memory_snapshot_kib'][key]=int(value.split()[0])
    row['thread_placement_snapshot']=[]
    for task in Path(f'/proc/{proc.pid}/task').iterdir():
     try:
      fields=(task/'stat').read_text().split(') ',1)[1].split(); status=(task/'status').read_text().splitlines()
      row['thread_placement_snapshot'].append({'tid':int(task.name),'cpu_ticks':int(fields[11])+int(fields[12]),'last_cpu':int(fields[36]),'allowed':next(x.split(':',1)[1].strip() for x in status if x.startswith('Cpus_allowed_list:'))})
     except (OSError,StopIteration):pass
    summary['requests'].append(row);(out/f'{workload}-{repeat}.json').write_text(json.dumps({'request':payload,'events':events,'result':row},indent=2));(out/'result.json').write_text(json.dumps(summary,indent=2))
    print(json.dumps({'run':name,'workload':workload,'rep':repeat,'ttft':row['ttft_seconds'],'timings':row['timings'],'quality':row.get('quality_pass')}),flush=True)
  if config.get('state_equivalence'):
   phase[0]='state-equivalence-diagnostic'
   from state_equivalence import run as state_equivalence
   summary['state_equivalence']=state_equivalence(post,prompts,out)
  if config.get('teacher_force'):
   phase[0]='teacher-force-diagnostic'
   from teacher_force import run as teacher_force
   summary['teacher_force']=teacher_force(post,prompts,EVID,out,config['teacher_force'],config.get('teacher_force_count',96),config.get('teacher_force_source_run'))
  if config.get('api_smoke'):
   from api_smoke import run as smoke
   summary['api_smoke']=smoke(post,args[args.index('--alias')+1])
  summary['status']='passed'
 except Exception as e:
  summary['status']='failed';summary['error']=str(e);print(json.dumps({'run':name,'error':str(e)}),flush=True)
 finally:
  phase[0]='stopping'
  if perf_proc and perf_proc.poll() is None:
   perf_proc.send_signal(signal.SIGINT)
   try:perf_proc.wait(timeout=10)
   except subprocess.TimeoutExpired:perf_proc.kill();perf_proc.wait()
  if perf_log:perf_log.close()

  if proc and proc.poll() is None:
   os.killpg(proc.pid,signal.SIGTERM)
   try:proc.wait(timeout=15)
   except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
  monitor_stop.set()
  if t.is_alive():t.join(timeout=4)
  log.close();summary['load_resources']=summary_samples('load');summary['peak_vram_mib']=max([s.get('vram_mib',0) for s in samples],default=0);summary['peak_rss_mib']=max([s.get('rss_mib',0) for s in samples],default=0);summary['exit_code']=proc.returncode if proc else None
  summary['peak_rss_hwm_mib']=max([s.get('rss_hwm_mib',0) for s in samples],default=0)
  summary['peak_process_vram_mib']=max([s['process_vram_mib'] for s in samples if 'process_vram_mib' in s],default=None)
  (out/'telemetry.json').write_text(json.dumps(samples));(out/'result.json').write_text(json.dumps(summary,indent=2));print(json.dumps({'run':name,'status':summary['status'],'load_seconds':summary.get('load_seconds'),'peak_vram_mib':summary['peak_vram_mib']}),flush=True)
 return summary
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('config');a=p.parse_args();config=json.loads(Path(a.config).read_text());run(config)
