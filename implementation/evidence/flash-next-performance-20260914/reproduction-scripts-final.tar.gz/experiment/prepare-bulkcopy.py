"""Avoid MoE routing readback for large prefill by copying all expert weights.

This changes transfer scheduling only: the same routing IDs still select the
same quantized experts in the unchanged GPU operation. Small batches use stock
sparse transfer. Build only when no timed inference is running.
"""
import difflib,hashlib,json,os,shlex,shutil,subprocess
from pathlib import Path
R=Path('/home/alex/Projects/flash-next-perf-20260914')
E=Path('/home/alex/Projects/AG1/implementation/evidence/flash-next-performance-20260914')
S=R/'unsloth-new-source/llama.cpp-b10909-mix-bea84f7';B=R/'build-new-ada'
O=R/'bulkcopy-overlay';D=R/'bundle-new-bulkcopy'
assert shutil.disk_usage(R).free>30*2**30
O.mkdir();D.mkdir()
for p in (B/'bin').iterdir():
    if p.name=='llama-server' or '.so' in p.name:
        if p.is_symlink():(D/p.name).symlink_to(os.readlink(p))
        elif p.is_file():shutil.copy2(p,D/p.name)
source=S/'ggml/src/ggml-backend.cpp';before=source.read_text()
needle='''                    ggml_backend_t ids_backend = split_backend;

                    // if the ids tensor is also an input of the split'''
assert before.count(needle)==1
after=before.replace(needle,'''                    ggml_backend_t ids_backend = split_backend;

                    // Large batches can touch nearly all experts. Copying the
                    // unchanged full tensor avoids a routing readback and host
                    // synchronization before transfer. Never alter expert IDs.
                    const char * bulk_env = getenv("AG1_FLASH_BULK_EXPERT_MIN_TOKENS");
                    const int bulk_min = bulk_env ? atoi(bulk_env) : 0;
                    if (bulk_min >= 256 && ids_tensor->ne[1] >= bulk_min &&
                            n_expert == 512 && ggml_is_contiguous(input) &&
                            ggml_nbytes(input) == ggml_nbytes(input_cpy)) {
                        ggml_backend_tensor_set_async(split_backend, input_cpy,
                                input->data, 0, ggml_nbytes(input));
                        continue;
                    }

                    // if the ids tensor is also an input of the split''',1)
patched=O/'ggml-backend.cpp';patched.write_text(after)
(E/'prefill-whole-expert-copy.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/ggml/src/ggml-backend.cpp',tofile='b/ggml/src/ggml-backend.cpp')))
commands=subprocess.check_output(['ninja','-C',str(B),'-t','commands','ggml-base'],text=True).splitlines()
obj='ggml/src/CMakeFiles/ggml-base.dir/ggml-backend.cpp.o'
cmd=shlex.split(next(c for c in commands if obj+' -c ' in c));cmd[cmd.index('-c')+1]=str(patched)
for flag,target in [('-o',O/'ggml-backend.cpp.o'),('-MF',O/'ggml-backend.cpp.o.d'),('-MT',O/'ggml-backend.cpp.o')]:cmd[cmd.index(flag)+1]=str(target)
line=next(c for c in commands if '-o bin/libggml-base.so.0.23.0 ' in c)
assert line.startswith(': && ') and line.endswith(' && :')
link=shlex.split(line[5:-5]);link[link.index(obj)]=str(O/'ggml-backend.cpp.o');link[link.index('-o')+1]=str(D/'libggml-base.so.0.23.0')
for i,arg in enumerate(link):
    if arg.startswith('-Wl,--dependency-file='):link[i]='-Wl,--dependency-file='+str(O/'link.d')
    if arg.startswith('-Wl,-rpath,'):link[i]='-Wl,-rpath,$ORIGIN'
manifest={'base_revision':'329b6160f513915f1c607dbfae3d5ce864a64a4f','base_source':str(S),'base_build':str(B),
          'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'modified_source':str(patched),
          'modified_source_sha256':hashlib.sha256(patched.read_bytes()).hexdigest(),
          'compile':cmd,'link':link,'cwd':str(B),'binary':str(D/'llama-server')}
(E/'bulkcopy-build-command.json').write_text(json.dumps(manifest,indent=2))
assert not (D/'libggml-base.so.0.23.0').is_symlink() and (D/'libggml-base.so.0.23.0').stat().st_nlink == 1, 'Refusing to overwrite a shared or linked library'
with (E/'bulkcopy-build.log').open('w') as log:
    subprocess.run(cmd,cwd=B,stdout=log,stderr=subprocess.STDOUT,check=True)
    subprocess.run(link,cwd=B,stdout=log,stderr=subprocess.STDOUT,check=True)
assert hashlib.sha256(source.read_bytes()).hexdigest()==manifest['source_sha256']
manifest['status']='built';manifest['library_sha256']=hashlib.sha256((D/'libggml-base.so.0.23.0').read_bytes()).hexdigest()
(E/'bulkcopy-build-result.json').write_text(json.dumps(manifest,indent=2))
