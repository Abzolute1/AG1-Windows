"""Explicit opt-in resume after the 2026-09-14 user-requested OS-switch pause.
Never start this merely because the goal remains active in thread metadata.
"""
import argparse,json,subprocess,time
from pathlib import Path
from bench import ROOT as R,EVID as E,run
p=argparse.ArgumentParser();p.add_argument('--resume-after-reboot',action='store_true');a=p.parse_args()
if not a.resume_after_reboot:p.error('Requires an explicit user instruction to resume, then --resume-after-reboot')
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit():continue
 try:exe=(proc/'exe').resolve(strict=True).name
 except OSError:continue
 assert exe not in ['llama-server','llama-bench','nvcc','ninja','cc1plus'],(proc.name,exe)
assert not (E/'user-pause-resume-started.json').exists(),'This continuation already started: inspect completed work and create a new targeted continuation instead of duplicating runs.'
(E/'user-pause-resume-started.json').write_text(json.dumps({'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}))
def launch(c):
 (R/(c['name']+'.json')).write_text(json.dumps(c,indent=2));result=run(c)
 assert result['status']=='passed',(c['name'],result.get('error'))
 return result
B=R/'build-new-ada/bin'
# Both arms are repeated after reboot so the completed pre-reboot control is
# not the only comparison across a changed machine/file-cache state.
for label,binary in [('base',B/'llama-server'),('candidate',R/'bundle-new-maskskip/llama-server')]:
 launch({'name':'maskskip-'+label+'-real-resume1','binary':str(binary),
  'workloads':['review','prose','edit','conversation'],'repetitions':3,'n_predict':256,
  'api_smoke':True,'teacher_force':['prose','edit'],'teacher_force_count':64})
for cycle,order in enumerate([['original','base','candidate'],['candidate','base','original']]):
 for label in order:
  c={'name':f'long80k-{label}-{cycle}','prepare_long':True,'workloads':['long80k'],
     'repetitions':1,'n_predict':768}
  if label!='original':c['binary']=str((B if label=='base' else R/'bundle-new-maskskip')/'llama-server')
  launch(c)
(E/'post-screen-investigation-done.json').write_text(json.dumps({'status':'finished','resumed_after_user_pause':True}))
for stage in ['further-source-screen','alternative-model-test']:
 assert not (E/(stage+'-done.json')).exists(),stage
 with (E/(stage+'-after-user-pause-console.log')).open('x') as log:
  result=subprocess.run(['python',str(R/(stage+'.py'))],stdout=log,stderr=subprocess.STDOUT)
 (E/(stage+'-after-user-pause-result.json')).write_text(json.dumps({'returncode':result.returncode}))
 if result.returncode:raise SystemExit(result.returncode)
(E/'user-pause-resume-screens-done.json').write_text(json.dumps({'status':'finished','final_validation_and_AG1_still_required':True}))
