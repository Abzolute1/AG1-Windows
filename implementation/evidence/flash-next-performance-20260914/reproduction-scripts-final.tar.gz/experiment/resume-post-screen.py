import json,os,statistics,struct,subprocess
from pathlib import Path
from bench import ROOT as R,EVID as E,run

def launch(c):
 (R/(c['name']+'.json')).write_text(json.dumps(c,indent=2));return run(c)
with (E/'turbo-followup-resume-console.log').open('w') as log:
 subprocess.run(['python',str(R/'resume-turbo-followup.py')],stdout=log,stderr=subprocess.STDOUT,check=True)
# Existing high-precision draft head only; the target model is unchanged.
mtp=Path('/home/alex/.lmstudio/models/unsloth/Qwen3.8-Flash-Next-MTP-GGUF/mtp-Qwen3.8-Flash-Next-shared-Q8_0.gguf')
assert mtp.is_file()
mtp_common={'--spec-type':'draft-mtp','--spec-draft-model':str(mtp),
 '--spec-draft-ngl':'99','--spec-draft-type-k':'q8_0','--spec-draft-type-v':'q8_0',
 '--spec-draft-n-min':'1','--verbosity':'4'}
for cpu in [46,48]:
 launch({'name':f'mtp-control-cpu{cpu}','flags':{'--n-cpu-moe':str(cpu)},
  'workloads':['prose','edit','reasoning'],'repetitions':2,'n_predict':256,'api_smoke':True})
 c={'name':f'mtp-q8-cpu{cpu}-max2','flags':{**mtp_common,'--n-cpu-moe':str(cpu),'--spec-draft-n-max':'2'},
    'workloads':['prose','edit','reasoning'],'repetitions':2,'n_predict':256,'api_smoke':True}
 result=launch(c)
 if result['status']=='passed':
  c={**c,'name':f'mtp-q8-cpu{cpu}-max4','flags':{**c['flags'],'--spec-draft-n-max':'4'}};launch(c)
  break

# Source overlay and independent kernel checks. No model is running here.
subprocess.run(['python',str(R/'prepare-maskskip.py')],check=True)
S=R/'unsloth-new-source/llama.cpp-b10909-mix-bea84f7';B=R/'build-new-ada/bin'
cmd=['g++-15','-O2','-std=c++17','-I'+str(S/'ggml/include'),str(R/'test-maskskip.cpp'),
     '-L'+str(B),'-lggml','-lggml-base','-ldl','-pthread','-Wl,-rpath,'+str(B),'-o',str(R/'test-maskskip')]
(E/'maskskip-fixture-build-command.json').write_text(json.dumps(cmd,indent=2))
with (E/'maskskip-fixture-build.log').open('w') as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
metrics={}
for cycle,order in enumerate([['base','candidate'],['candidate','base']]):
 for label in order:
  bundle=B if label=='base' else R/'bundle-new-maskskip'
  out=E/f'maskskip-fixture-{label}-{cycle}';out.mkdir(exist_ok=False)
  env={**os.environ,'LD_LIBRARY_PATH':str(bundle)}
  with (out/'stdout.jsonl').open('w') as stdout,(out/'stderr.log').open('w') as stderr:
   p=subprocess.run([str(R/'test-maskskip'),str(bundle),str(out)],env=env,stdout=stdout,stderr=stderr,timeout=900)
  assert p.returncode==0,(label,cycle,p.returncode)
  metrics[label,cycle]=[json.loads(x) for x in (out/'stdout.jsonl').read_text().splitlines() if x.startswith('{')]
comparisons=[]
for p in sorted((E/'maskskip-fixture-base-0').glob('*.f32')):
 ref=p.read_bytes();entry={'case':p.stem,'exact_outputs':True}
 for label,cycle in [('candidate',0),('candidate',1),('base',1)]:
  other=(E/f'maskskip-fixture-{label}-{cycle}'/p.name).read_bytes()
  entry['exact_outputs'] &= other==ref
  if other!=ref:
   a=struct.unpack('<'+'f'*(len(ref)//4),ref);b=struct.unpack('<'+'f'*(len(other)//4),other)
   entry[f'{label}-{cycle}-max-abs']=max(abs(x-y) for x,y in zip(a,b))
 for label in ['base','candidate']:
  entry[label+'_ms']=statistics.median(next(x['median_ms'] for x in metrics[label,c] if x['case']==p.stem) for c in [0,1])
 entry['speed_ratio']=entry['base_ms']/entry['candidate_ms'];comparisons.append(entry)
(E/'maskskip-fixture-results.json').write_text(json.dumps(comparisons,indent=2))
assert len(comparisons)==20 and all(x['exact_outputs'] for x in comparisons),'Masked-warp skip failed exact GPU output comparison'

# Full-model proof only if the isolated bottleneck improvement is substantial.
if next(x['speed_ratio'] for x in comparisons if x['case']=='83200-blocks')>1.10:
 for label,binary in [('base',str(B/'llama-server')),('candidate',str(R/'bundle-new-maskskip/llama-server'))]:
  launch({'name':'maskskip-'+label+'-real','binary':binary,'workloads':['review','prose','edit','conversation'],
          'repetitions':3,'n_predict':256,'api_smoke':True,'teacher_force':['prose','edit'],'teacher_force_count':64})
 for cycle,order in enumerate([['original','base','candidate'],['candidate','base','original']]):
  for label in order:
   c={'name':f'long80k-{label}-{cycle}','prepare_long':True,'workloads':['long80k'],'repetitions':1,'n_predict':768}
   if label!='original':c['binary']=str((B if label=='base' else R/'bundle-new-maskskip')/'llama-server')
   launch(c)
(E/'post-screen-investigation-done.json').write_text(json.dumps({'status':'finished'}))
