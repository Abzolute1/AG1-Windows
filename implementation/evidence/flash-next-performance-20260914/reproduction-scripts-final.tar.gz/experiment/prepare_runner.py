from pathlib import Path
import json
root=Path('/home/alex/Projects/flash-next-perf-20260914')
src=Path('/home/alex/Projects/llama-perf-20260914/bench.py').read_text()
src=src.replace("ROOT=Path('/home/alex/Projects/llama-perf-20260914')",f'ROOT=Path({str(root)!r})').replace("evidence/llama-performance-20260914'","evidence/flash-next-performance-20260914'").replace('PORT=18436','PORT=18438')
a=src.index('def build_prompts():');b=src.index('\ndef run(config):',a)
src=src[:a]+'''def build_prompts():
 from workloads import build
 return build(post,EVID/'prompts.json')
'''+src[b:]
src=src.replace('>300:raise TimeoutError(\'model load exceeded 300s\')','>900:raise TimeoutError(\'model load exceeded 900s\')')
src=src.replace("row['minor_faults']=int(stat[7]);row['major_faults']=int(stat[9])", """row['minor_faults']=int(stat[7]);row['major_faults']=int(stat[9])
     for line in Path(f'/proc/{proc.pid}/io').read_text().splitlines():
      k,v=line.split(':');row['io_'+k]=int(v)
     row['diskstats_sda']=[int(x) for x in next(l for l in Path('/proc/diskstats').read_text().splitlines() if l.split()[2]=='sda').split()[3:]]""")
src=src.replace("maps=Path(f'/proc/{proc.pid}/maps').read_text()", """readiness=[]
  for _ in range(10):
   h=time.monotonic();get('/health');readiness.append(time.monotonic()-h)
  summary['warm_health_seconds']=readiness
  maps=Path(f'/proc/{proc.pid}/maps').read_text()
  (out/'smaps-ready.txt').write_text(Path(f'/proc/{proc.pid}/smaps').read_text())""")
src=src.replace("for workload in config.get('workloads',['short','medium']):", "for workload in config.get('workloads',['review','prose']):")
src=src.replace("payload['n_predict']=2048", "payload['n_predict']=prompts[workload].get('max_tokens',2048)")
src=src.replace("    if config.get('diagnostic_n_probs'):", """    payload.update(prompts[workload].get('payload',{}))
    payload.update(config.get('payload',{}))
    if workload=='conversation':
     payload['cache_prompt']=True
     # Prefill a persistent conversation, then append a new user turn.
     warm={**payload,'prompt':prompts[workload]['prefix_tokens'],'stream':False,'n_predict':1}
     post('/completion',warm)
    if config.get('diagnostic_n_probs'):""")
src=src.replace("    row['memory_snapshot_kib']={}","""    (out/f'{workload}-{repeat}-smaps.txt').write_text(Path(f'/proc/{proc.pid}/smaps').read_text())
    row['memory_snapshot_kib']={}""")
(root/'bench.py').write_text(src)
(root/'baseline.json').write_text(json.dumps({'name':'baseline-01','workloads':['review','edit','prose','tool','conversation','repetitive','reasoning','long'],'repetitions':3,'n_predict':256},indent=2))
