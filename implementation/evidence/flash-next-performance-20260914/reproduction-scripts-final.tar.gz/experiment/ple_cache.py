import os,ctypes,time
from pathlib import Path

def residency(path,evict=False):
 # Inspect/evict only this read-only PLE shard; never drop global caches.
 p=Path(path);fd=os.open(p,os.O_RDONLY);size=p.stat().st_size
 libc=ctypes.CDLL(None,use_errno=True);libc.mmap.restype=ctypes.c_void_p
 libc.mmap.argtypes=[ctypes.c_void_p,ctypes.c_size_t,ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_long]
 libc.mincore.argtypes=[ctypes.c_void_p,ctypes.c_size_t,ctypes.c_void_p]
 libc.munmap.argtypes=[ctypes.c_void_p,ctypes.c_size_t]
 def count():
  addr=libc.mmap(None,size,1,1,fd,0)
  if addr==ctypes.c_void_p(-1).value:raise OSError(ctypes.get_errno(),'mmap residency')
  try:
   pages=(size+4095)//4096;vec=(ctypes.c_ubyte*pages)()
   if libc.mincore(addr,size,vec)!=0:raise OSError(ctypes.get_errno(),'mincore')
   # count in native bytes rather than a Python loop over9 million pages.
   resident=bytes(vec).translate(bytes(i & 1 for i in range(256))).count(b'\x01')
   return {'pages':pages,'resident_pages':resident,'resident_mib':resident*4096/2**20,'fraction':resident/pages}
  finally:libc.munmap(addr,size)
 try:
  before=count()
  if evict:os.posix_fadvise(fd,0,0,os.POSIX_FADV_DONTNEED)
  after=count() if evict else before
  if evict and after['fraction']>.02:raise RuntimeError('PLE eviction incomplete: '+str(after))
  return {'path':str(p),'evicted':evict,'before':before,'after':after,'scope':'OS page cache; SSD/controller caches uncontrolled'}
 finally:os.close(fd)
