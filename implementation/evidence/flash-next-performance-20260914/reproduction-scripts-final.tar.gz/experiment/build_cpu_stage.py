import json,time,subprocess,shutil,hashlib
from pathlib import Path
R=Path('/home/alex/Projects/flash-next-perf-20260914');E=Path('/home/alex/Projects/AG1/implementation/evidence/flash-next-performance-20260914')
last=E/'runs/batch2048-cpu44/result.json'
while True:
 try:
  if json.loads(last.read_text()).get('status'):break
 except (FileNotFoundError,json.JSONDecodeError):pass
 time.sleep(5)
# All timed inference in the first screen has ended. Prepare tools and isolated builds.
p=R/'prepare_perf.py';p.write_text(p.read_text().replace('https://fastly.mirror.pkgbuild.com/extra/os/x86_64/','https://archive.archlinux.org/packages/p/perf/'))
subprocess.run(['python',str(p)],check=True)
old=R/'original-source/llama.cpp-b10715-mix-86bd2d3'
patched=R/'source-original-ple-parallel'
if not patched.exists():shutil.copytree(old,patched,symlinks=True)
f=patched/'ggml/src/ggml-cpu/ggml-cpu.c';s=f.read_text()
before='''        case GGML_OP_GET_ROWS:
        case GGML_OP_SET_ROWS:
'''
after='''        case GGML_OP_GET_ROWS:
            {
                // Large lazy embeddings benefit from concurrent independent page reads.
                const struct ggml_tensor * table = node->src[0];
                const int64_t rows = ggml_nelements(node->src[1]);
                n_tasks = ggml_is_quantized(table->type) && ggml_nbytes(table) > (size_t) 4*1024*1024*1024 && rows >= 1024
                        ? MIN(n_threads, (int) (rows/256)) : 1;
            } break;
        case GGML_OP_SET_ROWS:
'''
assert s.count(before)==1 or after in s
s=s.replace(before,after);f.write_text(s)
diff=subprocess.run(['diff','-u',str(old/'ggml/src/ggml-cpu/ggml-cpu.c'),str(f)],text=True,capture_output=True)
(E/'ple-parallel.patch').write_text(diff.stdout)
for name,source in [('original-native',old),('original-ple-parallel',patched)]:
 build=R/('build-'+name);log=E/(name+'-build.log')
 args=['cmake','-S',str(source),'-B',str(build),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DGGML_BACKEND_DL=ON','-DGGML_NATIVE=OFF','-DCMAKE_C_FLAGS=-march=znver3','-DCMAKE_CXX_FLAGS=-march=znver3','-DGGML_SSE42=ON','-DGGML_AVX=ON','-DGGML_AVX2=ON','-DGGML_BMI2=ON','-DGGML_FMA=ON','-DGGML_F16C=ON','-DGGML_CPU_ALL_VARIANTS=OFF','-DGGML_CUDA=OFF','-DLLAMA_BUILD_COMMON=OFF','-DLLAMA_BUILD_TESTS=OFF','-DLLAMA_BUILD_TOOLS=OFF','-DLLAMA_BUILD_SERVER=OFF','-DLLAMA_BUILD_EXAMPLES=OFF','-DLLAMA_BUILD_APP=OFF']
 with log.open('w') as out:
  subprocess.run(args,stdout=out,stderr=subprocess.STDOUT,check=True)
  subprocess.run(['cmake','--build',str(build),'--target','ggml-cpu','-j','12'],stdout=out,stderr=subprocess.STDOUT,check=True)
 bundle=R/('bundle-'+name);bundle.mkdir(exist_ok=True)
 production=Path('/home/alex/Projects/llama-cpp-qwen4exp-mtp-b10715')
 for original in production.iterdir():
  if original.name.startswith('libggml-cpu'):continue
  if original.is_symlink():
   if not (bundle/original.name).exists():(bundle/original.name).symlink_to(original.readlink())
  elif original.is_file() and ('.so' in original.name or original.name=='llama-server'):shutil.copy2(original,bundle/original.name)
 cpu=next((build/'bin').glob('libggml-cpu.so'));shutil.copy2(cpu,bundle/cpu.name)
 (E/(name+'-build-command.json')).write_text(json.dumps({'configure':args,'target':'ggml-cpu','source':str(source),'bundle':str(bundle),'cpu_sha256':hashlib.file_digest(cpu.open('rb'),'sha256').hexdigest()},indent=2))
 print('Built isolated CPU backend',name,flush=True)
(E/'cpu-build-stage-done.json').write_text(json.dumps({'status':'built'}))
