import json,statistics,shlex
from pathlib import Path
R=Path('/home/alex/Projects/flash-next-perf-20260914');E=Path('/home/alex/Projects/AG1/implementation/evidence/flash-next-performance-20260914')
base=json.loads((E/'original-launch.json').read_text());run=json.loads((E/'runs/baseline-01/result.json').read_text())
lines=['# Qwen3.8 Flash-Next performance investigation','',
'**Working report — investigation and final validation are still in progress. No production cutover has been made.**','',
'## Preserved original','',
'- Machine: Ryzen9 5900X, RTX4080 16GB,64GB DDR4-3600, Arch Linux. Model storage is a SATA Samsung870EVO; it is not NVMe.',
'- Original runtime: Unsloth b10715-mix-86bd2d3, build10715, source `92cedc8679d145902ead3f006258e8672eac11e6`. Runtime reports0.3.0-dev. GNU11.4, CUDA13.3, multi-architecture CUDA build including sm89; selected CPU backend haswell.',
'- Original executable: `'+base['command']+'`.',
'- AG1 installed release: `'+base['installed_ag1']+'`. The profile and sealed launch capture are inventoried in `protected-before.json`; the authoritative argv/environment is `original-launch.json`.',
'- Exact model: `'+base['model_id']+'`,28shards,79.098GiB. All original hashes matched the sealed capture and subsequently the AtomicChat published hashes.',
'- Requested context90,000 (allocated90,112), Flash Attention on, Q8_0 K/V, one slot, batch/microbatch1,024/1,024,12decode/24batch threads with strict0–11/0–23 affinity, poll100, CPU MoE42, automatic GPU layer offload, fit off. No speculative drafting was configured originally.',
'', '```bash',shlex.join([base['command'],*base['args']]),'```','',
'`CUDA_PATH=/opt/cuda`; `LD_LIBRARY_PATH` points to the original executable directory. No experimental GGML/OMP overrides were inherited by the baseline. See the captured environment for exact values.','',
'## What “n-gram” means in this model','',
'Flash-Next’s learned PLE subsystem performs bigram/trigram-dependent table lookup as part of the target model computation. Its Q5_1 table occupies35.763GiB and emits16rows/token. This is separate from the runtime’s optional ngram-mod speculative drafting. PLE has no draft acceptance rate. Runtime speculation proposes tokens, then uses the unchanged target model to verify them. An additional existing Q8 MTP draft head is being evaluated separately.',
'',
'The GGUF filename is not an accurate inventory of tensor quantization. Actual tensors include48MXFP4 down-expert tensors,72IQ1_M and24IQ2_S gate/up-expert tensors,666Q8_0 tensors,388F32 tensors,24BF16 tensors and oneF16 tensor, plus the Q5_1 PLE table. No IQ4_XS tensor is present. Quantization types were read directly from the GGUF headers. Cache eligibility for existing IQ1_M experts changes placement only; it does not re-quantize weights.',
'', '## Baseline measurements','',
'Three repetitions per workload,24native inference requests in baseline-01. Fresh prompt cache is disabled except the explicitly warmed conversation fixture. Fixed greedy sampling: temperature0,top_k1,top_p1,min_p0,repeat_penalty1,seed777. Frozen prompts and token IDs live in `prompts.json`. Prompt-cache warmth and OS file-cache warmth are distinct. The first review had slower page-cache behavior; the table reports all-three medians, not its best run.','',
'| Workload | Input tokens | Prefill tok/s | Decode tok/s | TTFT s | Response s |','|---|---:|---:|---:|---:|---:|']
labels={'long':'A: fresh long ingestion','review':'B: code review','edit':'C: exact source edit','prose':'D: ordinary prose','tool':'E: tool JSON fixture','conversation':'F: cached conversation','repetitive':'G: repeated code rewrite','reasoning':'H: free-form reasoning'}
for w in ['long','review','edit','prose','tool','conversation','repetitive','reasoning']:
 rows=[r for r in run['requests'] if r['workload']==w]
 if not rows:continue
 med=lambda key:statistics.median(key(r) for r in rows)
 lines.append(f"| {labels[w]} | {rows[0]['prompt_tokens']} | {med(lambda r:r['timings']['prompt_per_second']):.2f} | {med(lambda r:(r['timings']['predicted_n']-1)*1000/r['timings']['predicted_ms']):.2f} | {med(lambda r:r['ttft_seconds']):.3f} | {med(lambda r:r['wall_seconds']):.3f} |")
lines += ['',
'Conversation prefill speed measures only the newly evaluated suffix, not all4,243tokens. The short tool JSON fixture is supplemented by native function-call validation. Native edit outputs commonly omit the final newline; content agreement is not strict file-byte correctness. Short256-token screens do not satisfy full500-word review/prose requests; those require the final quality pass.',
'',
f"Initial observed model load: {run['load_seconds']:.3f}s; this was not a cold-boot/drop-caches test. Later original warm loads were around3.4–5.4s. Baseline peak total GPU memory: {run['peak_vram_mib']:.0f}MiB, including desktop use. Process RSS is predominantly reclaimable mmap pages; it must not be equated with private committed RAM. Raw CPU/GPU utilization, clocks, power, RAM, faults and I/O are preserved per request.",
'', '## Measurement interpretation','',
'- Compare native prefill and common decode rates separately. Original native decode counts predicted_n−1; the older fork counts predicted_n. `RUNS.md` normalizes both to `(predicted_n−1)/predicted_ms`. Raw timings remain unchanged.',
'- TTFT is request-to-first SSE text. Response duration is request-to-stream completion. Health endpoint latency is only a warm readiness proxy; actual AG1 manual-load/readiness and task latency are separate checks.',
'- Resource samples occur about every0.5s. CPU utilization100% means one logical CPU. Early VRAM readings include desktop use; later runs also record process-specific NVML memory.',
'- Instrumented CUPTI/perf results locate bottlenecks and are excluded from speed comparisons. The stale-marker build-overlap arm and interrupted CPU-flat arm are explicitly excluded in `invalid-runs.json`.',
'- Same-file experiments keep model, quantization, context, sampling and other non-variable settings fixed. The optional higher-precision alternative is a separate model comparison.',
'', '## Measured bottlenecks','',
'Original review prefill moved roughly161GiB of host-to-device data for6,250input tokens. CUPTI summed H2D copies to10.10s and the host cudaMemcpyAsync API to13.34s. These overlapping instrumented activities are not additive wall-time components. IQ1_M dequantization had85,268launches but only0.506s summed GPU duration. Transfer/synchronization work therefore deserves priority over a kernel rewrite based on launch count alone.',
'',
'Original decode heavily exercised CPU expert dot products and OpenMP waiting while GPU utilization was around42%. The measured CPU sample shares included MXFP4/IQ1_M/IQ2_S arithmetic and substantial waiting. Prefill and decode therefore need different solutions; making larger GPU batches fit by putting more experts in RAM can help one and harm the other.',
'', '## Experiments and current status','',
'`RUNS.md` is the complete generated run catalog, with separate workload medians and ranges, failures, exclusions and configuration links. `STATUS.md` records checkpoints. `kernel-opportunities.md` and `turbo-source-review.md` explain the source hypotheses. `REPRODUCTION.md` describes the protocol. All source overlays remain in separately named experiment directories.',
'',
'Final matched winners, full-answer quality checks, near-limit context validation, actual AG1 comparison, final preservation audit and the final recommendation are pending. Promising screen results are not yet a production recommendation.',
'', '## Revisions under test','',
'| Family | Pinned source revision |','|---|---|',
'| Original Unsloth |92cedc8679d145902ead3f006258e8672eac11e6|',
'| Newer Unsloth b10909-mix-bea84f7 |329b6160f513915f1c607dbfae3d5ce864a64a4f|',
'| Upstream llama.cpp |97e4ca73582084f2751767f80c86237483ecc381|',
'| TheTom TurboQuant fork |407f3237bfb3eeaff61546797de3d8c1a96be748|',
'',
'The newer source families were built separately for sm89. Runtime build strings from archive builds may lack git metadata; the pinned source hashes and build manifests are authoritative. The old production source/installations were never used as mutable experiment trees.',
'', '## Reproduction and rollback','',
'Experiment root: `/home/alex/Projects/flash-next-perf-20260914`. Each run has `launch.json`, raw request/response files, telemetry, server logs and result.json. Build manifests and patches identify modified translation units and exact compilation/link commands. Re-run into fresh directories; the runner refuses to overwrite existing results. Do not combine binaries/libraries across incompatible context-parameter ABIs.',
'',
'No global paths or profiles were changed, so rollback currently means stopping an owned experimental process and launching AG1 with its preserved original profile. No model re-quantization or lossy routing/layer/attention changes were adopted. Final file/hash preservation proof will be recorded after timed work is complete.','']
p=E/'REPORT.md';assert not p.exists();p.write_text('\n'.join(lines))
