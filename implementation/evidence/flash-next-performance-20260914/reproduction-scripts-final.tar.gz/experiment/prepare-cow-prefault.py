"""Isolated parallel prefault experiment; run only in an idle build window."""
import difflib,hashlib,json,os,shlex,shutil,subprocess
from pathlib import Path
R=Path('/home/alex/Projects/flash-next-perf-20260914')
E=Path('/home/alex/Projects/AG1/implementation/evidence/flash-next-performance-20260914')
S=R/'source-new-cow';B=R/'build-new-cow';O=R/'cow-prefault-overlay';D=R/'bundle-new-cow-prefault'
assert shutil.disk_usage(R).free>30*2**30
O.mkdir();shutil.copytree(R/'bundle-new-cow',D,symlinks=True)
source=S/'src/llama-model.cpp';before=source.read_text()
after=before.replace('#include <vector>','#include <vector>\n#include <thread>\n#include <cstdlib>',1)
needle='            const int result = register_cow((void *) first, last - first, 1u);'
assert after.count(needle)==1
after=after.replace(needle,'''            // This mapping is MAP_PRIVATE over an O_RDONLY file descriptor.
            // Write the same byte to disjoint pages to materialize private COW
            // pages before serial driver pinning; original file bytes cannot change.
            const char * prefault_env = std::getenv("AG1_FLASH_COW_PREFAULT_THREADS");
            const int prefault_threads = prefault_env ? std::max(0, std::min(24, std::atoi(prefault_env))) : 0;
            if (prefault_threads > 0) {
                const size_t page_size = (size_t) sysconf(_SC_PAGESIZE);
                const size_t pages = (last - first) / page_size;
                std::vector<std::thread> workers;
                workers.reserve(prefault_threads);
                for (int worker = 0; worker < prefault_threads; ++worker) {
                    workers.emplace_back([=]() {
                        const size_t begin = pages * worker / prefault_threads;
                        const size_t end = pages * (worker + 1) / prefault_threads;
                        for (size_t page = begin; page < end; ++page) {
                            volatile unsigned char * address = reinterpret_cast<volatile unsigned char *>(first + page * page_size);
                            const unsigned char value = *address;
                            *address = value;
                        }
                    });
                }
                for (auto & worker : workers) worker.join();
            }
''' + needle,1)
patched=O/'llama-model.cpp';patched.write_text(after)
(E/'cow-parallel-prefault.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/src/llama-model.cpp',tofile='b/src/llama-model.cpp')))
commands=subprocess.check_output(['ninja','-C',str(B),'-t','commands','llama'],text=True).splitlines()
obj='src/CMakeFiles/llama.dir/llama-model.cpp.o'
compile=shlex.split(next(c for c in commands if obj+' -c ' in c))
compile[compile.index('-c')+1]=str(patched)
for flag,target in [('-o',O/'llama-model.cpp.o'),('-MF',O/'llama-model.cpp.o.d'),('-MT',O/'llama-model.cpp.o')]:compile[compile.index(flag)+1]=str(target)
line=next(c for c in commands if '-o bin/libllama.so.0.4.0 ' in c)
assert line.startswith(': && ') and line.endswith(' && :')
link=shlex.split(line[5:-5]);link[link.index(obj)]=str(O/'llama-model.cpp.o');link[link.index('-o')+1]=str(D/'libllama.so.0.4.0')
for i,arg in enumerate(link):
    if arg.startswith('-Wl,--dependency-file='):link[i]='-Wl,--dependency-file='+str(O/'link.d')
    if arg.startswith('-Wl,-rpath,'):link[i]='-Wl,-rpath,$ORIGIN'
manifest={'base_source':str(S),'base_build':str(B),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
          'modified_source':str(patched),'modified_source_sha256':hashlib.sha256(patched.read_bytes()).hexdigest(),
          'compile':compile,'link':link,'cwd':str(B),'binary':str(D/'llama-server')}
(E/'cow-prefault-build-command.json').write_text(json.dumps(manifest,indent=2))
assert not (D/'libllama.so.0.4.0').is_symlink() and (D/'libllama.so.0.4.0').stat().st_nlink == 1, 'Refusing to overwrite a shared or linked library'
with (E/'cow-prefault-build.log').open('w') as log:
    subprocess.run(compile,cwd=B,stdout=log,stderr=subprocess.STDOUT,check=True)
    subprocess.run(link,cwd=B,stdout=log,stderr=subprocess.STDOUT,check=True)
assert hashlib.sha256(source.read_bytes()).hexdigest()==manifest['source_sha256']
manifest['status']='built';manifest['library_sha256']=hashlib.sha256((D/'libllama.so.0.4.0').read_bytes()).hexdigest()
(E/'cow-prefault-build-result.json').write_text(json.dumps(manifest,indent=2))
