import json
from bench import run,EVID,ROOT
turbo=json.loads((EVID/'turbo-build-result.json').read_text())
if turbo['status']=='built':
 for mode,cpu,floor in [('off',42,None),('off',48,None),('4480',48,None),('6000',48,None),('6000',48,256)]:
  name='turbo-cache-'+mode+'-cpu'+str(cpu)+(('-min'+str(floor)) if floor else '')
  env={'TURBO_AUTO_ASYMMETRIC':'0','TURBO_LAYER_ADAPTIVE':'0'}
  if floor:env['GGML_CUDA_MOE_CACHE_MIN_EXPERT_KB']=str(floor)
  c={'name':name,'binary':turbo['binary'],'flags':{'--moe-cache':mode,'--n-cpu-moe':str(cpu),'--verbosity':'4'},'environment':env,'repetitions':3,'workloads':['review','prose','edit'],'n_predict':256,'api_smoke':True}
  (ROOT/(c['name']+'.json')).write_text(json.dumps(c,indent=2));run(c)
(EVID/'turbo-screen-done.json').write_text(json.dumps({'status':'finished'}))
