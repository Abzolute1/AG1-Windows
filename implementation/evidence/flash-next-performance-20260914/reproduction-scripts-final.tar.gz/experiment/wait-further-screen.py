import json,subprocess,time
from pathlib import Path
R=Path('/home/alex/Projects/flash-next-perf-20260914')
E=Path('/home/alex/Projects/AG1/implementation/evidence/flash-next-performance-20260914')
parent=1813009;started=time.time()
while True:
 try:state=Path(f'/proc/{parent}/status').read_text()
 except FileNotFoundError:state='State:\tZ'
 if 'State:\tZ' in state:break
 time.sleep(3)
marker=E/'post-screen-investigation-done.json'
assert marker.exists() and marker.stat().st_mtime>started,'Prior investigation exited without a fresh completion marker; no further work started'
with (E/'further-source-screen-console.log').open('w') as log:
 result=subprocess.run(['python',str(R/'further-source-screen.py')],stdout=log,stderr=subprocess.STDOUT)
(E/'further-source-screen-dispatch-result.json').write_text(json.dumps({'returncode':result.returncode}))
raise SystemExit(result.returncode)
