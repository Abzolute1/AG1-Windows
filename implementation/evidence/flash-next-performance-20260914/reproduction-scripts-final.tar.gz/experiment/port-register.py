from pathlib import Path
import shutil,difflib
R=Path('/home/alex/Projects/flash-next-perf-20260914');E=Path('/home/alex/Projects/AG1/implementation/evidence/flash-next-performance-20260914')
base=R/'unsloth-new-source/llama.cpp-b10909-mix-bea84f7'
register=R/'source-new-register'
if not register.exists():shutil.copytree(base,register)
# Keep the direct-read port scoped to the target architecture and server.
direct=R/'source-new-direct'
for f in ['src/models/gemma4.cpp','tools/llama-bench/llama-bench.cpp']:
 shutil.copy2(base/f,direct/f)
p=direct/'src/models/models.h';s=p.read_text();s=s.replace('\n    // --lazy-mode on-direct: pread() the lazy per-layer table rows\n    // host-side instead of faulting them in through the mmap; see gemma4.cpp\n    const llama_lazy_reader * ple_reader = nullptr;\n','');p.write_text(s)
# The upstream pool's KV estimate charges every recurrent layer and repeats an
# allocation already made before sched_reserve. An explicit experimental budget
# leaves baseline behavior unchanged unless selected for this hybrid model.
p=R/'source-new-pool/src/llama-context.cpp';s=p.read_text();needle='    LLAMA_LOG_INFO("%s: expert pool budget %.2f GiB'
pos=s.index(needle)
s=s[:pos]+'''    if (const char * limit = std::getenv("AG1_FLASH_POOL_MIB")) {
        const size_t requested = std::stoull(limit) * 1024ull * 1024ull;
        pool_budget = std::min(requested, dev_free > pool_rail ? dev_free - pool_rail : 0);
        LLAMA_LOG_INFO("%s: explicit experimental pool budget %.2f MiB\\n", __func__, pool_budget / 1048576.0);
    }

'''+s[pos:];p.write_text(s)
for name in ['register','pool','direct']:
 p=R/('source-new-'+name)/'src/llama-model.cpp';original=p.read_text();s=original
 s=s.replace('#include <vector>','#include <vector>\n#ifdef __linux__\n#include <unistd.h>\n#endif')
 s=s.replace('    ~impl() = default;','''    ~impl() {
        if (unregister_host) {
            for (void * address : registered_host) {
                unregister_host(address);
            }
        }
    }

    void (*unregister_host)(void *) = nullptr;
    std::vector<void *> registered_host;''',1)
 needle='    // load tensor data\n'
 s=s.replace(needle,'''    std::vector<std::pair<uintptr_t, uintptr_t>> register_ranges;
#ifdef __linux__
    if (ml.use_mmap && std::getenv("AG1_FLASH_REGISTER_MMAP")) {
        const uintptr_t page = (uintptr_t) sysconf(_SC_PAGESIZE);
        for (const auto & [key, context] : ml.ctx_map) {
            (void) key;
            (void) context;
        }
        for (const auto & [ctx, buffers] : ctx_buf_maps) {
            bool lazy = false;
            for (ggml_tensor * tensor = ggml_get_first_tensor(ctx); tensor; tensor = ggml_get_next_tensor(ctx, tensor)) {
                // Lazy PLE must remain pageable: its 35.8 GiB table cannot be pinned.
                if (std::string(tensor->name).find("per_layer_token_embd") != std::string::npos) {
                    lazy = true;
                    break;
                }
            }
            if (lazy) continue;
            for (const auto & [idx, runs] : buffers) {
                (void) idx;
                for (ggml_backend_buffer_t buffer : runs) {
                    if (!ggml_backend_buffer_is_host(buffer)) continue;
                    const uintptr_t begin = (uintptr_t) ggml_backend_buffer_get_base(buffer);
                    const uintptr_t end = begin + ggml_backend_buffer_get_size(buffer);
                    if (end > begin) register_ranges.emplace_back(begin & ~(page - 1), (end + page - 1) & ~(page - 1));
                }
            }
        }
    }
#endif

'''+needle,1)
 # No dependency on a private loader field.
 s=s.replace('        for (const auto & [key, context] : ml.ctx_map) {\n            (void) key;\n            (void) context;\n        }\n','')
 needle='    if (use_mmap_buffer) {\n        for (auto & mapping : ml.mappings) {'
 addition='''    if (!register_ranges.empty()) {
        auto reg = ggml_backend_reg_by_name("CUDA");
        auto register_host = reg ? reinterpret_cast<bool (*)(void *, size_t)>(
                ggml_backend_reg_get_proc_address(reg, "ggml_backend_register_host_buffer")) : nullptr;
        auto unregister_host = reg ? reinterpret_cast<void (*)(void *)>(
                ggml_backend_reg_get_proc_address(reg, "ggml_backend_unregister_host_buffer")) : nullptr;
        if (register_host && unregister_host) {
            std::sort(register_ranges.begin(), register_ranges.end());
            std::vector<std::pair<uintptr_t, uintptr_t>> merged;
            for (const auto & range : register_ranges) {
                if (!merged.empty() && range.first <= merged.back().second) {
                    merged.back().second = std::max(merged.back().second, range.second);
                } else {
                    merged.push_back(range);
                }
            }
            size_t total = 0;
            const int64_t begin_us = ggml_time_us();
            for (const auto & [first, last] : merged) {
                if (register_host((void *) first, last - first)) {
                    pimpl->registered_host.push_back((void *) first);
                    total += last - first;
                } else {
                    LLAMA_LOG_WARN("%s: host registration failed for %.2f MiB\\n", __func__, (last - first) / 1048576.0);
                }
            }
            pimpl->unregister_host = unregister_host;
            LLAMA_LOG_INFO("%s: registered %.2f MiB mapped host weights in %.3f s (%zu ranges)\\n",
                    __func__, total / 1048576.0, (ggml_time_us() - begin_us) / 1e6, pimpl->registered_host.size());
        }
    }

'''
 assert needle in s;s=s.replace(needle,addition+needle,1);p.write_text(s)
 (E/(name+'-registration.patch')).write_text(''.join(difflib.unified_diff(original.splitlines(True),s.splitlines(True),fromfile='a/src/llama-model.cpp',tofile='b/src/llama-model.cpp')))
