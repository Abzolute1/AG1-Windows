from pathlib import Path
R=Path('/home/alex/Projects/flash-next-perf-20260914')
s=Path('/home/alex/Projects/llama-perf-20260914/cpu-mmid-single/test-mmid-single.cpp').read_text()
s=s.replace('c.partner_input ? GGML_TYPE_Q8_K : GGML_TYPE_F32','c.partner_input ? ggml_get_type_traits_cpu(c.weight)->vec_dot_type : GGML_TYPE_F32')
s=s.replace('std::vector<float> values(static_cast<size_t>(t->ne[0]));','std::vector<float> values(static_cast<size_t>(t->ne[0]));\n    std::vector<float> importance(static_cast<size_t>(t->ne[0]), 1.0f);')
s=s.replace('0, 1, t->ne[0], nullptr);','0, 1, t->ne[0], importance.data());')
a=s.index('        const std::vector<Case> cases = {');b=s.index('        size_t completed',a)
s=s[:a]+"""        const std::vector<Case> cases = {
            {"mxfp4-down-512", GGML_TYPE_MXFP4, 640, 2560, 512, 10, 1, 10, false, false, false, {1,6,12}},
            {"iq1m-up-512", GGML_TYPE_IQ1_M, 2560, 640, 512, 10, 1, 1, false, false, false, {1,6,12}},
            {"iq2s-up-512", GGML_TYPE_IQ2_S, 2560, 640, 512, 10, 1, 1, false, false, false, {1,6,12}},
            {"mxfp4-tail", GGML_TYPE_MXFP4, 640, 65, 16, 10, 1, 10, true, true, false, {3,12}},
            {"iq1m-tail", GGML_TYPE_IQ1_M, 256, 65, 16, 10, 1, 10, true, true, false, {3,12}},
            {"iq2s-tail", GGML_TYPE_IQ2_S, 256, 65, 16, 10, 1, 1, true, false, false, {3,12}},
            {"empty-workers", GGML_TYPE_MXFP4, 640, 1, 16, 1, 1, 1, true, false, false, {1,12}},
            {"two-tokens", GGML_TYPE_IQ1_M, 256, 64, 16, 10, 2, 10, true, false, false, {3}},
            {"prefill", GGML_TYPE_IQ2_S, 256, 64, 16, 10, 16, 1, false, false, false, {6}},
            {"reference", GGML_TYPE_MXFP4, 640, 64, 16, 10, 1, 10, false, false, true, {3}},
            {"other-quant", GGML_TYPE_Q8_0, 512, 64, 16, 10, 1, 10, false, false, false, {3}},
        };
"""+s[b:]
(R/'test-flash-mmid.cpp').write_text(s)
