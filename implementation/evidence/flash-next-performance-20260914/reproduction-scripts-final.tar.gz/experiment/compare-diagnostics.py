"""Summarize teacher-forced distributions without pretending top32 is full KL."""
import json,math,statistics
from pathlib import Path
E=Path('/home/alex/Projects/AG1/implementation/evidence/flash-next-performance-20260914')
base=json.loads((E/'runs/state-equivalence-original/teacher-force.json').read_text());results=[]
def probs(row):return {x['id']:x['logprob'] for x in row['probabilities'][0]['top_logprobs']}
for path in sorted((E/'runs').glob('*/teacher-force.json')):
 d=json.loads(path.read_text());summary={'run':path.parent.name,'workloads':{}}
 for name,rows in d.items():
  if name not in base:continue
  comparisons=[]
  for a,b in zip(base[name],rows):
   assert a['position']==b['position'] and a['gold_token']==b['gold_token']
   pa,pb=probs(a),probs(b);common=pa.keys()&pb.keys();gold=a['gold_token']
   # Common explicitly reported tokens plus one bucket for all other tokens.
   # KL of this coarsened partition is a lower bound, not full-vocabulary KL.
   qa=[math.exp(pa[t]) for t in common];qb=[math.exp(pb[t]) for t in common]
   qa.append(max(1e-15,1-sum(qa)));qb.append(max(1e-15,1-sum(qb)))
   kl=sum(p*math.log(p/max(q,1e-15)) for p,q in zip(qa,qb) if p>0)
   comparisons.append({'position':a['position'],'greedy_matches':a['tokens']==b['tokens'],
                       'common_top_tokens':len(common),'coarsened_kl_original_to_candidate':max(0,kl),
                       'gold_nll_delta':pa[gold]-pb[gold] if gold in common else None,
                       'gold_reported_by_both':gold in common})
  nll=[x['gold_nll_delta'] for x in comparisons if x['gold_nll_delta'] is not None]
  summary['workloads'][name]={'positions':len(comparisons),'greedy_matches':sum(x['greedy_matches'] for x in comparisons),
    'mean_coarsened_kl':statistics.mean(x['coarsened_kl_original_to_candidate'] for x in comparisons),
    'mean_gold_nll_delta_where_reported':statistics.mean(nll) if nll else None,
    'gold_nll_count':len(nll),'comparisons':comparisons}
 results.append(summary)
(E/'teacher-force-comparison.json').write_text(json.dumps({'reference':'state-equivalence-original','scope':'Diagnostic32-position common prefix per workload. Not perplexity or an intelligence score; full vocabulary logits were not recorded.','results':results},indent=2))
for r in results:print(r['run'],{w:{k:v for k,v in x.items() if k!='comparisons'} for w,x in r['workloads'].items()})
