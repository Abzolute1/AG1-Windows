from pathlib import Path
import subprocess,json,shutil,hashlib
R=Path('/home/alex/Projects/flash-next-perf-20260914');E=Path('/home/alex/Projects/AG1/implementation/evidence/flash-next-performance-20260914')
for name in ['register','pool','direct']:
 source=R/('source-new-'+name);build=R/('build-new-'+name)
 args=['cmake','-S',str(source),'-B',str(build),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DGGML_BACKEND_DL=ON','-DGGML_NATIVE=OFF','-DCMAKE_C_FLAGS=-march=znver3','-DCMAKE_CXX_FLAGS=-march=znver3','-DGGML_SSE42=ON','-DGGML_AVX=ON','-DGGML_AVX2=ON','-DGGML_BMI2=ON','-DGGML_FMA=ON','-DGGML_F16C=ON','-DGGML_CPU_ALL_VARIANTS=OFF','-DGGML_CUDA=OFF','-DLLAMA_BUILD_TESTS=OFF','-DLLAMA_BUILD_TOOLS=ON','-DLLAMA_BUILD_SERVER=ON','-DLLAMA_BUILD_EXAMPLES=OFF','-DLLAMA_BUILD_APP=OFF','-DLLAMA_OPENSSL=OFF','-DLLAMA_CURL=OFF']
 with (E/(name+'-source-build.log')).open('w') as log:
  p=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT)
  if p.returncode==0:p=subprocess.run(['cmake','--build',str(build),'--target','llama-server','-j','12'],stdout=log,stderr=subprocess.STDOUT)
 result={'configure':args,'rc':p.returncode}
 if p.returncode==0:
  bundle=R/('bundle-new-'+name);bundle.mkdir(exist_ok=True)
  for f in (build/'bin').iterdir():
   if f.is_file() and ('.so' in f.name or f.name=='llama-server'):shutil.copy2(f,bundle/f.name,follow_symlinks=True)
  # No CUDA source changed. Retain the exact newer release CUDA backend.
  for f in (R/'unsloth-new-bundle').iterdir():
   if f.is_file() and (f.name.startswith('libggml-cuda') or f.name.startswith(('libcudart','libcublas','libnv'))):shutil.copy2(f,bundle/f.name,follow_symlinks=True)
  result['files']={p.name:hashlib.file_digest(p.open('rb'),'sha256').hexdigest() for p in bundle.iterdir() if p.is_file()}
 (E/(name+'-source-build.json')).write_text(json.dumps(result,indent=2));print(name,p.returncode,flush=True)
(E/'source-stage-done.json').write_text(json.dumps({'status':'finished'}))
