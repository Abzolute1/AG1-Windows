"""Pause only our waiting dispatcher, then build/test between model runs."""
import json, os, signal, subprocess, time
from pathlib import Path
from bench import ROOT as R, EVID as E, run

def find_script(name):
    found=[]
    for p in Path('/proc').iterdir():
        if not p.name.isdigit(): continue
        try: args=(p/'cmdline').read_bytes().split(b'\0')
        except OSError: continue
        if str(R/name).encode() in args: found.append(int(p.name))
    assert len(found)==1, (name,found)
    return found[0]

parent=find_script('post-build-screen.py')
child=find_script('turbo-screen.py')
assert f'PPid:\t{parent}' in Path(f'/proc/{child}/status').read_text()
record={'dispatcher_pid':parent,'screen_pid':child,'status':'waiting-for-stock-screen',
        'reason':'Build and test isolated lazy-PLE/graph-reuse repair between timed inference processes.'}
os.kill(parent,signal.SIGSTOP)
(E/'turbo-ple-checkpoint.json').write_text(json.dumps(record,indent=2))
try:
    started=time.monotonic();started_wall=time.time()
    while True:
        if time.monotonic()-started>7200: raise TimeoutError('Stock fork screen exceeded checkpoint deadline')
        try: status=Path(f'/proc/{child}/status').read_text()
        except FileNotFoundError: status='State:\tZ'
        if 'State:\tZ' in status:
            marker=E/'turbo-screen-done.json'
            assert marker.exists() and marker.stat().st_mtime>started_wall, 'Screen exited without a fresh completion marker'
            break
        time.sleep(3)
    # The completion marker is written after all owned servers have exited.
    record['status']='preparing-overlay'
    (E/'turbo-ple-checkpoint.json').write_text(json.dumps(record,indent=2))
    if not (E/'turbo-ple-build-result.json').exists():
        subprocess.run(['python',str(R/'prepare-turbo-ple.py')],check=True)
    env={**os.environ,'LD_LIBRARY_PATH':str(R/'build-turbo-latest/bin')}
    with (E/'turbo-cache-unit-tests.log').open('w') as log:
        test=subprocess.run([str(R/'build-turbo-latest/bin/test-moe-cache')],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=900)
    (E/'turbo-cache-unit-tests.json').write_text(json.dumps({'exit_code':test.returncode}))
    assert test.returncode==0, 'Hybrid cache unit tests failed; investigate before further cache inference'
    binary=str(R/'bundle-turbo-ple/llama-server')
    # Repeat the unmodified control: the earlier first arm overlapped an
    # erroneously admitted build and is excluded from timing comparisons.
    run({'name':'turbo-stock-cpu42-clean','binary':str(R/'build-turbo-latest/bin/llama-server'),
         'environment':{'TURBO_AUTO_ASYMMETRIC':'0','TURBO_LAYER_ADAPTIVE':'0'},
         'flags':{'--moe-cache':'off','--n-cpu-moe':'42','--verbosity':'4'},
         'repetitions':3,'workloads':['review','prose','edit','conversation'],'n_predict':256,'api_smoke':True})
    for label,reuse,cpu,cache,floor in [
        ('lazy-only-cpu42',False,42,'off',None),
        ('lazy-reuse-cpu42',True,42,'off',None),
        ('lazy-reuse-cpu48',True,48,'off',None),
        ('lazy-reuse-cache6000',True,48,'6000',None),
        ('lazy-reuse-cache6000-min256',True,48,'6000',256),
    ]:
        env={'TURBO_AUTO_ASYMMETRIC':'0','TURBO_LAYER_ADAPTIVE':'0','AG1_FLASH_PLE_LAZY':'1','AG1_FLASH_PLE_REUSE':str(int(reuse))}
        if floor: env['GGML_CUDA_MOE_CACHE_MIN_EXPERT_KB']=str(floor)
        c={'name':'turbo-ple-'+label,'binary':binary,'environment':env,
           'flags':{'--moe-cache':cache,'--n-cpu-moe':str(cpu),'--verbosity':'4'},
           'repetitions':3,'workloads':['review','prose','edit','conversation'],'n_predict':256,'api_smoke':True}
        (R/(c['name']+'.json')).write_text(json.dumps(c,indent=2))
        result=run(c)
        if result['status']!='passed': raise RuntimeError('Overlay failed: '+c['name'])
    run({'name':'original-after-turbo','repetitions':3,'workloads':['review','prose','edit','conversation'],'n_predict':256,'api_smoke':True})
    record['status']='completed'
except Exception as e:
    record['status']='failed';record['error']=repr(e)
    raise
finally:
    (E/'turbo-ple-checkpoint.json').write_text(json.dumps(record,indent=2))
    os.kill(parent,signal.SIGCONT)
