import json,time,subprocess
from bench import run,EVID,ROOT
while not (EVID/'fifth-preparation-done.json').exists() or not (EVID/'turbo-preparation-done.json').exists():time.sleep(3)
assert json.loads((EVID/'turbo-preparation-done.json').read_text())['status']=='built', 'Fork build must pass before timed tests'
def do(c):
 c.setdefault('workloads',['review','prose','edit']);c.setdefault('repetitions',2);c.setdefault('n_predict',256);c['api_smoke']=True
 (ROOT/(c['name']+'.json')).write_text(json.dumps(c,indent=2));return run(c)
with (EVID/'turbo-screen-console.log').open('w') as f:subprocess.run(['python',str(ROOT/'turbo-screen.py')],stdout=f,stderr=subprocess.STDOUT,check=True)
do({'name':'new-cpu-flat-verified','binary':str(ROOT/'bundle-new-cpu-flat/llama-server')})
do({'name':'new-graph-opt','binary':str(ROOT/'unsloth-new-bundle/llama-server'),'environment':{'GGML_CUDA_GRAPH_OPT':'1'}})
# Independent fresh-process speculation arms before further placement tuning.
with (EVID/'spec-screen-console.log').open('w') as f:subprocess.run(['python',str(ROOT/'spec-screen.py')],stdout=f,stderr=subprocess.STDOUT,check=True)
for label in ['upstream-ada','new-ada']:
 result=json.loads((EVID/(label+'-build-result.json')).read_text())
 if result['status']=='built':do({'name':label,'binary':result['binary']})
do({'name':'new-no-graphs','binary':str(ROOT/'unsloth-new-bundle/llama-server'),'environment':{'GGML_CUDA_DISABLE_GRAPHS':'1'}})
for c in json.loads((ROOT/'placement-configs.json').read_text()):do(c)
for size,budget in [(64,5400),(80,6600)]:
 c={'name':f'new-pool-efficient{size}-stage','binary':str(ROOT/'bundle-new-pool-efficient/llama-server'),
    'flags':{'--n-cpu-moe':'48','--moe-expert-cache':str(size)},
    'environment':{'AG1_FLASH_STAGE':'1','AG1_FLASH_POOL_MIB':str(budget)}}
 c['environment']['AG1_FLASH_POOL_TRACE']=str(EVID/'runs'/c['name']/'pool-counts.txt');do(c)
(EVID/'post-build-screen-done.json').write_text(json.dumps({'status':'finished'}))
