from pathlib import Path
import shutil,difflib
R=Path('/home/alex/Projects/flash-next-perf-20260914');E=Path('/home/alex/Projects/AG1/implementation/evidence/flash-next-performance-20260914')
base=R/'source-new-register';dst=R/'source-new-cow';shutil.copytree(base,dst)
p=dst/'src/llama-mmap.cpp';s=p.read_text();needle='        int flags = MAP_SHARED;';assert s.count(needle)==1;s=s.replace(needle,needle+'\n        // A writable registration must never target a shared file mapping.\n        if (getenv("AG1_FLASH_REGISTER_COW")) flags = MAP_PRIVATE;',1);p.write_text(s)
p=dst/'src/llama-model.cpp';s=p.read_text();s=s.replace('#include <unistd.h>','#include <unistd.h>\n#include <dlfcn.h>\n#include <sys/mman.h>')
s=s.replace('    ~impl() {','''    ~impl() {
#ifdef __linux__
        if (unregister_cow) {
            for (void * address : cow_host) unregister_cow(address);
        }
        if (cuda_driver_handle) dlclose(cuda_driver_handle);
#endif''',1)
s=s.replace('    void (*unregister_host)(void *) = nullptr;','''    int (*unregister_cow)(void *) = nullptr;
    void * cuda_driver_handle = nullptr;
    std::vector<void *> cow_host;
    void (*unregister_host)(void *) = nullptr;''',1)
s=s.replace('if (ml.use_mmap && std::getenv("AG1_FLASH_REGISTER_MMAP")) {','if (ml.use_mmap && (std::getenv("AG1_FLASH_REGISTER_MMAP") || std::getenv("AG1_FLASH_REGISTER_COW"))) {',1)
needle='    if (!register_ranges.empty()) {'
addition='''#ifdef __linux__
    if (!register_ranges.empty() && std::getenv("AG1_FLASH_REGISTER_COW")) {
        // llama_mmap used MAP_PRIVATE for this mode. The driver may create private
        // pages while pinning; it cannot write the original read-only-opened file.
        pimpl->cuda_driver_handle = dlopen("libcuda.so.1", RTLD_NOW | RTLD_LOCAL);
        auto register_cow = pimpl->cuda_driver_handle ? reinterpret_cast<int (*)(void *, size_t, unsigned)>(
                dlsym(pimpl->cuda_driver_handle, "cuMemHostRegister_v2")) : nullptr;
        pimpl->unregister_cow = pimpl->cuda_driver_handle ? reinterpret_cast<int (*)(void *)>(
                dlsym(pimpl->cuda_driver_handle, "cuMemHostUnregister")) : nullptr;
        if (!register_cow || !pimpl->unregister_cow) throw std::runtime_error("CUDA driver registration entry points unavailable");
        std::sort(register_ranges.begin(), register_ranges.end());
        std::vector<std::pair<uintptr_t, uintptr_t>> merged;
        for (const auto & range : register_ranges) {
            if (!merged.empty() && range.first <= merged.back().second) merged.back().second = std::max(merged.back().second, range.second);
            else merged.push_back(range);
        }
        size_t total = 0;
        const int64_t begin_us = ggml_time_us();
        for (const auto & [first, last] : merged) {
            if (mprotect((void *) first, last - first, PROT_READ | PROT_WRITE)) throw std::runtime_error("private host mapping mprotect failed");
            const int result = register_cow((void *) first, last - first, 1u);
            if (result) {
                mprotect((void *) first, last - first, PROT_READ);
                throw std::runtime_error(format("CUDA private mapping registration failed: %d", result));
            }
            pimpl->cow_host.push_back((void *) first);
            total += last - first;
        }
        LLAMA_LOG_INFO("%s: registered %.2f MiB private host weights in %.3f s (%zu ranges)\\n", __func__,
                total / 1048576.0, (ggml_time_us() - begin_us) / 1e6, pimpl->cow_host.size());
        register_ranges.clear();
    }
#endif

'''
assert s.count(needle)==1;s=s.replace(needle,addition+needle,1);p.write_text(s)
parts=[]
for f in ['src/llama-mmap.cpp','src/llama-model.cpp']:
 parts+=difflib.unified_diff((base/f).read_text().splitlines(True),(dst/f).read_text().splitlines(True),fromfile='a/'+f,tofile='b/'+f)
(E/'private-cow-registration.patch').write_text(''.join(parts))
