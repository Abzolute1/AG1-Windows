"""Lossless opt-in proposal backoff for repeatedly unprofitable n-gram matches.

The target sampler and verification are unchanged. Only whether another draft
is proposed changes. Based on measured edit~99% acceptance versus repeated-edit
~50-70% acceptance, which was slower than ordinary decode on this machine.
"""
import difflib,hashlib,json,os,shlex,shutil,subprocess
from pathlib import Path
R=Path('/home/alex/Projects/flash-next-perf-20260914')
E=Path('/home/alex/Projects/AG1/implementation/evidence/flash-next-performance-20260914')
S=R/'unsloth-new-source/llama.cpp-b10909-mix-bea84f7';B=R/'build-new-ada'
O=R/'ngram-adaptive-overlay';D=R/'bundle-new-ngram-adaptive'
assert shutil.disk_usage(R).free>30*2**30
O.mkdir();shutil.copytree(R/'bundle-new-ngram-rs',D,symlinks=True)
source=S/'common/speculative.cpp';before=source.read_text()
start=before.index('struct common_speculative_impl_ngram_mod :')
end=before.index('struct common_speculative_impl_ngram_cache :',start)
body=before[start:end]
body=body.replace('    const bool verbose;', '    const bool verbose;\n    const bool adaptive;\n    const size_t cooldown_tokens;',1)
body=body.replace('        int n_low = 0;', '''        int n_low = 0;
        size_t observed_prompt_len = 0;
        size_t cooldown_until = 0;
        size_t proposed_window = 0;
        size_t accepted_window = 0;''',1)
needle='        , verbose(std::getenv("LLAMA_TRACE") != nullptr) {'
assert body.count(needle)==1
body=body.replace(needle,'''        , verbose(std::getenv("LLAMA_TRACE") != nullptr)
        , adaptive([]() { const char * v = std::getenv("AG1_FLASH_NGRAM_ADAPTIVE"); return v && v[0] == '1' && v[1] == '\\0'; }())
        , cooldown_tokens([]() { const char * v = std::getenv("AG1_FLASH_NGRAM_COOLDOWN"); return (size_t) (v ? std::max(32, std::min(8192, std::atoi(v))) : 1024); }()) {''',1)
needle='        sinfo.i_last = 0;\n        sinfo.n_draft_last = 0;'
assert body.count(needle)==1
body=body.replace(needle,needle+'''
        sinfo.observed_prompt_len = prompt.size();
        sinfo.cooldown_until = 0;
        sinfo.proposed_window = sinfo.accepted_window = 0;
        if (adaptive) sinfo.n_low = 0;''',1)
needle='        const size_t cur_len = prompt.size();'
body=body.replace(needle,needle+'\n        sinfo.observed_prompt_len = cur_len;',1)
needle='        result.resize(n + params.n_max);'
assert body.count(needle)==1
body=body.replace(needle,'''        // Keep learning the accepted prompt during cooldown; omit only drafting.
        if (adaptive && cur_len < sinfo.cooldown_until) {
            result.clear();
            return;
        }

''' + needle,1)
needle='        // compute acceptance fraction if we have a recorded draft length'
assert body.count(needle)==1
body=body.replace(needle,'''        if (adaptive && sinfo.n_draft_last > 0) {
            sinfo.proposed_window += sinfo.n_draft_last;
            sinfo.accepted_window += std::min<size_t>(n_accepted, sinfo.n_draft_last);
            if (sinfo.proposed_window >= 32) {
                const double rate = (double) sinfo.accepted_window / sinfo.proposed_window;
                if (rate < 0.85) {
                    sinfo.cooldown_until = sinfo.observed_prompt_len + cooldown_tokens;
                    SPC_INF("ngram adaptive pause: seq=%d accepted=%zu proposed=%zu until=%zu\\n",
                            seq_id, sinfo.accepted_window, sinfo.proposed_window, sinfo.cooldown_until);
                }
                sinfo.proposed_window = sinfo.accepted_window = 0;
            }
        }

''' + needle,1)
after=before[:start]+body+before[end:]
patched=O/'speculative.cpp';patched.write_text(after)
(E/'ngram-adaptive-backoff.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/common/speculative.cpp',tofile='b/common/speculative.cpp')))
commands=subprocess.check_output(['ninja','-C',str(B),'-t','commands','llama-server'],text=True).splitlines()
obj='common/CMakeFiles/llama-common.dir/speculative.cpp.o'
cmd=shlex.split(next(c for c in commands if obj+' -c ' in c));cmd[cmd.index('-c')+1]=str(patched)
for flag,target in [('-o',O/'speculative.cpp.o'),('-MF',O/'speculative.cpp.o.d'),('-MT',O/'speculative.cpp.o')]:cmd[cmd.index(flag)+1]=str(target)
cmd+=['-I'+str(S/'common')]
parent=json.loads((E/'ngram-rs-build-command.json').read_text())
link=parent['link'].copy()
link[link.index(obj)]=str(O/'speculative.cpp.o')
link[link.index('-o')+1]=str(D/'libllama-common.so.0.4.0')
for i,arg in enumerate(link):
    if arg.startswith('-Wl,--dependency-file='):link[i]='-Wl,--dependency-file='+str(O/'link.d')
manifest={'base_revision':parent['base_revision'],'base_source':str(S),'base_build':str(B),
          'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'modified_source':str(patched),
          'modified_source_sha256':hashlib.sha256(patched.read_bytes()).hexdigest(),
          'compile':cmd,
          'link':link,'cwd':str(B),'binary':str(D/'llama-server'),'optional_dependency':'ngram-recurrent-snapshots.patch (disabled unless explicitly enabled)'}
(E/'ngram-adaptive-build-command.json').write_text(json.dumps(manifest,indent=2))
assert not (D/'libllama-common.so.0.4.0').is_symlink() and (D/'libllama-common.so.0.4.0').stat().st_nlink == 1, 'Refusing to overwrite a shared or linked library'
with (E/'ngram-adaptive-build.log').open('w') as log:
    subprocess.run(cmd,cwd=B,stdout=log,stderr=subprocess.STDOUT,check=True)
    subprocess.run(link,cwd=B,stdout=log,stderr=subprocess.STDOUT,check=True)
assert hashlib.sha256(source.read_bytes()).hexdigest()==manifest['source_sha256']
manifest['status']='built';manifest['library_sha256']=hashlib.sha256((D/'libllama-common.so.0.4.0').read_bytes()).hexdigest()
(E/'ngram-adaptive-build-result.json').write_text(json.dumps(manifest,indent=2))
