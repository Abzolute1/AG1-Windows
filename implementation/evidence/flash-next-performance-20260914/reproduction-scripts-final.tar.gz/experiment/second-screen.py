import time,json
from pathlib import Path
from bench import run,EVID,ROOT
while not (EVID/'cpu-build-stage-done.json').exists():time.sleep(5)
configs=[
 {'name':'original-api','workloads':['prose'],'repetitions':1,'api_smoke':True},
 {'name':'newer-stock','binary':str(ROOT/'unsloth-new-bundle/llama-server'),'api_smoke':True},
 {'name':'newer-pinned','binary':str(ROOT/'unsloth-new-bundle/llama-server'),'flags':{'--load-mode':'none','--lazy-mode':'on'},'api_smoke':True},
 {'name':'native-original','binary':str(ROOT/'bundle-original-native/llama-server'),'api_smoke':True},
 {'name':'parallel-original','binary':str(ROOT/'bundle-original-ple-parallel/llama-server'),'api_smoke':True},
]
for c in configs:
 c.setdefault('workloads',['review','prose','edit']);c.setdefault('repetitions',2);c['n_predict']=256
 (ROOT/(c['name']+'.json')).write_text(json.dumps(c,indent=2));run(c)
for cycle in range(3):
 # Balanced order; independent cold OS-PLE starts, retained eager-weight file cache.
 for arm in (['original-native','original-ple-parallel'] if cycle%2==0 else ['original-ple-parallel','original-native']):
  c={'name':f'cold-ple-{cycle}-{arm}','binary':str(ROOT/f'bundle-{arm}/llama-server'),'workloads':['review'],'repetitions':1,'n_predict':256,'evict_ple_before_load':True}
  (ROOT/(c['name']+'.json')).write_text(json.dumps(c,indent=2));run(c)
(EVID/'second-screen-done.json').write_text(json.dumps({'status':'finished'}))
