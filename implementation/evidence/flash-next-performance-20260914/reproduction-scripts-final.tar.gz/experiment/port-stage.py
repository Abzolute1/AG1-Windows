from pathlib import Path
import shutil,difflib
R=Path('/home/alex/Projects/flash-next-perf-20260914');E=Path('/home/alex/Projects/AG1/implementation/evidence/flash-next-performance-20260914')
base=R/'source-new-pool';dst=R/'source-new-stage';shutil.copytree(base,dst)
p=dst/'ggml/src/ggml-backend.cpp';old=p.read_text();s=old.replace('#include <algorithm>','#include <algorithm>\n#include <array>\n#include <memory>')
s=s.replace('struct ggml_backend_sched_expert_pool {',(R/'host-stage-class.cpp').read_text()+'\nstruct ggml_backend_sched_expert_pool {',1)
s=s.replace('struct ggml_backend_sched {','struct ggml_backend_sched {\n    std::unordered_map<ggml_backend_t, std::unique_ptr<ggml_sched_host_stage>> host_stages;\n    bool host_stage_enabled = getenv("AG1_FLASH_STAGE") != nullptr;\n',1)
needle='static int ggml_backend_sched_backend_id(ggml_backend_sched_t sched, ggml_backend_t backend) {'
s=s.replace(needle,'''static bool ggml_backend_sched_stage_copy(ggml_backend_sched_t sched, ggml_backend_t backend,
        const void * src, ggml_tensor * dst, size_t offset, size_t size) {
    if (!sched->host_stage_enabled) return false;
    auto & stage = sched->host_stages[backend];
    if (!stage) stage = std::make_unique<ggml_sched_host_stage>();
    return stage->copy(backend, src, dst, offset, size);
}

'''+needle,1)
needle='''        ggml_backend_tensor_set_async(split_backend, ep.pool,
            (const uint8_t *) ep.w->data + (size_t) e * ep.expert_size,
            (size_t) slot * ep.expert_size,
            ep.expert_size);'''
replacement='''        const void * source = (const uint8_t *) ep.w->data + (size_t) e * ep.expert_size;
        if (!ggml_backend_sched_stage_copy(sched, split_backend, source, ep.pool,
                (size_t) slot * ep.expert_size, ep.expert_size)) {
            ggml_backend_tensor_set_async(split_backend, ep.pool, source,
                    (size_t) slot * ep.expert_size, ep.expert_size);
        }'''
assert s.count(needle)==1;s=s.replace(needle,replacement)
needle='''                        ggml_backend_tensor_set_async(split_backend,
                            input_cpy,
                            (const uint8_t *)input->data + expert_offset, expert_offset,'''
replacement='''                        if (ggml_backend_sched_stage_copy(sched, split_backend,
                                (const uint8_t *) input->data + expert_offset, input_cpy,
                                expert_offset, expert_size_copy + padding_end)) {
                            return;
                        }
                        ggml_backend_tensor_set_async(split_backend,
                            input_cpy,
                            (const uint8_t *)input->data + expert_offset, expert_offset,'''
assert s.count(needle)==1;s=s.replace(needle,replacement);p.write_text(s)
(E/'bounded-host-stage.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='a/ggml/src/ggml-backend.cpp',tofile='b/ggml/src/ggml-backend.cpp')))
