import hashlib,json,random
from pathlib import Path

def build(post,path):
 if path.exists():return json.loads(path.read_text())
 repo=Path('/home/alex/Projects/AG1')
 def task(prompt,system='Answer directly and accurately using the supplied information. Do not include private reasoning.',**kw):
  return {'messages':[{'role':'system','content':system},{'role':'user','content':prompt}],**kw}
 files=[]
 for name in ['product/crates/ag1-platform/src/llama/lifecycle.rs','product/crates/ag1-platform/src/client/model_loading.rs','product/apps/desktop/src/ModelLoadControl.tsx']:
  content=(repo/name).read_text();files.append({'path':name,'content':content,'sha256':hashlib.sha256(content.encode()).hexdigest()})
 review='Review the following AG1 implementation. Explain cancellation, scheduler admission, runtime ownership, readiness, and progress reporting. Cite visible code precisely and distinguish assumptions about absent dependencies. Give a detailed review of at least 500 words.\n\n'+'\n\n'.join('FILE '+f['path']+'\n'+f['content'] for f in files)
 original=files[-1]['content']
 assert '"Waiting for model slot"' in original
 exact=original.replace('"Waiting for model slot"','"Waiting for GPU availability"')
 # Varied paragraphs avoid measuring a tiny repeated PLE working set.
 rng=random.Random(380914)
 topics=['connection reuse','deadline propagation','queue backpressure','transaction isolation','token verification','cache invalidation','stream cancellation','request admission','buffer lifetime','storage durability','scheduler fairness','error propagation']
 notes=[]
 for i in range(280):
  t=topics[i%len(topics)];budget=rng.randrange(50,9000);owner=rng.choice(['Amina','Jonas','Mei','Priya','Tomas','Elsa','Noah','Zara'])
  notes.append(f'Record {i:04d}: {owner} reviewed {t} in component {rng.randrange(100000,999999)}. The latency budget is {budget} ms and the verified revision is {rng.getrandbits(48):012x}. '+rng.choice([
   'The worker must preserve input order while releasing resources when cancellation arrives. An earlier implementation waited on an obsolete event and leaked a permit.',
   'A failed write must report its durability state explicitly. Retrying an ambiguous transaction without an idempotency key can duplicate an externally visible operation.',
   'Batching improves throughput only when independent requests are available. A partially filled batch must not wait indefinitely for another caller.',
   'The cache stores immutable values keyed by the complete configuration digest. Concurrent readers may share storage, but eviction must respect in-flight references.',
   'The measured tail latency exceeded its budget during a deployment. Investigation found lock contention rather than arithmetic throughput to be the immediate bottleneck.',
   'An asynchronous copy requires an event before the source buffer is reused. Pinned staging buffers remain bounded and ownership follows completion rather than enqueue time.'
  ]))
 tasks={
  'review':task(review,files=files,category='B'),
  'edit':task('Replace the string literal "Waiting for model slot" with "Waiting for GPU availability" in this file. Return the entire updated file, changing nothing else.\n\n'+original,system='Edit precisely. Return only the full requested source file, without fences, explanation, or extra whitespace.',expected_output=exact,max_tokens=2600,category='C'),
  'prose':task('Write a clear 500-word explanation for a new colleague of how deadline budgets, retries, cancellation, and idempotency interact in a distributed service. Include two concrete examples and avoid unsupported claims.',category='D'),
  'tool':task('A user asks to read lines 40 through 80 of src/cache.rs. Return exactly the JSON call object for read_file with arguments path, start_line, and end_line. No other text.',system='You choose a tool call. Return only valid JSON.',expected={'name':'read_file','arguments':{'path':'src/cache.rs','start_line':40,'end_line':80}},category='E',payload={'n_predict':128}),
  'conversation':task('Operational notes from earlier discussion:\n'+'\n'.join(notes[:55])+'\nSummarize the next investigation steps in detail.',category='F'),
  'repetitive':task('Return this source exactly except change every occurrence of delay_ms=100 to delay_ms=80. Return only the full file.\n\n'+'\n'.join(f'def retry_{i:02d}(client, key, delay_ms=100):\n    return client.fetch(key, timeout_ms=500, delay_ms=delay_ms)\n' for i in range(12)),system='You copy source accurately. Output only the requested file.',category='G'),
  'reasoning':task('Design a safe recovery protocol for a desktop application that may crash between accepting an edit, writing its journal, replacing a file, and showing success. The filesystem offers atomic rename but no transaction spanning the journal and edited file. Explain a concrete state machine, replay rules, cancellation races, and which failures remain ambiguous. Work through crashes at each boundary. Give at least 500 words.',category='H'),
  'long':task('Read this complete engineering notebook. Return only JSON with the exact latency budget, owner, and revision for records 0003, 0091, 0177, and 0275. Use keys "0003", "0091", "0177", "0275"; each value has budget_ms (integer), owner (string), revision (string).\n\n'+'\n'.join(notes),system='Extract facts exactly from the supplied notebook. Return only the specified JSON.',category='A')
 }
 import re
 tasks['long']['expected']={}
 for i in [3,91,177,275]:
  m=re.search(r': (\w+) reviewed.*budget is (\d+) ms.*revision is ([0-9a-f]+)',notes[i]);tasks['long']['expected'][f'{i:04d}']={'owner':m[1],'budget_ms':int(m[2]),'revision':m[3]}
 src='\n'.join(f'def retry_{i:02d}(client, key, delay_ms=100):\n    return client.fetch(key, timeout_ms=500, delay_ms=delay_ms)\n' for i in range(12))
 tasks['repetitive']['expected_output']=src.replace('delay_ms=100','delay_ms=80');tasks['repetitive']['max_tokens']=1400
 for key,v in tasks.items():
  if key=='conversation':
   v['messages'] += [{'role':'assistant','content':'We should verify cancellation ownership, bounded queues, safe retries, and durable recovery using controlled failure cases.'},{'role':'user','content':'Now give a concrete test plan covering those failure cases, expected observations, and success criteria. Be detailed.'}]
  v['prompt']=post('/apply-template',{'messages':v['messages'],'chat_template_kwargs':{'enable_thinking':False}})['prompt']
  v['tokens']=post('/tokenize',{'content':v['prompt'],'add_special':False})['tokens']
  v['sha256']=hashlib.sha256(v['prompt'].encode()).hexdigest()
  if key=='conversation':
   # An actual serialized prefix shared with the final conversation, no template ambiguity.
   v['prefix_tokens']=v['tokens'][:-65]
 path.write_text(json.dumps(tasks,indent=2))
 print('Frozen workloads '+json.dumps({k:len(v['tokens']) for k,v in tasks.items()}),flush=True)
 return tasks
