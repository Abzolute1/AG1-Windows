"""Build a source overlay against the exact completed fork's read-only objects.

Run only between inference sessions. No stock source/object/library is modified.
The two opt-in switches separate lazy loading from graph reuse in one build.
"""
import difflib, hashlib, json, os, shlex, shutil, subprocess
from pathlib import Path

R = Path('/home/alex/Projects/flash-next-perf-20260914')
E = Path('/home/alex/Projects/AG1/implementation/evidence/flash-next-performance-20260914')
S = Path(json.loads((E/'turbo-source-manifest.json').read_text())['source'])
B = R/'build-turbo-latest'
O = R/'turbo-ple-overlay'
D = R/'bundle-turbo-ple'
assert shutil.disk_usage(R).free > 30*2**30
O.mkdir(exist_ok=False)
D.mkdir(exist_ok=False)
source = S/'src/models/qwen4exp.cpp'
before = source.read_text()
after = before.replace('#include <cinttypes>', '''#include <cinttypes>
#include <cstdlib>

// Isolated Flash-Next experiment: no change unless explicitly enabled.
static bool flash_ple_experiment(const char * name) {
    const char * value = std::getenv(name);
    return value && value[0] == '1' && value[1] == '\\0';
}''', 1)
needle = '{ hparams.ple_head_dim, ple_rows }, 0);'
assert after.count(needle) == 1
after = after.replace(needle, '{ hparams.ple_head_dim, ple_rows }, flash_ple_experiment("AG1_FLASH_PLE_LAZY") ? TENSOR_READ_LAZY : 0);')
start = after.index('class llm_graph_input_ple :')
needle = '    void set_input(const llama_ubatch * ubatch) override;'
pos = after.index(needle, start) + len(needle)
after = after[:pos] + '''

    bool can_reuse(const llm_graph_params & params) override {
        if (!flash_ple_experiment("AG1_FLASH_PLE_REUSE")) {
            return false;
        }
        // Refresh the current memory-context pointer on every reuse check,
        // matching the lifetime contract of the other graph inputs.
        mctx = static_cast<const llama_memory_hybrid_idx_context *>(params.mctx);
        return rows->ne[0] == (int64_t) pmodel.hparams.ple_n_heads * params.ubatch.n_tokens;
    }
''' + after[pos:]
patched = O/'qwen4exp.cpp'
patched.write_text(after)
(E/'turbo-ple-lazy-reuse.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True), fromfile='a/src/models/qwen4exp.cpp', tofile='b/src/models/qwen4exp.cpp')))

# Copy the stock bundle as independent files; leave its build and source intact.
for p in (B/'bin').iterdir():
    if p.name == 'llama-server' or '.so' in p.name:
        if p.is_symlink(): (D/p.name).symlink_to(os.readlink(p))
        elif p.is_file(): shutil.copy2(p, D/p.name)

commands = subprocess.check_output(['ninja','-C',str(B),'-t','commands','llama'], text=True).splitlines()
object_rel = 'src/CMakeFiles/llama.dir/models/qwen4exp.cpp.o'
compile = shlex.split(next(c for c in commands if object_rel+' -c ' in c))
compile[compile.index('-c')+1] = str(patched)
for flag, target in [('-o', O/'qwen4exp.cpp.o'), ('-MF', O/'qwen4exp.cpp.o.d'), ('-MT', O/'qwen4exp.cpp.o')]:
    compile[compile.index(flag)+1] = str(target)
compile += ['-I'+str(S/'src/models')]
link_line = next(c for c in commands if '-o bin/libllama.so.0.0.0 ' in c)
assert link_line.startswith(': && ') and link_line.endswith(' && :')
link = shlex.split(link_line[5:-5])
link[link.index(object_rel)] = str(O/'qwen4exp.cpp.o')
link[link.index('-o')+1] = str(D/'libllama.so.0.0.0')
for i, arg in enumerate(link):
    if arg.startswith('-Wl,--dependency-file='): link[i] = '-Wl,--dependency-file='+str(O/'link.d')
    if arg.startswith('-Wl,-rpath,'): link[i] = '-Wl,-rpath,$ORIGIN'
manifest = {'base_source':str(S), 'base_build':str(B), 'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
            'modified_source':str(patched), 'modified_source_sha256':hashlib.sha256(patched.read_bytes()).hexdigest(),
            'compile':compile, 'link':link, 'cwd':str(B), 'binary':str(D/'llama-server')}
(E/'turbo-ple-build-command.json').write_text(json.dumps(manifest, indent=2))
with (E/'turbo-ple-build.log').open('w') as log:
    subprocess.run(compile, cwd=B, stdout=log, stderr=subprocess.STDOUT, check=True)
    subprocess.run(link, cwd=B, stdout=log, stderr=subprocess.STDOUT, check=True)
assert hashlib.sha256(source.read_bytes()).hexdigest() == manifest['source_sha256']
manifest['status'] = 'built'
manifest['library_sha256'] = hashlib.sha256((D/'libllama.so.0.0.0').read_bytes()).hexdigest()
(E/'turbo-ple-build-result.json').write_text(json.dumps(manifest, indent=2))
print(json.dumps({'status':'built','binary':manifest['binary']}), flush=True)
