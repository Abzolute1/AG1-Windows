"""Build one CUDA translation-unit overlay; run between model benchmarks."""
import difflib, hashlib, json, os, shlex, shutil, subprocess
from pathlib import Path
R=Path('/home/alex/Projects/flash-next-perf-20260914')
E=Path('/home/alex/Projects/AG1/implementation/evidence/flash-next-performance-20260914')
S=R/'unsloth-new-source/llama.cpp-b10909-mix-bea84f7'
B=R/'build-new-ada';O=R/'maskskip-overlay';D=R/'bundle-new-maskskip'
assert shutil.disk_usage(R).free>30*2**30
O.mkdir(exist_ok=False);D.mkdir(exist_ok=False);(O/'template-instances').mkdir()
source=S/'ggml/src/ggml-cuda/fattn-vec.cuh'
before=source.read_text()
needle='''        // Calculate KQ tile and keep track of new maximum KQ values:'''
assert before.count(needle)==1
after=before.replace(needle,'''        // A warp owns the same 32 KV rows throughout this iteration. For a
        // fully masked warp, the stock recurrence only adds zero and scales
        // the existing accumulator by one. Skip its K/V reads and arithmetic.
        // No CTA barrier occurs inside this loop; the decision is warp-uniform.
#if !defined(GGML_USE_HIP) && !defined(GGML_USE_MUSA)
        if constexpr (D == 256 && ncols == 1 &&
                      type_K == GGML_TYPE_Q8_0 && type_V == GGML_TYPE_Q8_0) {
            if (ne11 >= 4096 && mask && max_bias == 0.0f &&
                __all_sync(0xFFFFFFFF, __half2float(maskh[tid]) == -INFINITY)) {
                continue;
            }
        }
#endif

'''+needle,1)
(O/'fattn-vec.cuh').write_text(after)
generated=S/'ggml/src/ggml-cuda/template-instances/fattn-vec-instance-q8_0-q8_0.cu'
shutil.copy2(generated,O/'template-instances'/generated.name)
(E/'cuda-masked-warp-skip.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/ggml/src/ggml-cuda/fattn-vec.cuh',tofile='b/ggml/src/ggml-cuda/fattn-vec.cuh')))
for p in (B/'bin').iterdir():
 if p.name=='llama-server' or '.so' in p.name:
  if p.is_symlink():(D/p.name).symlink_to(os.readlink(p))
  elif p.is_file():shutil.copy2(p,D/p.name)
commands=subprocess.check_output(['ninja','-C',str(B),'-t','commands','ggml-cuda'],text=True).splitlines()
obj='ggml/src/ggml-cuda/CMakeFiles/ggml-cuda.dir/template-instances/fattn-vec-instance-q8_0-q8_0.cu.o'
compile=shlex.split(next(x for x in commands if obj in x and ' -c ' in x))
compile[compile.index('-c')+1]=str(O/'template-instances'/generated.name)
for flag,target in [('-o',O/'maskskip.cu.o'),('-MT',O/'maskskip.cu.o'),('-MF',O/'maskskip.cu.o.d')]:compile[compile.index(flag)+1]=str(target)
compile+=['-I'+str(S/'ggml/src/ggml-cuda')]
line=next(x for x in commands if '-o bin/libggml-cuda.so ' in x)
assert line.startswith(': && ') and line.endswith(' && :')
link=shlex.split(line[5:-5]);link[link.index(obj)]=str(O/'maskskip.cu.o');link[link.index('-o')+1]=str(D/'libggml-cuda.so')
for i,x in enumerate(link):
 if x.startswith('-Wl,--dependency-file='):link[i]='-Wl,--dependency-file='+str(O/'link.d')
 if x.startswith('-Wl,-rpath,'):link[i]='-Wl,-rpath,$ORIGIN:/opt/cuda/targets/x86_64-linux/lib'
m={'base_source':str(S),'base_build':str(B),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'compile':compile,'link':link,'cwd':str(B),'binary':str(D/'llama-server')}
(E/'maskskip-build-command.json').write_text(json.dumps(m,indent=2))
with (E/'maskskip-build.log').open('w') as log:
 subprocess.run(compile,cwd=B,stdout=log,stderr=subprocess.STDOUT,check=True)
 subprocess.run(link,cwd=B,stdout=log,stderr=subprocess.STDOUT,check=True)
assert hashlib.sha256(source.read_bytes()).hexdigest()==m['source_sha256']
m['status']='built';m['library_sha256']=hashlib.sha256((D/'libggml-cuda.so').read_bytes()).hexdigest()
(E/'maskskip-build-result.json').write_text(json.dumps(m,indent=2))
print(json.dumps({'status':'built','binary':m['binary']}),flush=True)
