"""Insert a bounded thread A/B after the active fresh-process speculation screen."""
import json,os,signal,time
from pathlib import Path
from bench import ROOT as R,EVID as E,run
def find(name):
 found=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:args=(p/'cmdline').read_bytes().split(b'\0')
  except OSError:continue
  if str(R/name).encode() in args:found.append(int(p.name))
 assert len(found)==1,(name,found)
 return found[0]
parent=find('post-build-screen.py');child=find('spec-screen.py')
assert f'PPid:\t{parent}' in Path(f'/proc/{child}/status').read_text()
record={'dispatcher_pid':parent,'screen_pid':child,'status':'waiting-for-active-spec-screen'}
started=time.time();os.kill(parent,signal.SIGSTOP)
(E/'spec-thread-checkpoint.json').write_text(json.dumps(record,indent=2))
try:
 while True:
  try:state=Path(f'/proc/{child}/status').read_text()
  except FileNotFoundError:state='State:\tZ'
  if 'State:\tZ' in state:
   marker=E/'spec-screen-done.json'
   assert marker.exists() and marker.stat().st_mtime>started,'Spec screen exited without a fresh completion marker'
   break
  if time.time()-started>7200:raise TimeoutError('Spec screen exceeded two hours')
  time.sleep(3)
 record['status']='running-thread-comparison';(E/'spec-thread-checkpoint.json').write_text(json.dumps(record,indent=2))
 pairs=[(4,12),(4,24),(8,12),(8,24),(16,12),(16,24)]
 for cycle,order in enumerate([pairs,list(reversed(pairs))]):
  for maximum,threads in order:
   c={'name':f'spec-thread-{maximum}-t{threads}-{cycle}','workloads':['edit'],'repetitions':1,'n_predict':256,
      'flags':{'--spec-type':'ngram-mod','--spec-ngram-mod-n-max':str(maximum),'--spec-ngram-mod-n-min':'2',
               '--spec-ngram-mod-n-match':'24','--threads-batch':str(threads),'--cpu-range-batch':f'0-{threads-1}'}}
   (R/(c['name']+'.json')).write_text(json.dumps(c,indent=2));run(c)
 record['status']='completed'
except Exception as e:
 record.update(status='failed',error=repr(e));raise
finally:
 (E/'spec-thread-checkpoint.json').write_text(json.dumps(record,indent=2))
 os.kill(parent,signal.SIGCONT)
