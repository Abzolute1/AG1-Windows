"""Isolated PLE rewind repair, layered on the lazy/reuse overlay.

Retain token IDs for the live contiguous prefix (at most 1 Mi tokens here),
instead of irreversibly discarding every token older than two positions.
No GGUF or tensor arithmetic changes. Private contexts/state blobs only.
Run only between inference processes.
"""
import difflib,hashlib,json,os,shlex,shutil,subprocess
from pathlib import Path
R=Path('/home/alex/Projects/flash-next-perf-20260914')
E=Path('/home/alex/Projects/AG1/implementation/evidence/flash-next-performance-20260914')
S=Path(json.loads((E/'turbo-source-manifest.json').read_text())['source'])
B=R/'build-turbo-latest';O=R/'turbo-history-overlay';D=R/'bundle-turbo-history'
assert shutil.disk_usage(R).free>30*2**30
O.mkdir();shutil.copytree(R/'bundle-turbo-ple',D,symlinks=True)
qbase=(R/'turbo-ple-overlay/qwen4exp.cpp').read_text();q=qbase
q=q.replace('    std::vector<int32_t> idx(n_heads * n_tokens);',
'''    std::vector<int32_t> idx(n_heads * n_tokens);
    const bool retain_history = flash_ple_experiment("AG1_FLASH_PLE_HISTORY");''',1)
needle='if ((int64_t) h.toks.size() > n_gram - 1) {'
assert q.count(needle)==2
q=q.replace(needle,'if (!retain_history && (int64_t) h.toks.size() > n_gram - 1) {')
needle='        std::copy(h.toks.begin(), h.toks.end(), padded.end() - (int64_t) h.toks.size());'
assert q.count(needle)==1
q=q.replace(needle,'''        const size_t n_copy = std::min<size_t>(h.toks.size(), padded.size());
        std::copy(h.toks.end() - n_copy, h.toks.end(), padded.end() - n_copy);''')
needle='        h.toks.push_back(tok_of(i));'
q=q.replace(needle,'''        if (retain_history && h.toks.size() >= (1u << 20)) {
            throw std::runtime_error("experimental PLE retained history exceeded validated bound");
        }
''' + needle,1)
mfile=S/'src/llama-memory-hybrid-idx.cpp';mbase=mfile.read_text();m=mbase
m=m.replace('#include <stdexcept>','#include <stdexcept>\n#include <cstdlib>\n\nstatic bool flash_retain_ple_history() {\n    const char * value = std::getenv("AG1_FLASH_PLE_HISTORY");\n    return value && value[0] == \'1\' && value[1] == \'\\0\';\n}',1)
needle='    // a hole in the middle: seq_rm does not renumber what follows, so an overlapping'
assert m.count(needle)==1
m=m.replace(needle,'''    if (flash_retain_ple_history()) {
        const llama_pos beg = ple_hist_beg(h);
        if (p0 <= beg && p1 > beg && p1 < h.next_pos) {
            // Prefix eviction: keep the surviving contiguous suffix and its positions.
            h.toks.erase(h.toks.begin(), h.toks.begin() + (p1 - beg));
            return;
        }
        if (p0 < h.next_pos && p1 >= h.next_pos) {
            ple_hist_truncate(h, std::max(p0, beg));
            return;
        }
    }

''' + needle,1)
m=m.replace('if (n_toks > LLAMA_MAX_PLE_NGRAM - 1) {',
            'if (n_toks > (flash_retain_ple_history() ? (1u << 20) : LLAMA_MAX_PLE_NGRAM - 1)) {',1)
changes=[('src/models/qwen4exp.cpp',qbase,q),('src/llama-memory-hybrid-idx.cpp',mbase,m)]
commands=subprocess.check_output(['ninja','-C',str(B),'-t','commands','llama'],text=True).splitlines()
compiled=[];replacements={};patch=[]
for rel,before,after in changes:
    p=O/Path(rel).name;p.write_text(after)
    patch.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
    obj='src/CMakeFiles/llama.dir/'+rel.removeprefix('src/')+'.o'
    cmd=shlex.split(next(c for c in commands if obj+' -c ' in c));cmd[cmd.index('-c')+1]=str(p)
    dest=O/(p.name+'.o')
    for flag,target in [('-o',dest),('-MF',str(dest)+'.d'),('-MT',dest)]:cmd[cmd.index(flag)+1]=str(target)
    cmd+=['-I'+str(S/'src/models')];compiled.append(cmd);replacements[obj]=str(dest)
(E/'turbo-ple-retained-history.patch').write_text(''.join(patch))
line=next(c for c in commands if '-o bin/libllama.so.0.0.0 ' in c)
assert line.startswith(': && ') and line.endswith(' && :')
link=shlex.split(line[5:-5])
for i,arg in enumerate(link):
    if arg in replacements:link[i]=replacements[arg]
    if arg.startswith('-Wl,--dependency-file='):link[i]='-Wl,--dependency-file='+str(O/'link.d')
    if arg.startswith('-Wl,-rpath,'):link[i]='-Wl,-rpath,$ORIGIN'
link[link.index('-o')+1]=str(D/'libllama.so.0.0.0')
manifest={'base_revision':'407f3237bfb3eeaff61546797de3d8c1a96be748','base_source':str(S),'base_build':str(B),
          'overlay_dependency':'turbo-ple-lazy-reuse.patch','compile':compiled,'link':link,'cwd':str(B),
          'binary':str(D/'llama-server'),'files':{str(O/Path(rel).name):hashlib.sha256(after.encode()).hexdigest() for rel,_,after in changes}}
(E/'turbo-history-build-command.json').write_text(json.dumps(manifest,indent=2))
assert not (D/'libllama.so.0.0.0').is_symlink() and (D/'libllama.so.0.0.0').stat().st_nlink == 1, 'Refusing to overwrite a shared or linked library'
with (E/'turbo-history-build.log').open('w') as log:
    for cmd in compiled:subprocess.run(cmd,cwd=B,stdout=log,stderr=subprocess.STDOUT,check=True)
    subprocess.run(link,cwd=B,stdout=log,stderr=subprocess.STDOUT,check=True)
assert mfile.read_text()==mbase and (R/'turbo-ple-overlay/qwen4exp.cpp').read_text()==qbase
manifest['status']='built';manifest['library_sha256']=hashlib.sha256((D/'libllama.so.0.0.0').read_bytes()).hexdigest()
(E/'turbo-history-build-result.json').write_text(json.dumps(manifest,indent=2))
