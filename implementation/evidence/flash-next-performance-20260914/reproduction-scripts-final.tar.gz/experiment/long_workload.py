import json,random,hashlib

def extend(prompts,post,path):
 if path.exists():return {**prompts,'long80k':json.loads(path.read_text())}
 rng=random.Random(38091485);records=[];facts={}
 topics=['deadline propagation','durable recovery','queue admission','replica reconciliation','stream cancellation','cache coherence','model readiness','resource ownership']
 endings=[
  'The worker must preserve input order while releasing resources when cancellation arrives. An earlier implementation waited on an obsolete event and leaked a permit.',
  'A failed write must report its durability state explicitly. Retrying an ambiguous transaction without an idempotency key can duplicate an externally visible operation.',
  'Batching improves throughput only when independent requests are available. A partially filled batch must not wait indefinitely for another caller.',
  'The cache stores immutable values keyed by the complete configuration digest. Concurrent readers may share storage, but eviction must respect in-flight references.',
  'The measured tail latency exceeded its budget during a deployment. Investigation found lock contention rather than arithmetic throughput to be the immediate bottleneck.',
  'An asynchronous copy requires an event before the source buffer is reused. Pinned staging buffers remain bounded and ownership follows completion rather than enqueue time.'
 ]
 for i in range(1500):
  owner=rng.choice(['Amina','Jonas','Mei','Priya','Tomas','Elsa','Noah','Zara']);budget=rng.randrange(50,9000);rev=f'{rng.getrandbits(48):012x}'
  facts[f'{i:04d}']={'owner':owner,'budget_ms':budget,'revision':rev}
  records.append(f'Record {i:04d}: {owner} reviewed {topics[i%len(topics)]} in component {rng.randrange(100000,999999)}. The latency budget is {budget} ms and the verified revision is {rev}. '+rng.choice(endings))
 # Calibrate using the actual tokenizer once, before timings, then freeze the
 # exact complete-record notebook for every build. Never truncate a fact record.
 n=1120
 for attempt in range(6):
  ids=[f'{i:04d}' for i in [3,n//3,2*n//3,n-5]];expected={i:facts[i] for i in ids}
  content='Read the complete notebook. Return only JSON with the exact owner, budget_ms and revision for records '+', '.join(ids)+'. Use those four record IDs as keys; each value has owner (string), budget_ms (integer), revision (string).\n\n'+'\n'.join(records[:n])
  messages=[{'role':'system','content':'Extract facts exactly from the supplied notebook. Return only the specified JSON.'},{'role':'user','content':content}]
  prompt=post('/apply-template',{'messages':messages,'chat_template_kwargs':{'enable_thinking':False}})['prompt'];tokens=post('/tokenize',{'content':prompt,'add_special':False})['tokens']
  if 81000<len(tokens)<85000:break
  n=max(20,min(len(records),round(n*83000/len(tokens))))
 assert 78000<len(tokens)<89000, len(tokens)
 value={'category':'A-long-context','record_count':n,'messages':messages,'prompt':prompt,'tokens':tokens,'sha256':hashlib.sha256(prompt.encode()).hexdigest(),'expected':expected}
 path.write_text(json.dumps(value,indent=2));return {**prompts,'long80k':value}
