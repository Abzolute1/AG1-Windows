from pathlib import Path
import subprocess,shutil,json,time,urllib.request,hashlib,tarfile
R=Path('/home/alex/Projects/flash-next-perf-20260914');E=Path('/home/alex/Projects/AG1/implementation/evidence/flash-next-performance-20260914')
while not (E/'third-screen-done.json').exists():time.sleep(3)
# Model processes have exited; hardware diagnostics/builds do not overlap timing.
p=R/'check-host-register.cpp';p.write_text(p.read_text().replace('#include <cstdio>','#include <cstdio>\n#include <initializer_list>'))
cmd=['g++','-O2',str(p),'-I/opt/cuda/targets/x86_64-linux/include','-L/opt/cuda/targets/x86_64-linux/lib','-lcudart','-Wl,-rpath,/opt/cuda/targets/x86_64-linux/lib','-o',str(R/'check-host-register')]
subprocess.run(cmd,check=True)
model=json.loads((E/'original-launch.json').read_text())['model_path']
p=subprocess.run([str(R/'check-host-register'),model],capture_output=True,text=True);(E/'host-register-diagnostic.txt').write_text(p.stdout+p.stderr)
subprocess.run(['python',str(R/'prepare-cpu-kernel.py')],check=True)
args=json.loads((E/'register-source-build.json').read_text())['configure'];args[args.index('-S')+1]=str(R/'source-new-rows2');args[args.index('-B')+1]=str(R/'build-new-rows2')
with (E/'rows2-build.log').open('w') as log:
 subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,check=True)
 subprocess.run(['cmake','--build',str(R/'build-new-rows2'),'--target','ggml-cpu','-j','12'],stdout=log,stderr=subprocess.STDOUT,check=True)
bundle=R/'bundle-new-rows2';shutil.copytree(R/'bundle-new-register',bundle);shutil.copy2(R/'build-new-rows2/bin/libggml-cpu.so',bundle/'libggml-cpu.so')
layout=json.loads((E/'model-layout.json').read_text());w=next(x for x in layout if x['name']=='blk.0.ffn_down_exps.weight');assert w['dims']==[640,2560,512] and w['type']==39
size=64*2560*640//32*17
with open(w['file'],'rb') as f:f.seek(w['absolute_offset']);data=f.read(size)
(R/'mxfp4-fixture.bin').write_bytes(data);(E/'mxfp4-fixture.json').write_text(json.dumps({'tensor':w,'fixture_bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()},indent=2));del data
subprocess.run(['g++','-O3','-std=c++17',str(R/'check-dot-mxfp4.cpp'),'-ldl','-o',str(R/'check-dot-mxfp4')],check=True)
with (E/'mxfp4-rows2-micro.jsonl').open('w') as log:
 p=subprocess.run([str(R/'check-dot-mxfp4'),str(R/'bundle-new-register/libggml-cpu.so'),str(bundle/'libggml-cpu.so'),str(R/'mxfp4-fixture.bin')],stdout=log,stderr=subprocess.STDOUT)
print('rows2 correctness and micro return',p.returncode,flush=True)
# Hash existing MTP heads before any speculative model test.
mtp=Path('/home/alex/.lmstudio/models/unsloth/Qwen3.8-Flash-Next-MTP-GGUF')
(E/'mtp-before.json').write_text(json.dumps([{'path':str(f),'bytes':f.stat().st_size,'sha256':hashlib.file_digest(f.open('rb'),'sha256').hexdigest()} for f in sorted(mtp.glob('*.gguf'))],indent=2))
revision='97e4ca73582084f2751767f80c86237483ecc381'
archive=R/'downloads'/('upstream-'+revision+'.tar.gz')
if not archive.exists():urllib.request.urlretrieve('https://api.github.com/repos/ggml-org/llama.cpp/tarball/'+revision,archive)
with tarfile.open(archive) as t:t.extractall(R/'upstream-source',filter='data')
(E/'upstream-download.json').write_text(json.dumps({'revision':revision,'sha256':hashlib.file_digest(archive.open('rb'),'sha256').hexdigest(),'bytes':archive.stat().st_size},indent=2))
(E/'fourth-preparation-done.json').write_text(json.dumps({'status':'finished','rows2_check_return':p.returncode}))
