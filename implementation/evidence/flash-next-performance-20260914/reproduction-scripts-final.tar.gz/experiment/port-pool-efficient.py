from pathlib import Path
import shutil,difflib
R=Path('/home/alex/Projects/flash-next-perf-20260914');E=Path('/home/alex/Projects/AG1/implementation/evidence/flash-next-performance-20260914')
base=R/'source-new-stage';dst=R/'source-new-pool-efficient';shutil.copytree(base,dst)
p=dst/'ggml/src/ggml-backend.cpp';old=p.read_text();s=old
s=s.replace('    uint64_t n_hits = 0;','    const ggml_tensor * last_update_ids = nullptr;\n    uint64_t update_calls = 0;\n    uint64_t duplicate_updates = 0;\n    uint64_t n_hits = 0;',1)
s=s.replace('    sched->expert_ids_tensor = nullptr;','    sched->expert_ids_tensor = nullptr;\n    for (auto & ep : sched->expert_pools) ep.last_update_ids = nullptr;',1)
needle='    GGML_ASSERT(ids != nullptr && "pooled expert ids without a routing tensor");'
s=s.replace(needle,needle+"""
    ++ep.update_calls;
    // Reset for every graph execution above: a tensor address can recur next token.
    // Within one execution, remap and matmul consume the same routing result.
    if (ep.last_update_ids == ids) {
        ++ep.duplicate_updates;
        return;
    }
    ep.last_update_ids = ids;
""",1)
needle='    const uint64_t stamp_base = ep.stamp;'
s=s.replace(needle,needle+"""
    // Protect every required resident expert before inserting any miss. Otherwise
    // a low-numbered miss can evict a high-numbered hit needed by this same batch.
    for (int e = 0; e < ep.n_expert; ++e) {
        if (ggml_bitset_get(used.data(), e) && ep.expert_slot[e] >= 0) {
            ep.slot_stamp[ep.expert_slot[e]] = ++ep.stamp;
        }
    }
""",1)
needle='    for (auto & ep : sched->expert_pools) {\n        ggml_backend_buffer_free(ep.pool_buf);'
replace="""    for (auto & ep : sched->expert_pools) {
        if (const char * trace = getenv("AG1_FLASH_POOL_TRACE")) {
            if (FILE * f = fopen(trace, "a")) {
                fprintf(f, "%s calls=%llu duplicates=%llu hits=%llu misses=%llu bytes=%llu\\n",
                    ep.w->name, (unsigned long long) ep.update_calls,
                    (unsigned long long) ep.duplicate_updates, (unsigned long long) ep.n_hits,
                    (unsigned long long) ep.n_misses, (unsigned long long) (ep.n_misses * ep.expert_size));
                fclose(f);
            }
        }
        ggml_backend_buffer_free(ep.pool_buf);"""
assert s.count(needle)==1;s=s.replace(needle,replace,1);p.write_text(s)
(E/'pool-efficient-updates.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='a/ggml/src/ggml-backend.cpp',tofile='b/ggml/src/ggml-backend.cpp')))
