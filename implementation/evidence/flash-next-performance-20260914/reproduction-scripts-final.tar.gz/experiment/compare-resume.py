"""Compare retained post-resume evidence without running model or build work."""
import argparse
import hashlib
import json
import math
import statistics
from pathlib import Path

E = Path('/home/alex/Projects/AG1/implementation/evidence/flash-next-performance-20260914')


def summarize(name):
    path = E / 'runs' / name
    result = json.loads((path / 'result.json').read_text())
    workloads = {}
    for row in result['requests']:
        workloads.setdefault(row['workload'], []).append(row)
    summary = {'name': name, 'status': result['status'], 'load_seconds': result.get('load_seconds'),
               'peak_process_vram_mib': result.get('peak_process_vram_mib'), 'workloads': {}}
    for workload, rows in workloads.items():
        metrics = {
            'prefill_tps': [r['timings']['prompt_per_second'] for r in rows],
            'decode_tps': [(r['timings']['predicted_n'] - 1) * 1000 / r['timings']['predicted_ms'] for r in rows],
            'ttft_seconds': [r['ttft_seconds'] for r in rows if r['ttft_seconds'] is not None],
            'wall_seconds': [r['wall_seconds'] for r in rows],
        }
        summary['workloads'][workload] = {
            'requests': len(rows),
            **{k: {'median': statistics.median(v), 'min': min(v), 'max': max(v)} for k, v in metrics.items() if v},
            'outputs_sha256': [hashlib.sha256(r['output'].encode()).hexdigest() for r in rows],
            'word_counts': [len(r['output'].split()) for r in rows],
            'stop_types': [r.get('stop_type') for r in rows],
            'quality': [{k: r[k] for k in ['quality_pass', 'quality_content_pass', 'quality_exact_bytes_pass'] if k in r} for r in rows],
        }
    if 'api_smoke' in result:
        summary['api_smoke'] = {k: result['api_smoke'][k] for k in ['answer_pass', 'tool_call_pass']}
    return summary


def compare_teacher(base, candidate):
    left = E / 'runs' / base / 'teacher-force.json'
    right = E / 'runs' / candidate / 'teacher-force.json'
    if not left.exists() or not right.exists():
        return None
    a, b = json.loads(left.read_text()), json.loads(right.read_text())
    comparison = {}
    for workload in a.keys() & b.keys():
        assert len(a[workload]) == len(b[workload])
        pairs = list(zip(a[workload], b[workload]))
        assert all(x['position'] == y['position'] and x['gold_token'] == y['gold_token'] for x, y in pairs)
        distances = []
        for x, y in pairs:
            px = {v['id']: math.exp(v['logprob']) for v in x['probabilities'][0]['top_logprobs']}
            py = {v['id']: math.exp(v['logprob']) for v in y['probabilities'][0]['top_logprobs']}
            common = sorted(px.keys() & py.keys())
            qx, qy = [px[v] for v in common], [py[v] for v in common]
            qx.append(max(1e-15, 1-sum(qx)))
            qy.append(max(1e-15, 1-sum(qy)))
            distances.append({'coarsened_kl': max(0, sum(p*math.log(p/max(q, 1e-15)) for p, q in zip(qx, qy) if p)),
                              'coarsened_total_variation': sum(abs(p-q) for p, q in zip(qx, qy))/2})
        comparison[workload] = {
            'positions': len(pairs),
            'greedy_matches': sum(x['tokens'] == y['tokens'] for x, y in pairs),
            'reported_distributions_exactly_equal': sum(x['probabilities'] == y['probabilities'] for x, y in pairs),
            'positions_with_different_greedy_token': [x['position'] for x, y in pairs if x['tokens'] != y['tokens']],
            'mean_coarsened_kl': statistics.mean(d['coarsened_kl'] for d in distances),
            'mean_coarsened_total_variation': statistics.mean(d['coarsened_total_variation'] for d in distances),
            'scope': 'Same canonical prefixes. Common reported top-32 tokens plus a residual bucket: KL/TV are lower bounds, not full logits or a quality score.',
        }
    return comparison


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('runs', nargs='+')
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    result = {'runs': [summarize(name) for name in args.runs]}
    if len(args.runs) == 2:
        result['teacher_force_pair'] = compare_teacher(*args.runs)
    encoded = json.dumps(result, indent=2) + '\n'
    if args.output:
        args.output.write_text(encoded)
    else:
        print(encoded)
