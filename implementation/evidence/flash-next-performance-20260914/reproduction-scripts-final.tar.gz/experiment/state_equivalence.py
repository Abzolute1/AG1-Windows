"""Compare fresh and reused fixed prefixes; diagnostic, not a speed score."""
import json

def run(post,prompts,out):
    fixed=prompts['edit']['tokens']
    target=fixed[:min(900,len(fixed)-80)]
    base={'stream':False,'n_predict':1,'temperature':0,'top_k':1,'top_p':1,'min_p':0,
          'repeat_penalty':1,'seed':777,'id_slot':0,'n_probs':32,
          'post_sampling_probs':False,'return_tokens':True}
    def query(tokens,cached):
        return post('/completion',{**base,'prompt':tokens,'cache_prompt':cached})
    records=[]
    for mode,count in [('append',1),('append',8),('append',64),('rewind',1),('rewind',4),('rewind',32)]:
        fresh=query(target,False)
        setup=target[:-count] if mode=='append' else fixed[:len(target)+count]
        warm=query(setup,False)
        reused=query(target,True)
        def top_probs(response):
            items=response.get('completion_probabilities',[])
            if not items:return {}
            return {x['id']:x.get('logprob') for x in items[0].get('top_logprobs',[]) if isinstance(x.get('logprob'),(int,float))}
        a,b=top_probs(fresh),top_probs(reused)
        common=a.keys() & b.keys()
        records.append({'mode':mode,'distance':count,'target_tokens':len(target),
                        'fresh':fresh,'setup':warm,'reused':reused,
                        'same_next_content':fresh.get('content')==reused.get('content'),
                        'same_next_tokens':fresh.get('tokens')==reused.get('tokens'),
                        'cache_n':reused.get('timings',{}).get('cache_n'),
                        'prompt_n':reused.get('timings',{}).get('prompt_n'),
                        'top32_common_tokens':len(common),
                        'max_common_logprob_delta':max((abs(a[t]-b[t]) for t in common),default=None)})
    (out/'state-equivalence.json').write_text(json.dumps(records,indent=2))
    return {'cases':len(records),'next_content_matches':sum(x['same_next_content'] for x in records),
            'scope':'Fixed-prefix fresh versus cache append/rewind. Inspect raw pre-sampling probabilities and actual cache reuse; a matching greedy token alone is not proof of identical logits.'}
