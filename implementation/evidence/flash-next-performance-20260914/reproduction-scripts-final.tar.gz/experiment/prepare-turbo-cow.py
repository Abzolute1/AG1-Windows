"""Combine hybrid expert caching with private pinned expert mappings.
Only the isolated fork overlay changes. GGUF descriptors remain read-only and
mappings become MAP_PRIVATE; only CPU expert tensors are registered, never PLE.
"""
import difflib,hashlib,json,os,shlex,shutil,subprocess
from pathlib import Path
R=Path('/home/alex/Projects/flash-next-perf-20260914');E=Path('/home/alex/Projects/AG1/implementation/evidence/flash-next-performance-20260914')
S=Path(json.loads((E/'turbo-source-manifest.json').read_text())['source']);B=R/'build-turbo-latest'
O=R/'turbo-cow-overlay';D=R/'bundle-turbo-cow'
assert shutil.disk_usage(R).free>30*2**30
O.mkdir();shutil.copytree(R/'bundle-turbo-history',D,symlinks=True)
mp=S/'src/llama-mmap.cpp';mb=mp.read_text();m=mb
needle='        int flags = MAP_SHARED;';assert m.count(needle)==1
m=m.replace(needle,needle+'''
        const char * private_env = getenv("AG1_FLASH_TURBO_COW");
        if (private_env && private_env[0] == '1' && private_env[1] == '\\0') flags = MAP_PRIVATE;''',1)
p=S/'src/llama-model.cpp';before=p.read_text();s=before
s=s.replace('#include <algorithm>','''#include <algorithm>
#include <thread>
#include <cstdlib>
#ifdef __linux__
#include <dlfcn.h>
#include <sys/mman.h>
#include <unistd.h>
#endif''',1)
needle='    ~impl() = default;';assert s.count(needle)==1
s=s.replace(needle,'''    ~impl() {
#ifdef __linux__
        if (flash_unregister) {
            for (void * address : flash_pinned_experts) flash_unregister(address);
        }
        if (flash_driver) dlclose(flash_driver);
#endif
    }
    void * flash_driver = nullptr;
    int (*flash_unregister)(void *) = nullptr;
    std::vector<void *> flash_pinned_experts;''',1)
needle='''    if (use_mmap_buffer) {
        for (auto & mapping : ml.mappings) {''';assert s.count(needle)==1
s=s.replace(needle,'''#ifdef __linux__
    const char * flash_cow = std::getenv("AG1_FLASH_TURBO_COW");
    if (flash_cow && flash_cow[0] == '1' && flash_cow[1] == '\\0') {
        if (!ml.use_mmap || !use_mmap_buffer) throw std::runtime_error("private expert pinning requires mmap buffers");
        const uintptr_t page = (uintptr_t) sysconf(_SC_PAGESIZE);
        std::vector<std::pair<uintptr_t, uintptr_t>> ranges;
        for (const auto & entry : ctx_buf_maps) {
            ggml_context * ctx = entry.first;
            for (ggml_tensor * t = ggml_get_first_tensor(ctx); t; t = ggml_get_next_tensor(ctx, t)) {
                const std::string name(t->name);
                if (name.find("ffn_") == std::string::npos || name.find("_exps.weight") == std::string::npos ||
                        !t->buffer || !ggml_backend_buffer_is_host(t->buffer)) continue;
                const uintptr_t begin = (uintptr_t) t->data;
                const uintptr_t end = begin + ggml_nbytes(t);
                bool in_mapping = false;
                for (const auto & mapping : ml.mappings) {
                    const uintptr_t a = (uintptr_t) mapping->addr();
                    if (begin >= a && end >= begin && end <= a + mapping->size()) { in_mapping = true; break; }
                }
                if (!in_mapping) throw std::runtime_error("CPU expert tensor is not backed by the private GGUF mapping");
                ranges.emplace_back(begin & ~(page - 1), (end + page - 1) & ~(page - 1));
            }
        }
        if (ranges.empty()) throw std::runtime_error("no mapped CPU experts found for private pinning");
        std::sort(ranges.begin(), ranges.end());
        std::vector<std::pair<uintptr_t, uintptr_t>> merged;
        for (const auto & range : ranges) {
            if (!merged.empty() && range.first <= merged.back().second) merged.back().second = std::max(merged.back().second, range.second);
            else merged.push_back(range);
        }
        pimpl->flash_driver = dlopen("libcuda.so.1", RTLD_NOW | RTLD_LOCAL);
        auto register_host = pimpl->flash_driver ? reinterpret_cast<int (*)(void *, size_t, unsigned)>(dlsym(pimpl->flash_driver, "cuMemHostRegister_v2")) : nullptr;
        pimpl->flash_unregister = pimpl->flash_driver ? reinterpret_cast<int (*)(void *)>(dlsym(pimpl->flash_driver, "cuMemHostUnregister")) : nullptr;
        if (!register_host || !pimpl->flash_unregister) throw std::runtime_error("CUDA driver pinning entry points unavailable");
        const char * workers_env = std::getenv("AG1_FLASH_COW_PREFAULT_THREADS");
        const int workers_n = workers_env ? std::max(0, std::min(24, std::atoi(workers_env))) : 0;
        pimpl->flash_pinned_experts.reserve(merged.size());
        size_t total = 0;
        const int64_t start_us = ggml_time_us();
        for (const auto & range : merged) {
            const uintptr_t first = range.first, last = range.second;
            if (mprotect((void *) first, last - first, PROT_READ | PROT_WRITE)) throw std::runtime_error("private expert mapping mprotect failed");
            if (workers_n) {
                const size_t pages = (last - first) / page;
                std::vector<std::thread> workers;
                for (int worker = 0; worker < workers_n; ++worker) {
                    workers.emplace_back([=]() {
                        for (size_t i = pages * worker / workers_n; i < pages * (worker + 1) / workers_n; ++i) {
                            volatile unsigned char * address = reinterpret_cast<volatile unsigned char *>(first + i * page);
                            const unsigned char value = *address; *address = value;
                        }
                    });
                }
                for (auto & worker : workers) worker.join();
            }
            const int rc = register_host((void *) first, last - first, 1u);
            if (rc) throw std::runtime_error(format("private expert registration failed: %d", rc));
            pimpl->flash_pinned_experts.push_back((void *) first); total += last - first;
        }
        LLAMA_LOG_INFO("%s: pinned %.2f MiB private CPU expert weights in %.3f s, workers=%d, ranges=%zu\\n",
                __func__, total / 1048576.0, (ggml_time_us() - start_us) / 1e6, workers_n, merged.size());
    }
#endif

'''+needle,1)
changes=[('src/llama-model.cpp',before,s),('src/llama-mmap.cpp',mb,m)]
commands=subprocess.check_output(['ninja','-C',str(B),'-t','commands','llama'],text=True).splitlines()
compiled=[];replacements={};patch=[]
for rel,old,new in changes:
 dest=O/Path(rel).name;dest.write_text(new)
 patch.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
 obj='src/CMakeFiles/llama.dir/'+Path(rel).name+'.o';cmd=shlex.split(next(c for c in commands if obj+' -c ' in c));cmd[cmd.index('-c')+1]=str(dest)
 output=O/(dest.name+'.o')
 for flag,value in [('-o',output),('-MF',str(output)+'.d'),('-MT',output)]:cmd[cmd.index(flag)+1]=str(value)
 compiled.append(cmd);replacements[obj]=str(output)
parent=json.loads((E/'turbo-history-build-command.json').read_text());link=parent['link'].copy()
for i,arg in enumerate(link):
 if arg in replacements:link[i]=replacements[arg]
 if arg.startswith('-Wl,--dependency-file='):link[i]='-Wl,--dependency-file='+str(O/'link.d')
link[link.index('-o')+1]=str(D/'libllama.so.0.0.0')
(E/'turbo-private-expert-pinning.patch').write_text(''.join(patch))
manifest={'base_revision':parent['base_revision'],'base_source':str(S),'base_build':str(B),
 'compile':compiled,'link':link,'cwd':str(B),'binary':str(D/'llama-server'),
 'dependencies':['turbo-ple-lazy-reuse.patch','turbo-ple-retained-history.patch'],
 'source_hashes':{rel:hashlib.sha256(old.encode()).hexdigest() for rel,old,_ in changes}}
(E/'turbo-cow-build-command.json').write_text(json.dumps(manifest,indent=2))
assert not (D/'libllama.so.0.0.0').is_symlink() and (D/'libllama.so.0.0.0').stat().st_nlink==1
with (E/'turbo-cow-build.log').open('w') as log:
 for cmd in compiled:subprocess.run(cmd,cwd=B,stdout=log,stderr=subprocess.STDOUT,check=True)
 subprocess.run(link,cwd=B,stdout=log,stderr=subprocess.STDOUT,check=True)
for rel,old,_ in changes:assert (S/rel).read_text()==old
manifest['status']='built';manifest['library_sha256']=hashlib.sha256((D/'libllama.so.0.0.0').read_bytes()).hexdigest()
(E/'turbo-cow-build-result.json').write_text(json.dumps(manifest,indent=2))
