import time,subprocess,shutil,json
from pathlib import Path
R=Path('/home/alex/Projects/flash-next-perf-20260914')
E=Path('/home/alex/Projects/AG1/implementation/evidence/flash-next-performance-20260914')
while not (E/'second-screen-done.json').exists():time.sleep(3)
cmd=['g++','-shared','-fPIC','-O2','-std=c++17',str(R/'cupti_trace.cpp'),'-I/opt/cuda/targets/x86_64-linux/include','-L/opt/cuda/targets/x86_64-linux/lib','-lcupti','-Wl,-rpath,/opt/cuda/targets/x86_64-linux/lib','-o',str(R/'libcupti-trace.so')]
p=subprocess.run(cmd,capture_output=True,text=True);(E/'cupti-build.json').write_text(json.dumps({'command':cmd,'rc':p.returncode,'stdout':p.stdout,'stderr':p.stderr},indent=2));print('cupti',p.returncode,flush=True)
base=R/'unsloth-new-source/llama.cpp-b10909-mix-bea84f7'
for name,patch in [('pool','expert-pool-code.diff'),('direct','ple-direct.diff')]:
 dst=R/('source-new-'+name)
 if not dst.exists():shutil.copytree(base,dst)
 cmd=['patch','--batch','-p1','-i',str(R/'source-reference'/patch)]
 p=subprocess.run(cmd,cwd=dst,capture_output=True,text=True)
 (E/(name+'-port-apply.log')).write_text(p.stdout+p.stderr)
 print(name,p.returncode,p.stdout,p.stderr,flush=True)
