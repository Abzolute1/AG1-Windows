import time,json
from bench import run,EVID,ROOT
while not (EVID/'cow-stage-build-done.json').exists():time.sleep(3)
def binary(name):return str(ROOT/('bundle-new-'+name)/'llama-server')
configs=[
 {'name':'original-threads24','flags':{'--threads':'24','--cpu-range':'0-23'}},
 {'name':'new-rows2','binary':binary('rows2')},
 {'name':'new-cow-pinned','binary':binary('cow'),'environment':{'AG1_FLASH_REGISTER_COW':'1'},'flags':{'--verbosity':'3'}},
 {'name':'new-stage-original-placement','binary':binary('stage'),'environment':{'AG1_FLASH_STAGE':'1'}},
 {'name':'new-pool64-stage','binary':binary('stage'),'environment':{'AG1_FLASH_STAGE':'1','AG1_FLASH_POOL_MIB':'5400'},'flags':{'--n-cpu-moe':'48','--moe-expert-cache':'64'}},
 {'name':'new-pool80-stage','binary':binary('stage'),'environment':{'AG1_FLASH_STAGE':'1','AG1_FLASH_POOL_MIB':'6600'},'flags':{'--n-cpu-moe':'48','--moe-expert-cache':'80'}},
 {'name':'new-pool64-pinned','binary':binary('pool'),'environment':{'AG1_FLASH_POOL_MIB':'5400'},'flags':{'--n-cpu-moe':'48','--moe-expert-cache':'64','--load-mode':'none','--lazy-mode':'on'}},
 {'name':'new-stage-b2048-cpu44','binary':binary('stage'),'environment':{'AG1_FLASH_STAGE':'1'},'flags':{'--batch-size':'2048','--ubatch-size':'2048','--n-cpu-moe':'44'}},
 {'name':'new-stage-b1536-cpu42','binary':binary('stage'),'environment':{'AG1_FLASH_STAGE':'1'},'flags':{'--batch-size':'1536','--ubatch-size':'1536'}},
 {'name':'new-stage-b4096-cpu48','binary':binary('stage'),'environment':{'AG1_FLASH_STAGE':'1'},'flags':{'--batch-size':'4096','--ubatch-size':'4096','--n-cpu-moe':'48'}},
 {'name':'new-cow-b2048-cpu44','binary':binary('cow'),'environment':{'AG1_FLASH_REGISTER_COW':'1'},'flags':{'--batch-size':'2048','--ubatch-size':'2048','--n-cpu-moe':'44','--verbosity':'3'}},
]
for c in configs:
 c.setdefault('workloads',['review','prose','edit']);c.setdefault('repetitions',2);c['n_predict']=256;c['api_smoke']=True
 if c.get('environment',{}).get('AG1_FLASH_STAGE'):c['environment']['AG1_FLASH_STAGE_TRACE']=str(EVID/'runs'/c['name']/'stage-counts.jsonl')
 (ROOT/(c['name']+'.json')).write_text(json.dumps(c,indent=2));run(c)
(EVID/'fourth-screen-done.json').write_text(json.dumps({'status':'finished'}))
