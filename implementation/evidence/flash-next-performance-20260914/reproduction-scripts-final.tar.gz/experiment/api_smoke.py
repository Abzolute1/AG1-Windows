import json

def run(post,model):
 base={'model':model,'temperature':0,'seed':777,'top_k':1,'top_p':1,'min_p':0,'stream':False,'chat_template_kwargs':{'enable_thinking':False},'cache_prompt':False}
 answer=post('/v1/chat/completions',{**base,'max_tokens':64,'messages':[{'role':'system','content':'Return only the requested JSON object.'},{'role':'user','content':'Calculate 17 * 19. Return a JSON object with the integer result in the answer field.'}]})
 try:answer_ok=json.loads(answer['choices'][0]['message']['content'])=={'answer':323}
 except (KeyError,ValueError,TypeError):answer_ok=False
 tool=post('/v1/chat/completions',{**base,'max_tokens':128,'messages':[{'role':'user','content':'Call lookup_service for svc-047. Do not answer yet.'}],'tools':[{'type':'function','function':{'name':'lookup_service','description':'Look up a service by its service identifier.','parameters':{'type':'object','properties':{'service':{'type':'string'}},'required':['service'],'additionalProperties':False}}}],'tool_choice':{'type':'function','function':{'name':'lookup_service'}}})
 try:
  calls=tool['choices'][0]['message']['tool_calls'];tool_ok=len(calls)==1 and calls[0]['function']['name']=='lookup_service' and json.loads(calls[0]['function']['arguments'])=={'service':'svc-047'}
 except (KeyError,ValueError,TypeError):tool_ok=False
 return {'answer_pass':answer_ok,'tool_call_pass':tool_ok,'answer_response':answer,'tool_response':tool}
