import json,statistics,collections
from pathlib import Path
E=Path('/home/alex/Projects/AG1/implementation/evidence/flash-next-performance-20260914')
results=[]
invalid_path=E/'invalid-runs.json'
invalid={r['run']:r['reason'] for r in json.loads(invalid_path.read_text())} if invalid_path.exists() else {}
prompts=json.loads((E/'prompts.json').read_text())
if (E/'prompts-additional.json').exists():prompts.update(json.loads((E/'prompts-additional.json').read_text()))
for p in sorted((E/'runs').glob('*/result.json')):
 d=json.loads(p.read_text());groups=collections.defaultdict(list)
 for q in d['requests']:groups[q['workload']].append(q)
 summary={'run':d['name'],'status':d.get('status','running'),'load_seconds':d.get('load_seconds'),'configuration':d['config'],'workloads':{}}
 if d['name'] in invalid:
  summary['raw_status']=summary['status'];summary['status']='excluded';summary['exclusion_reason']=invalid[d['name']]
 for name,rows in groups.items():
  med=lambda f:statistics.median(f(r) for r in rows)
  summary['workloads'][name]={'n':len(rows),'prefill_tps':med(lambda r:r['timings']['prompt_per_second']),'decode_tps':med(lambda r:r['timings']['predicted_per_second']),'ttft_seconds':med(lambda r:r['ttft_seconds']),'wall_seconds':med(lambda r:r['wall_seconds']),'quality_raw':[r.get('quality_pass') for r in rows],'outputs_identical':len({r['output'] for r in rows})==1,'prefill_tps_range':[min(r['timings']['prompt_per_second'] for r in rows),max(r['timings']['prompt_per_second'] for r in rows)]}
  if 'expected_output' in prompts.get(name,{}):
   expected=prompts[name]['expected_output']
   summary['workloads'][name]['quality_exact_bytes']=[r['output'].encode()==expected.encode() for r in rows]
   summary['workloads'][name]['quality_content_ignoring_outer_whitespace']=[r['output'].strip()==expected.strip() for r in rows]
  summary['workloads'][name]['decode_common_tps']=med(lambda r:1000*max(0,r['timings']['predicted_n']-1)/r['timings']['predicted_ms'])
 results.append(summary)
(E/'run-summary.json').write_text(json.dumps(results,indent=2))
for d in results:
 print(d['run'],d['status'],'load',round(d['load_seconds'],2) if d['load_seconds'] else None)
 for k,r in d['workloads'].items():print(' ',k,r['n'],round(r['prefill_tps'],2),round(r['decode_tps'],2),round(r['ttft_seconds'],3),r['quality_raw'])
