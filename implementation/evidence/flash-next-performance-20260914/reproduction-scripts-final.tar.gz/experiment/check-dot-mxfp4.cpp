#include <dlfcn.h>
#include <sched.h>
#include <chrono>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <iterator>
#include <vector>
#include <cmath>
#include <algorithm>
#include <cstdint>
using dot_t=void (*)(int,float *,size_t,const void *,size_t,const void *,size_t,int);
using rows_t=void (*)(int,float *,const void *,size_t,const void *);
using quant_t=void (*)(const float *,void *,int64_t);
int main(int argc,char ** argv) {
    if(argc!=4)return 2;
    cpu_set_t set;CPU_ZERO(&set);CPU_SET(0,&set);if(sched_setaffinity(0,sizeof(set),&set))return 3;
    void * a=dlopen(argv[1],RTLD_NOW|RTLD_LOCAL),*b=dlopen(argv[2],RTLD_NOW|RTLD_LOCAL);
    if(!a||!b){fprintf(stderr,"%s\n",dlerror());return 4;}
    auto dot=(dot_t)dlsym(a,"ggml_vec_dot_mxfp4_q8_0");
    auto rows=(rows_t)dlsym(b,"ggml_vec_dot_mxfp4_q8_0_rows2");
    auto quant=(quant_t)dlsym(a,"quantize_row_q8_0");
    auto init=(void (*)())dlsym(a,"ggml_cpu_init");
    if(!dot||!rows||!quant||!init)return 5;init();((void (*)())dlsym(b,"ggml_cpu_init"))();
    std::ifstream f(argv[3],std::ios::binary);std::vector<char>x{std::istreambuf_iterator<char>(f),{}};
    constexpr int n=640,stride=20*17;size_t count=x.size()/stride;count-=count%2;
    std::vector<float>act(n),out0(count),out1(count);std::vector<uint8_t>y(20*34);
    uint32_t seed=777;size_t mismatches=0;double maxabs=0;
    for(int sample=0;sample<4;++sample) {
        for(float &v:act){seed^=seed<<13;seed^=seed>>17;seed^=seed<<5;v=(float(int(seed%200001)-100000)/100000.0f)*(sample+1);}
        quant(act.data(),y.data(),n);
        for(size_t row=0;row<count;++row)dot(n,&out0[row],0,x.data()+row*stride,0,y.data(),0,1);
        for(size_t row=0;row<count;row+=2)rows(n,&out1[row],x.data()+row*stride,stride,y.data());
        for(size_t row=0;row<count;++row){mismatches+=memcmp(&out0[row],&out1[row],sizeof(float))!=0;maxabs=std::max(maxabs,double(std::abs(out0[row]-out1[row])));}
    }
    printf("{\"rows\":%zu,\"samples\":4,\"bitwise_mismatches\":%zu,\"max_abs_error\":%.12g}\n",count,mismatches,maxabs);
    for(int rep=0;rep<12;++rep)for(int order=0;order<2;++order) {
        int variant=(rep%2)^order;auto start=std::chrono::steady_clock::now();
        for(int pass=0;pass<4;++pass) {
            if(variant==0)for(size_t row=0;row<count;++row)dot(n,&out0[row],0,x.data()+row*stride,0,y.data(),0,1);
            else for(size_t row=0;row<count;row+=2)rows(n,&out1[row],x.data()+row*stride,stride,y.data());
        }
        double seconds=std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();
        printf("{\"rep\":%d,\"variant\":%d,\"seconds\":%.9f,\"check\":%.9g}\n",rep,variant,seconds,double(variant?out1[1]:out0[1]));fflush(stdout);
    }
    return mismatches?6:0;
}
