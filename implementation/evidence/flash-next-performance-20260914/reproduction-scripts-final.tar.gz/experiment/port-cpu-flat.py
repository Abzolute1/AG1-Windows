from pathlib import Path
import shutil,difflib
R=Path('/home/alex/Projects/flash-next-perf-20260914');E=Path('/home/alex/Projects/AG1/implementation/evidence/flash-next-performance-20260914')
base=R/'source-new-register';dst=R/'source-new-cpu-flat';shutil.copytree(base,dst)
previous=Path('/home/alex/Projects/llama-perf-20260914/cpu-mmid-single/diagnostic-source/ggml/src/ggml-cpu/ggml-cpu.c').read_text()
a=previous.index('static void ggml_compute_forward_mul_mat_id_single_token(');b=previous.index('static void ggml_compute_forward_mul_mat_id_impl(',a);helper=previous[a:b]
helper=helper.replace('    if (ag1_mmid_single_coverage) {\n        ag1_mmid_single_coverage(dst, params->ith, params->nth);\n    }\n','')
p=dst/'ggml/src/ggml-cpu/ggml-cpu.c';old=p.read_text();s=old;needle='static void ggml_compute_forward_mul_mat_id(\n';assert s.count(needle)==1;s=s.replace(needle,helper+needle,1)
a=s.index(needle);before=s[:a];body=s[a:]
needle='''    if (ith == 0) {
        // initialize matrix_row_counts'''
addition='''    // A single decode token needs no expert grouping or per-expert work queues.
    bool single_token = !params->use_ref &&
        (type == GGML_TYPE_MXFP4 || type == GGML_TYPE_IQ1_M || type == GGML_TYPE_IQ2_S) &&
        (src1->type == GGML_TYPE_F32 || src1->type == vec_dot_type) &&
        ids->type == GGML_TYPE_I32 && n_ids > 0 && n_ids <= 64 &&
        ne00 > 0 && ne00 <= INT32_MAX && ne01 > 0 && ne01 <= INT32_MAX && ne03 == 1 &&
        ne10 == ne00 && ne11 > 0 && ne12 == 1 && ne13 == 1 &&
        ids->ne[1] == 1 && ids->ne[2] == 1 && ids->ne[3] == 1 &&
        ne0 == ne01 && ne1 == n_ids && ne2 == 1 && ne3 == 1;
    if (single_token && iqp) {
        // Repeated experts may select the stock multi-row IQ panel kernel.
        for (int i = 0; i < n_ids && single_token; ++i) {
            const int32_t a = *(const int32_t *) ((const char *) ids->data + i * ids->nb[0]);
            for (int j = 0; j < i; ++j) {
                const int32_t b = *(const int32_t *) ((const char *) ids->data + j * ids->nb[0]);
                if (a == b) { single_token = false; break; }
            }
        }
    }
    if (single_token) {
        ggml_barrier(params->threadpool);
        ggml_compute_forward_mul_mat_id_single_token(params, dst);
        return;
    }

'''
assert body.count(needle)==1;body=body.replace(needle,addition+needle,1);s=before+body;p.write_text(s)
(E/'cpu-flat-single-token.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='a/ggml/src/ggml-cpu/ggml-cpu.c',tofile='b/ggml/src/ggml-cpu/ggml-cpu.c')))
