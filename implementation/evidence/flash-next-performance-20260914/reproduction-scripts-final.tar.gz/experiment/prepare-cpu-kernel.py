from pathlib import Path
import shutil,difflib
R=Path('/home/alex/Projects/flash-next-perf-20260914');E=Path('/home/alex/Projects/AG1/implementation/evidence/flash-next-performance-20260914')
base=R/'source-new-register';dst=R/'source-new-rows2'
shutil.copytree(base,dst)
p=dst/'ggml/src/ggml-cpu/arch/x86/quants.c';s=p.read_text();needle='void ggml_vec_dot_nvfp4_q8_0(';s=s.replace(needle,(R/'mxfp4-rows.c').read_text()+'\n'+needle,1);p.write_text(s)
p=dst/'ggml/src/ggml-cpu/quants.h';s=p.read_text();s=s.replace('void ggml_vec_dot_nvfp4_q8_0(', '#if defined(__x86_64__)\nvoid ggml_vec_dot_mxfp4_q8_0_rows2(int n, float * s, const void * vx, size_t row_stride, const void * vy);\n#endif\nvoid ggml_vec_dot_nvfp4_q8_0(',1);p.write_text(s)
p=dst/'ggml/src/ggml-cpu/ggml-cpu.c';s=p.read_text();before='''                for (int64_t ir0 = iir0; ir0 < iir0 + blck_0 && ir0 < ir0_end; ++ir0) {
                    vec_dot(ne00, &tmp[ir0 - iir0], 0, src0_cur + ir0*nb01, 0, src1_col, 0, 1);
                }''';after='''                int64_t ir0 = iir0;
#if defined(__x86_64__)
                if (type == GGML_TYPE_MXFP4) {
                    for (; ir0 + 1 < MIN(iir0 + blck_0, ir0_end); ir0 += 2) {
                        ggml_vec_dot_mxfp4_q8_0_rows2(ne00, &tmp[ir0-iir0], src0_cur+ir0*nb01, nb01, src1_col);
                    }
                }
#endif
                for (; ir0 < iir0 + blck_0 && ir0 < ir0_end; ++ir0) {
                    vec_dot(ne00, &tmp[ir0 - iir0], 0, src0_cur + ir0*nb01, 0, src1_col, 0, 1);
                }''';assert s.count(before)==1;s=s.replace(before,after);p.write_text(s)
parts=[]
for f in ['ggml/src/ggml-cpu/arch/x86/quants.c','ggml/src/ggml-cpu/quants.h','ggml/src/ggml-cpu/ggml-cpu.c']:
 parts+=difflib.unified_diff((base/f).read_text().splitlines(True),(dst/f).read_text().splitlines(True),fromfile='a/'+f,tofile='b/'+f)
(E/'mxfp4-rows2.patch').write_text(''.join(parts))
