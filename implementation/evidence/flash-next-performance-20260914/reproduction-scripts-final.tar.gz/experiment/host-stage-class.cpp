// Bounded pinned staging preserves mapped model bytes and overlaps a host copy
// with earlier H2D transfers. Events prevent reuse until the GPU has read a slot.
struct ggml_sched_host_stage {
    struct slot {
        ggml_backend_buffer_t buffer = nullptr;
        ggml_backend_event_t event = nullptr;
        bool pending = false;
    };
    std::array<slot, 3> slots;
    size_t chunk = 8 * 1024 * 1024;
    size_t next = 0;
    bool ready = false, disabled = false;
    uint64_t calls = 0, bytes = 0;

    ~ggml_sched_host_stage() {
        for (auto & s : slots) {
            if (s.pending) ggml_backend_event_synchronize(s.event);
            if (s.event) ggml_backend_event_free(s.event);
            if (s.buffer) ggml_backend_buffer_free(s.buffer);
        }
        if (const char * path = getenv("AG1_FLASH_STAGE_TRACE")) {
            if (FILE * out = fopen(path, "a")) {
                fprintf(out, "{\"calls\":%llu,\"bytes\":%llu,\"chunk\":%zu,\"ready\":%s}\n",
                        (unsigned long long) calls, (unsigned long long) bytes, chunk, ready ? "true" : "false");
                fclose(out);
            }
        }
    }

    bool initialize(ggml_backend_t backend) {
        if (ready) return true;
        if (disabled) return false;
        disabled = true;
        auto dev = ggml_backend_get_device(backend);
        if (!dev || ggml_backend_dev_type(dev) == GGML_BACKEND_DEVICE_TYPE_CPU) return false;
        auto host_type = ggml_backend_dev_host_buffer_type(dev);
        if (!host_type || strcmp(ggml_backend_buft_name(host_type), "CUDA_Host")) return false;
        if (const char * value = getenv("AG1_FLASH_STAGE_MIB")) {
            const int mib = atoi(value);
            if (mib < 1 || mib > 64) return false;
            chunk = size_t(mib) * 1024 * 1024;
        }
        for (auto & s : slots) {
            s.buffer = ggml_backend_buft_alloc_buffer(host_type, chunk);
            if (!s.buffer || ggml_backend_buffer_get_type(s.buffer) != host_type) return false;
            s.event = ggml_backend_event_new(dev);
            if (!s.event) return false;
        }
        ready = true;
        GGML_LOG_INFO("bounded host staging: 3 x %zu bytes pinned\n", chunk);
        return true;
    }

    bool copy(ggml_backend_t backend, const void * src, ggml_tensor * dst, size_t offset, size_t size) {
        if (!initialize(backend)) return false;
        GGML_ASSERT(offset <= ggml_nbytes(dst) && size <= ggml_nbytes(dst) - offset);
        for (size_t done = 0; done < size;) {
            auto & s = slots[next];
            if (s.pending) ggml_backend_event_synchronize(s.event);
            const size_t count = std::min(chunk, size - done);
            void * host = ggml_backend_buffer_get_base(s.buffer);
            memcpy(host, (const char *) src + done, count);
            ggml_backend_tensor_set_async(backend, dst, host, offset + done, count);
            ggml_backend_event_record(s.event, backend);
            s.pending = true;
            next = (next + 1) % slots.size();
            done += count;
        }
        ++calls;
        bytes += size;
        return true;
    }
};
