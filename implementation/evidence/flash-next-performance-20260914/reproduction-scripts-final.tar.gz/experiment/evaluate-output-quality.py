"""Separate strict formatting, content agreement, and full-answer coverage."""
import argparse
import hashlib
import json
import re
from pathlib import Path

E = Path('/home/alex/Projects/AG1/implementation/evidence/flash-next-performance-20260914')
parser = argparse.ArgumentParser()
parser.add_argument('runs', nargs='+')
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
prompts = json.loads((E / 'prompts.json').read_text())
if (E / 'prompts-additional.json').exists():
    prompts.update(json.loads((E / 'prompts-additional.json').read_text()))
for filename, key in [('prompts-long-context.json', 'long80k')]:
    if (E / filename).exists():
        prompts[key] = json.loads((E / filename).read_text())
records = []
for name in args.runs:
    result = json.loads((E / 'runs' / name / 'result.json').read_text())
    for request in result['requests']:
        text = request['output']
        workload = request['workload']
        prompt = prompts.get(workload, {})
        trimmed = text.strip()
        fence = re.fullmatch(r'```[^\n]*\n(.*?)\n```', trimmed, flags=re.DOTALL)
        content = fence.group(1) if fence else trimmed
        row = {'run': name, 'workload': workload, 'repeat': request['repeat'],
               'word_count': len(text.split()), 'stop_type': request.get('stop_type'),
               'sha256': hashlib.sha256(text.encode()).hexdigest(), 'outer_fence': bool(fence)}
        if 'expected' in prompt:
            for label, value in [('strict_json', text), ('json_after_removing_outer_fence', content)]:
                try:
                    parsed = json.loads(value)
                    row[label] = {'parses': True, 'matches_expected': parsed == prompt['expected']}
                except (ValueError, TypeError):
                    row[label] = {'parses': False, 'matches_expected': False}
        if 'expected_output' in prompt:
            expected = prompt['expected_output']
            row['exact_bytes_pass'] = text.encode() == expected.encode()
            row['content_after_outer_whitespace_pass'] = trimmed == expected.strip()
            row['content_after_outer_fence_pass'] = content.strip() == expected.strip()
        if workload in {'review', 'reasoning'}:
            row['minimum_500_words_pass'] = row['word_count'] >= 500
        if workload == 'prose':
            row['requested_words'] = 500
            row['word_count_difference'] = row['word_count'] - 500
        records.append(row)
args.output.write_text(json.dumps({'scope': 'Mechanical checks only. Factuality, reasoning, instruction adherence, and actual AG1 file bytes require separate adjudication.', 'records': records}, indent=2) + '\n')
