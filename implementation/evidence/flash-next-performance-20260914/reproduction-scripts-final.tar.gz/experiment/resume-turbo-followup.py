import json,statistics
from bench import ROOT as R,EVID as E,run
assert json.loads((E/'turbo-flat-build-result.json').read_text())['status']=='built'
fixture=json.loads((E/'turbo-flat-fixture-result.json').read_text())
assert len(fixture)==63 and all(x['equal'] for x in fixture)
base=json.loads((E/'runs/turbo-history-cache/result.json').read_text())['config']
base={k:v for k,v in base.items() if k not in ['state_equivalence','teacher_force','teacher_force_count']}
c={**base,'name':'turbo-flat-cache','binary':str(R/'bundle-turbo-flat/llama-server'),
   'environment':{**base['environment'],'AG1_FLASH_FLAT_CPU_MISSES':'1'},
   'workloads':['review','prose','edit','conversation'],'repetitions':3,'api_smoke':True,
   'teacher_force':['prose','edit'],'teacher_force_count':32}
(R/(c['name']+'.json')).write_text(json.dumps(c,indent=2));flat=run(c)
control=json.loads((E/'runs/turbo-history-cache/result.json').read_text())
def rate(d,w):return statistics.median(r['timings']['predicted_per_second'] for r in d['requests'] if r['workload']==w)
if flat['status']=='passed' and flat.get('api_smoke',{}).get('tool_call_pass') and all(r.get('quality_content_pass',False) for r in flat['requests'] if r['workload']=='edit'):
 ratios={w:rate(flat,w)/rate(control,w) for w in ['review','prose','edit','conversation']}
 use_flat=min(ratios.values())>=.98 and max(ratios.values())>=1.03
 (E/'turbo-flat-screen-selection.json').write_text(json.dumps({'ratios':ratios,'provisional_followup_use':use_flat,'scope':'Screen selection only; balanced final repeats still required.'},indent=2))
 if use_flat:base={**base,'binary':c['binary'],'environment':c['environment']}
variants=[
 ('reserve1024',{}, {'GGML_CUDA_MOE_CACHE_RESERVE_MB':'1024'}),
 ('threads8',{'--threads':'8','--cpu-range':'0-7'},{}),
 ('threads6',{'--threads':'6','--cpu-range':'0-5'},{}),
 ('low-churn',{}, {'GGML_CUDA_MOE_CACHE_INSERTS':'1','GGML_CUDA_MOE_CACHE_THROTTLE':'32'}),
 ('async-fill',{}, {'GGML_CUDA_MOE_CACHE_SERIAL_FILL':'0'}),
 ('overlap0',{}, {'GGML_CUDA_MOE_CACHE_OVERLAP_CPU_ROWS':'0'}),
 ('overlap4',{}, {'GGML_CUDA_MOE_CACHE_OVERLAP_CPU_ROWS':'4'}),
 ('overlap8',{}, {'GGML_CUDA_MOE_CACHE_OVERLAP_CPU_ROWS':'8'}),
 ('no-cpu-fusion',{}, {'GGML_CPU_DISABLE_FUSION':'1'}),
 ('batch1536',{'--batch-size':'1536','--ubatch-size':'1536'},{'GGML_CUDA_MOE_CACHE_RESERVE_MB':'1024'}),
 ('batch2048-cache4480',{'--batch-size':'2048','--ubatch-size':'2048','--moe-cache':'4480'},{'GGML_CUDA_MOE_CACHE_RESERVE_MB':'1024'}),
]
for name,flags,env in variants:
 c={**base,'name':'turbo-followup-'+name,'flags':{**base['flags'],**flags},'environment':{**base['environment'],**env},
    'workloads':['review','prose','edit'],'repetitions':2}
 (R/(c['name']+'.json')).write_text(json.dumps(c,indent=2));run(c)
for maximum in [2,4]:
 c={**base,'name':'turbo-followup-ngram'+str(maximum),
    'flags':{**base['flags'],'--spec-type':'ngram-mod','--spec-ngram-mod-n-min':'2',
             '--spec-ngram-mod-n-max':str(maximum),'--spec-ngram-mod-n-match':'24'},
    'workloads':['prose','edit','repetitive'],'repetitions':2}
 (R/(c['name']+'.json')).write_text(json.dumps(c,indent=2));run(c)
(E/'turbo-followup-done.json').write_text(json.dumps({'status':'finished'}))
