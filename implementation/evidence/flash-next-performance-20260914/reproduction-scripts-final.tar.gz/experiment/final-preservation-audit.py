"""Rehash protected materials only after all inference and build work stops."""
import hashlib
import json
import os
import subprocess
import time
from pathlib import Path

E = Path('/home/alex/Projects/AG1/implementation/evidence/flash-next-performance-20260914')
output = E / 'final-preservation-audit.json'
assert not output.exists(), 'Keep prior audit evidence; use a new output path for a new audit.'
for proc in Path('/proc').iterdir():
    if not proc.name.isdigit():
        continue
    try:
        executable = (proc / 'exe').resolve(strict=True).name
    except OSError:
        continue
    assert executable not in {'llama-server', 'llama-bench', 'nvcc', 'ninja', 'cc1plus', 'cc1'}, (proc.name, executable)


def digest(path):
    with path.open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


report = {'started_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), 'protected': [], 'models': [], 'mtp': [], 'sources': [], 'installed_package': []}
for name, expected in json.loads((E / 'protected-before.json').read_text()).items():
    path = Path(name)
    actual = {'size': path.stat().st_size, 'sha256': digest(path),
              'symlink': os.readlink(path) if path.is_symlink() else None}
    report['protected'].append({'path': name, 'actual': actual, 'matches': actual == expected})
for category, manifest, size_key in [('models', 'model-materials-before.json', 'size'), ('mtp', 'mtp-before.json', 'bytes')]:
    for expected in json.loads((E / manifest).read_text()):
        path = Path(expected['path'])
        actual = {'size': path.stat().st_size, 'sha256': digest(path)}
        report[category].append({'path': str(path), 'actual': actual,
                                 'matches': actual['size'] == expected[size_key] and actual['sha256'] == expected['sha256']})
        print('Hashed', path.name, report[category][-1]['matches'], flush=True)
        (E / 'final-preservation-audit-progress.json').write_text(json.dumps(report, indent=2))
for root, expected in json.loads((E / 'original-source.json').read_text()).items():
    actual = {key: subprocess.check_output(['git', '-C', root, *args], text=True).strip()
              for key, args in [('commit', ['rev-parse', 'HEAD']), ('status', ['status', '--porcelain']), ('remotes', ['remote', '-v'])]}
    report['sources'].append({'path': root, 'actual': actual, 'matches': actual == expected})
release = os.readlink('/opt/ag1/current')
expected_release = json.loads((E / 'preservation-at-user-pause.json').read_text())['production_release']
report['production_release'] = {'actual': release, 'resolved': str(Path('/opt/ag1/current').resolve()), 'expected': expected_release, 'matches': release == expected_release}
package = json.loads((E / 'resume-installed-package-reference.json').read_text())
report['installed_package_reference'] = {
    'scope': package['scope'],
    'manifest_unchanged': digest(Path(package['manifest_path'])) == package['manifest_sha256'],
    'release_unchanged': str(Path('/opt/ag1/current').resolve()) == package['release'],
}
for expected in package['files']:
    relative = Path(expected['path'])
    assert not relative.is_absolute() and '..' not in relative.parts
    path = Path(package['release']) / relative
    try:
        actual = {'size': path.stat().st_size, 'sha256': digest(path)}
        matches = actual['size'] == expected['bytes'] and actual['sha256'] == expected['sha256']
    except OSError as error:
        actual, matches = {'error': repr(error)}, False
    report['installed_package'].append({'path': str(path), 'actual': actual, 'matches': matches})
report['passed'] = (all(row['matches'] for category in ['protected', 'models', 'mtp', 'sources', 'installed_package'] for row in report[category])
                    and report['production_release']['matches']
                    and report['installed_package_reference']['manifest_unchanged']
                    and report['installed_package_reference']['release_unchanged'])
report['finished_utc'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
output.write_text(json.dumps(report, indent=2) + '\n')
assert report['passed'], 'Preservation mismatch; inspect the retained audit.'
print('Full preservation audit passed.', flush=True)
