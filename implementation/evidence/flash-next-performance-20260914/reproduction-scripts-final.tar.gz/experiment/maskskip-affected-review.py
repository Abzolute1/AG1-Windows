"""Probe fixed prefixes above the attention patch threshold, including a repeat control."""
import json
from bench import ROOT as R, EVID as E, run

for label, binary in [('base-a', R/'build-new-ada/bin/llama-server'),
                      ('candidate', R/'bundle-new-maskskip/llama-server'),
                      ('base-b', R/'build-new-ada/bin/llama-server')]:
    config = {'name': 'maskskip-affected-review-'+label, 'binary': str(binary),
              'workloads': ['review'], 'repetitions': 1, 'n_predict': 64,
              'teacher_force': ['review'], 'teacher_force_count': 64,
              'teacher_force_source_run': 'baseline-01',
              'purpose': 'Fixed-prefix probability diagnostic above the maskskip activation threshold; repeat control measures numerical variability.'}
    (R/(config['name']+'.json')).write_text(json.dumps(config, indent=2))
    result = run(config)
    if result['status'] != 'passed':
        raise RuntimeError((config['name'], result.get('error')))
(E/'maskskip-affected-review-done.json').write_text(json.dumps({'status': 'finished', 'comparison_pending': True}))
