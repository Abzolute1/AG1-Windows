import json,time
from pathlib import Path
from bench import run,EVID
p=EVID/'runs/baseline-01/result.json'
while True:
 try:
  d=json.loads(p.read_text())
  if d.get('status'):
   assert d['status']=='passed',d
   break
 except (FileNotFoundError,json.JSONDecodeError):pass
 time.sleep(5)
import subprocess
subprocess.run(['python',str(Path(__file__).parent/'fetch_sources.py')],check=True)
# Discovery screens use real frozen workloads; finalists need a repeated full comparison.
configs=[
 {'name':'threads6-batch12','flags':{'--threads':6,'--threads-batch':12,'--cpu-range':'0-5','--cpu-range-batch':'0-11'}},
 {'name':'threads8-batch12','flags':{'--threads':8,'--threads-batch':12,'--cpu-range':'0-7','--cpu-range-batch':'0-11'}},
 {'name':'threads12-batch12','flags':{'--threads-batch':12,'--cpu-range-batch':'0-11'}},
 {'name':'poll0','flags':{'--poll':0}},
 {'name':'cpu-moe41','flags':{'--n-cpu-moe':41}},
 {'name':'batch2048','flags':{'--batch-size':2048,'--ubatch-size':2048}},
 {'name':'batch2048-cpu44','flags':{'--batch-size':2048,'--ubatch-size':2048,'--n-cpu-moe':44}},
]
for c in configs:
 c.update(workloads=['review','prose','edit'],repetitions=2,n_predict=256)
 (Path(__file__).parent/(c['name']+'.json')).write_text(json.dumps(c,indent=2))
 result=run(c)
 if 'Another GPU' in result.get('error',''):break
