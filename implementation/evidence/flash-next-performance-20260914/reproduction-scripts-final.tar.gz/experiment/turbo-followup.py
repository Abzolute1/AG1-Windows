import json,statistics,subprocess
from bench import ROOT as R,EVID as E,run
paths=[E/'runs'/('turbo-ple-'+n)/'result.json' for n in ['lazy-reuse-cache6000','lazy-reuse-cache6000-min256']]
available=[json.loads(p.read_text()) for p in paths if p.exists()]
available=[d for d in available if d.get('status')=='passed']
if not available:
 print('No valid repaired hybrid-cache arm; skipping dependent tuning',flush=True)
else:
 # Rank ordinary prose only for follow-up selection. Keep edit/prefill outcomes
 # separate; this is not an aggregate victory score or a final recommendation.
 best=max(available,key=lambda d:statistics.median(x['timings']['predicted_per_second'] for x in d['requests'] if x['workload']=='prose'))
 base=best['config'];(E/'turbo-followup-selection.json').write_text(json.dumps({'source':best['name'],'criterion':'highest median prose decode among valid repaired cache arms, provisional screen selection'},indent=2))
 # Source review found a short PLE-history rewind concern. Diagnose both
 # preserved original and repaired fork before interpreting speculation speed.
 for label,diagnostic in [('original',{}),('fork-cacheoff',{'binary':base['binary'],
      'environment':base['environment'],'flags':{'--moe-cache':'off','--n-cpu-moe':'42','--verbosity':'4'}})]:
  c={**diagnostic,'name':'state-equivalence-'+label,'workloads':[],
     'state_equivalence':True,'teacher_force':['prose','edit'],'teacher_force_count':32}
  (R/(c['name']+'.json')).write_text(json.dumps(c,indent=2));run(c)
 # Build only after both diagnostic servers have been stopped by run(). The
 # retained-prefix repair makes rollback semantics testable before speculation.
 subprocess.run(['python',str(R/'prepare-turbo-history.py')],check=True)
 repaired={**base,'binary':str(R/'bundle-turbo-history/llama-server'),
           'environment':{**base['environment'],'AG1_FLASH_PLE_HISTORY':'1','GGML_CUDA_MOE_CACHE_STATS':'10000'}}
 for label,flags in [('cacheoff',{'--moe-cache':'off','--n-cpu-moe':'42','--verbosity':'4'}),('cache',base['flags'])]:
  c={**repaired,'name':'turbo-history-'+label,'flags':flags,'workloads':['review','prose','edit','conversation'],
     'repetitions':3,'state_equivalence':True,'teacher_force':['prose','edit'],'teacher_force_count':32,'api_smoke':True}
  (R/(c['name']+'.json')).write_text(json.dumps(c,indent=2))
  result=run(c)
  if result['status']!='passed':raise RuntimeError('Retained PLE history validation failed: '+label)
  if not result.get('api_smoke',{}).get('tool_call_pass'):
   raise RuntimeError('Retained PLE history failed native function-call validation: '+label)
  if not all(x.get('quality_content_pass',False) for x in result['requests'] if x['workload']=='edit'):
   raise RuntimeError('Retained PLE history corrupted exact-edit content')
 base=repaired
 subprocess.run(['python',str(R/'prepare-turbo-flat.py')],check=True)
 c={**base,'name':'turbo-flat-cache','binary':str(R/'bundle-turbo-flat/llama-server'),
    'environment':{**base['environment'],'AG1_FLASH_FLAT_CPU_MISSES':'1'},
    'workloads':['review','prose','edit','conversation'],'repetitions':3,'api_smoke':True,
    'teacher_force':['prose','edit'],'teacher_force_count':32}
 (R/(c['name']+'.json')).write_text(json.dumps(c,indent=2));flat=run(c)
 control=json.loads((E/'runs/turbo-history-cache/result.json').read_text())
 def rate(d,w):return statistics.median(r['timings']['predicted_per_second'] for r in d['requests'] if r['workload']==w)
 if flat['status']=='passed' and flat.get('api_smoke',{}).get('tool_call_pass') and all(r.get('quality_content_pass',False) for r in flat['requests'] if r['workload']=='edit'):
  ratios={w:rate(flat,w)/rate(control,w) for w in ['review','prose','edit','conversation']}
  use_flat=min(ratios.values())>=.98 and max(ratios.values())>=1.03
  (E/'turbo-flat-screen-selection.json').write_text(json.dumps({'ratios':ratios,'provisional_followup_use':use_flat,'scope':'Screen selection only; balanced final repeats still required.'},indent=2))
  if use_flat:base={**base,'binary':c['binary'],'environment':c['environment']}
 variants=[
  ('reserve1024',{}, {'GGML_CUDA_MOE_CACHE_RESERVE_MB':'1024'}),
  ('threads8',{'--threads':'8','--cpu-range':'0-7'},{}),
  ('threads6',{'--threads':'6','--cpu-range':'0-5'},{}),
  ('low-churn',{}, {'GGML_CUDA_MOE_CACHE_INSERTS':'1','GGML_CUDA_MOE_CACHE_THROTTLE':'32'}),
  ('async-fill',{}, {'GGML_CUDA_MOE_CACHE_SERIAL_FILL':'0'}),
  ('overlap0',{}, {'GGML_CUDA_MOE_CACHE_OVERLAP_CPU_ROWS':'0'}),
  ('overlap4',{}, {'GGML_CUDA_MOE_CACHE_OVERLAP_CPU_ROWS':'4'}),
  ('overlap8',{}, {'GGML_CUDA_MOE_CACHE_OVERLAP_CPU_ROWS':'8'}),
  ('no-cpu-fusion',{}, {'GGML_CPU_DISABLE_FUSION':'1'}),
  ('batch1536',{'--batch-size':'1536','--ubatch-size':'1536'},{'GGML_CUDA_MOE_CACHE_RESERVE_MB':'1024'}),
  ('batch2048-cache4480',{'--batch-size':'2048','--ubatch-size':'2048','--moe-cache':'4480'},{'GGML_CUDA_MOE_CACHE_RESERVE_MB':'1024'}),
 ]
 for name,flags,env in variants:
  c={**base,'name':'turbo-followup-'+name,'flags':{**base['flags'],**flags},'environment':{**base['environment'],**env},
     'workloads':['review','prose','edit'],'repetitions':2}
  (R/(c['name']+'.json')).write_text(json.dumps(c,indent=2));run(c)
 for maximum in [2,4]:
  c={**base,'name':'turbo-followup-ngram'+str(maximum),
     'flags':{**base['flags'],'--spec-type':'ngram-mod','--spec-ngram-mod-n-min':'2',
              '--spec-ngram-mod-n-max':str(maximum),'--spec-ngram-mod-n-match':'24'},
     'workloads':['prose','edit','repetitive'],'repetitions':2}
  (R/(c['name']+'.json')).write_text(json.dumps(c,indent=2));run(c)
(E/'turbo-followup-done.json').write_text(json.dumps({'status':'finished'}))
