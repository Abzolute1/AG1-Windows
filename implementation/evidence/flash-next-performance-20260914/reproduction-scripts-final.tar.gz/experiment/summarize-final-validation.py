"""Summarize the fixed closeout suite; never launches inference."""
import hashlib,json,statistics
from pathlib import Path
E=Path('/home/alex/Projects/AG1/implementation/evidence/flash-next-performance-20260914')
names=[f'final-{arm}-{cycle}' for cycle in range(2) for arm in ['original','config-only','candidate']]+['final-long80k-original-0','final-long80k-candidate-0']
runs=[];pending=[];groups={};answers={}
for name in names:
 p=E/'runs'/name/'result.json'
 if not p.exists():pending.append(name);continue
 r=json.loads(p.read_text())
 if r.get('status')!='passed':pending.append(name);continue
 meta={k:r.get(k) for k in ['name','status','load_seconds','peak_process_vram_mib','peak_rss_mib','peak_rss_hwm_mib','api_smoke']}
 smaps=(p.parent/'smaps-ready.txt').read_text().splitlines()
 meta['ready_smaps_mib']={field.rstrip(':'):sum(int(line.split()[1]) for line in smaps if line.startswith(field))/1024 for field in ['Rss:','Anonymous:','Private_Dirty:','Locked:','Swap:']}
 runs.append(meta)
 arm=name.removeprefix('final-long80k-').removeprefix('final-').rsplit('-',1)[0]
 for q in r['requests']:
  h=hashlib.sha256(q['output'].encode()).hexdigest()
  answers.setdefault(h,{'workload':q['workload'],'word_count':len(q['output'].split()),'runs':[]})['runs'].append(name)
  groups.setdefault((arm,q['workload']),[]).append({'prefill_tps':q['timings']['prompt_per_second'],'decode_tps':(q['timings']['predicted_n']-1)*1000/q['timings']['predicted_ms'],'ttft_seconds':q['ttft_seconds'],'wall_seconds':q['wall_seconds'],'predicted_tokens':q['timings']['predicted_n'],'stop_type':q.get('stop_type'),'sha256':h})
rows=[]
for (arm,workload),qs in sorted(groups.items()):
 row={'arm':arm,'workload':workload,'n':len(qs),'samples':qs}
 for k in ['prefill_tps','decode_tps','ttft_seconds','wall_seconds','predicted_tokens']:
  vs=[q[k] for q in qs if q[k] is not None]
  row[k]={'mean':statistics.mean(vs),'min':min(vs),'max':max(vs)}
 rows.append(row)
x={'complete':not pending,'pending':pending,'scope':'Two reversed process orders for full answers; one final long pair supplements six prior long runs. No statistical universal-win claim. Different answer lengths affect wall latency.','runs':runs,'workloads':rows,'unique_answers':answers}
(E/'final-validation-summary.json').write_text(json.dumps(x,indent=2)+'\n')
print(json.dumps({'complete':x['complete'],'completed_runs':len(runs),'pending':pending}))
for r in rows:print(r['arm'],r['workload'],'n='+str(r['n']),'prefill=%.2f'%r['prefill_tps']['mean'],'decode=%.2f'%r['decode_tps']['mean'],'wall=%.2f'%r['wall_seconds']['mean'])
