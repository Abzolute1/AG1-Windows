import json,subprocess,shutil,time,os,hashlib
from pathlib import Path
R=Path('/home/alex/Projects/flash-next-perf-20260914');E=Path('/home/alex/Projects/AG1/implementation/evidence/flash-next-performance-20260914')
while not (E/'fourth-screen-done.json').exists():time.sleep(3)
def call(cmd,label,env=None):
 print(label,flush=True)
 with (E/(label+'.log')).open('w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True,env=env)
base=json.loads((E/'cow-build-command.json').read_text())['configure']
for label,target,base_bundle,library in [('cpu-flat','ggml-cpu','register','libggml-cpu.so*'),('pool-efficient','ggml-base','stage','libggml-base.so*')]:
 call(['python',str(R/('port-'+('cpu-flat' if label=='cpu-flat' else 'pool-efficient')+'.py'))],label+'-port')
 src=R/('source-new-'+label);build=R/('build-new-'+label);bundle=R/('bundle-new-'+label)
 cmd=base.copy();cmd[cmd.index('-S')+1]=str(src);cmd[cmd.index('-B')+1]=str(build)
 (E/(label+'-build-command.json')).write_text(json.dumps({'configure':cmd,'target':target},indent=2))
 call(cmd,label+'-configure');call(['cmake','--build',str(build),'--target',target,'-j8'],label+'-build')
 shutil.copytree(R/('bundle-new-'+base_bundle),bundle,symlinks=True)
 for p in (build/'bin').glob(library):
  d=bundle/p.name
  if d.exists() or d.is_symlink():d.unlink()
  if p.is_symlink():d.symlink_to(os.readlink(p))
  else:shutil.copy2(p,d)
call(['python',str(R/'prepare-flat-fixture.py')],'flat-fixture-prepare')
b=R/'bundle-new-register';src=R/'source-new-register'
cmd=['g++','-std=c++20','-O2','-fopenmp','-I'+str(src/'ggml/include'),str(R/'test-flash-mmid.cpp'),'-L'+str(b),'-Wl,-rpath,'+str(b),'-Wl,--export-dynamic','-lggml-cpu','-lggml-base','-ldl','-pthread','-o',str(R/'test-flash-mmid')]
call(cmd,'flat-fixture-build')
for arm in ['register','cpu-flat']:
 out=E/('flat-fixture-'+arm);out.mkdir()
 env=os.environ.copy();env['LD_LIBRARY_PATH']=str(R/('bundle-new-'+arm));env['AG1_MMID_OUTPUT_DIR']=str(out)
 call([str(R/'test-flash-mmid'),'--allow-no-coverage'],'flat-fixture-'+arm,env)
a=E/'flat-fixture-register';b=E/'flat-fixture-cpu-flat';checks=[]
for p in a.glob('*.f32'):
 q=b/p.name;checks.append({'name':p.name,'bytes':p.stat().st_size,'equal':p.read_bytes()==q.read_bytes()})
assert checks and all(x['equal'] for x in checks)
(E/'flat-fixture-result.json').write_text(json.dumps({'checks':checks,'status':'bit-identical'},indent=2))
# Full CUDA build: do not mix a new upstream graph ABI with the Unsloth backend.
for label,src in [('upstream-ada',R/'upstream-source/ggml-org-llama.cpp-97e4ca7'),('new-ada',R/'unsloth-new-source/llama.cpp-b10909-mix-bea84f7')]:
 build=R/('build-'+label)
 cmd=base.copy();cmd[cmd.index('-S')+1]=str(src);cmd[cmd.index('-B')+1]=str(build);cmd.remove('-DGGML_CUDA=OFF')
 cmd+=['-DCMAKE_C_COMPILER=/usr/bin/gcc-15','-DCMAKE_CXX_COMPILER=/usr/bin/g++-15','-DCMAKE_CUDA_HOST_COMPILER=/usr/bin/g++-15','-DCMAKE_CUDA_COMPILER=/opt/cuda/bin/nvcc','-DCMAKE_CUDA_ARCHITECTURES=89','-DGGML_CUDA=ON','-DGGML_CUDA_GRAPHS=ON','-DGGML_CUDA_FA_ALL_QUANTS=ON','-DGGML_CUDA_NCCL=OFF']
 (E/(label+'-build-command.json')).write_text(json.dumps({'configure':cmd},indent=2))
 try:
  call(cmd,label+'-configure');call(['cmake','--build',str(build),'--target','llama-server','-j8'],label+'-build')
  (E/(label+'-build-result.json')).write_text(json.dumps({'status':'built','binary':str(build/'bin/llama-server')}))
 except subprocess.CalledProcessError as error:
  (E/(label+'-build-result.json')).write_text(json.dumps({'status':'failed','error':str(error)}))
(E/'fifth-preparation-done.json').write_text(json.dumps({'status':'finished'}))
