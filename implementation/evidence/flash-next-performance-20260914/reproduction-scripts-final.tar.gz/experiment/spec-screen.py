import time,json
from bench import run,EVID,ROOT
# Run only when explicitly started after preparation; fresh server per independent arm.
for cycle in range(2):
 for maximum in ([0,4,8,16] if cycle==0 else [16,8,4,0]):
  for workload in ['edit','prose','reasoning','repetitive']:
   c={'name':f'spec-original-{maximum}-{workload}-{cycle}','workloads':[workload],'repetitions':1,'n_predict':256}
   if maximum:
    c['flags']={'--spec-type':'ngram-mod','--spec-ngram-mod-n-max':str(maximum),'--spec-ngram-mod-n-min':'2','--spec-ngram-mod-n-match':'24'}
   (ROOT/(c['name']+'.json')).write_text(json.dumps(c,indent=2));result=run(c)
   if result['status']!='passed':break
(EVID/'spec-screen-done.json').write_text(json.dumps({'status':'finished'}))
