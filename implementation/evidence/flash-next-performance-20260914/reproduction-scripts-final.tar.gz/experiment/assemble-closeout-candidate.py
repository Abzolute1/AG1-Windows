"""Combine the already-screened COW and masked-attention changes for final validation."""
import hashlib
import json
import os
import shutil
from pathlib import Path

R = Path('/home/alex/Projects/flash-next-perf-20260914')
E = Path('/home/alex/Projects/AG1/implementation/evidence/flash-next-performance-20260914')
for p in Path('/proc').iterdir():
    if not p.name.isdigit():
        continue
    try:
        name = (p / 'exe').resolve(strict=True).name
    except OSError:
        continue
    assert name not in {'llama-server', 'llama-bench', 'nvcc', 'ninja', 'cc1plus', 'rustc'}, (p.name, name)

def digest(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

cow = R / 'bundle-new-cow-prefault'
mask = R / 'bundle-new-maskskip'
destination = R / 'bundle-closeout-cow-mask'
assert not destination.exists()
headers = ['include/llama.h', 'ggml/include/ggml.h', 'ggml/include/ggml-backend.h', 'ggml/src/ggml-backend-impl.h']
header_hashes = {}
for rel in headers:
    left = R / 'source-new-cow' / rel
    right = R / 'unsloth-new-source/llama.cpp-b10909-mix-bea84f7' / rel
    assert left.read_bytes() == right.read_bytes(), ('ABI header mismatch', rel)
    header_hashes[rel] = digest(left)
expected_cow = json.loads((E / 'cow-prefault-build-result.json').read_text())['library_sha256']
assert digest(cow / 'libllama.so.0.4.0') == expected_cow
shutil.copytree(cow, destination, symlinks=True)
cuda = destination / 'libggml-cuda.so'
assert cuda.is_file() and not cuda.is_symlink() and cuda.stat().st_nlink == 1
shutil.copy2(mask / 'libggml-cuda.so', cuda)
manifest = {'base_revision': '329b6160f513915f1c607dbfae3d5ce864a64a4f',
            'assembly': {'base_bundle': str(cow), 'replacement_library': str(mask / 'libggml-cuda.so')},
            'abi_header_hashes': header_hashes,
            'scope': 'Already-screened private expert pinning plus masked Q8 attention; stock ngram-mod with twelve verification threads. No adaptive drafting, recurrent snapshot extension, bulk copy, pool, staging or Turbo runtime.',
            'files': [{'path': str(p), 'sha256': digest(p), 'symlink': os.readlink(p) if p.is_symlink() else None}
                      for p in sorted(destination.iterdir()) if p.is_file()]}
(E / 'closeout-candidate-assembly.json').write_text(json.dumps(manifest, indent=2) + '\n')
config = {'binary': str(destination / 'llama-server'),
          'environment': {'AG1_FLASH_REGISTER_COW': '1', 'AG1_FLASH_COW_PREFAULT_THREADS': '0'},
          'flags': {'--threads-batch': '12', '--cpu-range-batch': '0-11',
                    '--spec-type': 'ngram-mod', '--spec-ngram-mod-n-max': '16',
                    '--spec-ngram-mod-n-min': '2', '--spec-ngram-mod-n-match': '24'}}
with (R / 'closeout-candidate.json').open('x') as f:
    json.dump(config, f, indent=2)
print('Assembled one candidate for final validation:', destination, flush=True)
