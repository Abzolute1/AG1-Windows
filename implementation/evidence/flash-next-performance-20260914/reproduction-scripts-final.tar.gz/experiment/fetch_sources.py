import json,urllib.request,hashlib,tarfile
from pathlib import Path
R=Path('/home/alex/Projects/flash-next-perf-20260914');E=Path('/home/alex/Projects/AG1/implementation/evidence/flash-next-performance-20260914')
archives=R/'downloads';archives.mkdir(exist_ok=True)
old=json.loads((E/'original-release.json').read_text());new=json.loads((E/'unsloth-latest.json').read_text())
items=[]
for release,needle,dest in [(old,'llama.cpp-source-commit-','original-source'),(new,'llama.cpp-source-commit-','unsloth-new-source'),(new,'linux-x64-cuda13-newer.tar.gz','unsloth-new-bundle')]:
 asset=next(a for a in release['assets'] if needle in a['name']);items.append((asset,dest))
manifest=[]
for asset,dest in items:
 p=archives/asset['name']
 if not p.exists():
  print('Downloading',asset['name'],asset['size'],flush=True)
  with urllib.request.urlopen(asset['browser_download_url'],timeout=90) as src,p.open('wb') as out:
   while chunk:=src.read(2**20):out.write(chunk)
 assert p.stat().st_size==asset['size']
 with p.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
 if asset.get('digest'):assert asset['digest']=='sha256:'+digest
 target=R/dest;target.mkdir(exist_ok=True)
 if not (target/'.extracted').exists():
  with tarfile.open(p) as f:f.extractall(target,filter='data')
  (target/'.extracted').write_text(digest+'\n')
 manifest.append({'asset':asset['name'],'url':asset['browser_download_url'],'sha256':digest,'bytes':p.stat().st_size,'directory':str(target)})
 print('Prepared',dest,flush=True)
(E/'download-manifest.json').write_text(json.dumps(manifest,indent=2))

import subprocess
subprocess.run(["python",str(R/"prepare_perf.py")],check=True)
