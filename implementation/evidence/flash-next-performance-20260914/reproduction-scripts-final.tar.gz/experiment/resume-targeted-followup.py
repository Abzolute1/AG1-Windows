"""Close specific comparison gaps after the resume controller has exited.

No automatic launch or production changes. Fresh run names; fail on process
errors. Keep this bounded: batch size, matched Turbo control, snapshot/thread
interaction, and a shorter adaptive cooldown.
"""
import json
from pathlib import Path
from bench import ROOT as R, EVID as E, run

assert not (E / 'close-discovery-user-steering.json').exists(), 'User steering closed discovery; do not launch these optional screens.'

for p in Path('/proc').iterdir():
    if not p.name.isdigit():
        continue
    try:
        name = (p / 'exe').resolve(strict=True).name
    except OSError:
        continue
    assert name not in ['llama-server', 'llama-bench', 'nvcc', 'ninja', 'cc1plus'], (p.name, name)
marker = E / 'resume-targeted-followup-started.json'
with marker.open('x') as f:
    json.dump({'status': 'started'}, f)

def launch(c):
    with (R / (c['name'] + '.json')).open('x') as f:
        json.dump(c, f, indent=2)
    result = run(c)
    if result['status'] != 'passed':
        raise RuntimeError((c['name'], result.get('error')))
    return result

ngram = {'--threads-batch': '12', '--cpu-range-batch': '0-11',
         '--spec-type': 'ngram-mod', '--spec-ngram-mod-n-max': '16',
         '--spec-ngram-mod-n-min': '2', '--spec-ngram-mod-n-match': '24'}
arms = [(1024, False), (1536, False), (1536, True), (1024, True)]
for cycle, order in enumerate([arms, arms[::-1]]):
    for batch, spec in order:
        flags = {'--batch-size': str(batch), '--ubatch-size': str(batch)}
        if spec:
            flags.update(ngram)
        launch({'name': f'original-batch{batch}-spec{int(spec)}-followup{cycle}',
                'flags': flags, 'workloads': ['review', 'edit', 'prose', 'repetitive'],
                'repetitions': 1, 'n_predict': 256, 'api_smoke': True})

# The earlier fastest prose cache included 256 KiB experts, while the COW
# screen retained the 512 KiB control. Test the more inclusive cache with COW
# off/on and matched no-draft/draft order, rather than attributing cache warm-up
# or overlap calibration to drafting. Re-run both sides contemporaneously.
previous = json.loads((E / 'runs/turbo-combined-ngram16-t12/result.json').read_text())['config']
arms = [(False, False), (False, True), (True, True), (True, False)]
for cycle, order in enumerate([arms, arms[::-1]]):
    for cow, spec in order:
        flags = dict(previous['flags'])
        if not spec:
            flags = {k: v for k, v in flags.items() if not k.startswith('--spec-')}
        launch({**previous, 'name': f'turbo-matched-cow{int(cow)}-spec{int(spec)}-followup{cycle}',
                'binary': str(R / 'bundle-turbo-cow/llama-server'),
                'environment': {**previous['environment'], 'AG1_FLASH_TURBO_COW': str(int(cow)),
                                'AG1_FLASH_COW_PREFAULT_THREADS': '0'},
                'prewarm_weights': True,
                'flags': flags, 'workloads': ['prose', 'edit', 'repetitive'],
                'repetitions': 2, 'api_smoke': True})

# CPU44 leaves room for deeper recurrent snapshots without reducing precision.
# Depth8 also fits CPU42 by the observed ~934 MiB incremental allocation, so
# test it without moving two more expert layers to the CPU. Pair all controls.
arms = [(44, 8, False), (44, 8, True), (44, 16, False), (44, 16, True),
        (42, 8, False), (42, 8, True)]
for cycle, order in enumerate([arms, arms[::-1]]):
    for cpu, depth, enabled in order:
        launch({'name': f'ngram-rs-t12-cpu{cpu}-depth{depth}-enabled{int(enabled)}-followup{cycle}',
                'binary': str(R / 'bundle-new-ngram-rs/llama-server'),
                'environment': {'AG1_FLASH_NGRAM_RS': str(int(enabled))},
                'flags': {**ngram, '--n-cpu-moe': str(cpu), '--spec-ngram-mod-n-max': str(depth)},
                'workloads': ['edit', 'prose', 'repetitive'],
                'repetitions': 1, 'n_predict': 256, 'api_smoke': True,
                'state_equivalence': enabled and cycle == 0})

# Existing implementation exposes cooldown length: test bounded re-probing
# before introducing another source policy. Include matched fixed/no-draft arms.
for cycle, order in enumerate([['none', 'fixed', 'cooldown64'], ['cooldown64', 'fixed', 'none']]):
    for label in order:
        flags = dict(ngram) if label != 'none' else {'--threads-batch': '12', '--cpu-range-batch': '0-11'}
        launch({'name': f'ngram-cooldown-{label}-followup{cycle}',
                'binary': str(R / 'bundle-new-ngram-adaptive/llama-server'),
                'environment': {'AG1_FLASH_NGRAM_RS': '0',
                                'AG1_FLASH_NGRAM_ADAPTIVE': str(int(label == 'cooldown64')),
                                'AG1_FLASH_NGRAM_COOLDOWN': '64'},
                'flags': flags, 'prepare_extra': True,
                'workloads': ['edit', 'repetitive', 'copy_source', 'copy_repetitive', 'prose'],
                'repetitions': 1, 'n_predict': 256, 'api_smoke': True})

(E / 'resume-targeted-followup-done.json').write_text(json.dumps({'status': 'finished'}))
