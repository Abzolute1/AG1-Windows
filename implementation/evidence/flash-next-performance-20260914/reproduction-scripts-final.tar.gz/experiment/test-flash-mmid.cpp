// CPU-only exact-equality fixture. Never opens a GGUF or initializes CUDA.
// Optional helper-entry callback requires diagnostic-coverage.patch in a
// separate diagnostic CPU build. Do not use that build for performance claims.
#include "ggml.h"
#include "ggml-backend.h"
#include "ggml-cpu.h"
#include <algorithm>
#include <array>
#include <atomic>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <memory>
#include <set>
#include <stdexcept>
#include <string>
#include <vector>
#include <sched.h>
#include <omp.h>

namespace {
constexpr size_t guard = 128;
constexpr unsigned char sentinel = 0xA5;
constexpr int max_workers = 64;
struct WorkerVisit { int cpu = -1, affinity_status = -1; cpu_set_t allowed{}; };
std::array<WorkerVisit, max_workers> visits;
std::atomic<unsigned long long> entered{0};
std::atomic<int> reported_nth{0}, bad_callback{0};
std::atomic<const ggml_tensor *> expected_tensor{nullptr};

void require(bool good, const std::string & reason) {
    if (!good) throw std::runtime_error(reason);
}
std::string mask_text(const cpu_set_t & cpus) {
    std::string result;
    for (int i = 0; i < CPU_SETSIZE; ++i) if (CPU_ISSET(i, &cpus)) {
        if (!result.empty()) result += ',';
        result += std::to_string(i);
    }
    return result.empty() ? "empty" : result;
}
uint32_t random_word(uint32_t & state) {
    state ^= state << 13; state ^= state >> 17; state ^= state << 5; return state;
}
float random_float(uint32_t & state) {
    return (static_cast<int>(random_word(state) & 4095U) - 2048) / 1024.0f;
}
struct Buffer {
    ggml_backend_buffer_t handle = nullptr;
    ggml_tensor * tensor = nullptr;
    size_t bytes = 0;
    unsigned char * base = nullptr;
    explicit Buffer(ggml_tensor * t) : tensor(t), bytes(ggml_nbytes(t)) {
        handle = ggml_backend_buft_alloc_buffer(ggml_backend_cpu_buffer_type(), bytes + 2 * guard);
        require(handle != nullptr, "CPU buffer allocation failed");
        base = static_cast<unsigned char *>(ggml_backend_buffer_get_base(handle));
        std::memset(base, sentinel, bytes + 2 * guard);
        if (ggml_backend_tensor_alloc(handle, t, base + guard) != GGML_STATUS_SUCCESS) {
            ggml_backend_buffer_free(handle); handle = nullptr;
            throw std::runtime_error("tensor allocation failed");
        }
    }
    ~Buffer() { ggml_backend_buffer_free(handle); }
    Buffer(const Buffer &) = delete;
    Buffer & operator=(const Buffer &) = delete;
    void check_guards() const {
        for (size_t i = 0; i < guard; ++i) {
            require(base[i] == sentinel && base[guard + bytes + i] == sentinel,
                    std::string("outer guard overwritten: ") + ggml_get_name(tensor));
        }
    }
};
struct Case {
    const char * name;
    ggml_type weight;
    int k, m, experts, used, tokens, input_slots;
    bool padded = false, partner_input = false, reference = false;
    std::vector<int> threads{6};
};
void padded_rows(ggml_tensor * t, size_t row_padding, size_t plane_padding) {
    t->nb[1] += row_padding;
    t->nb[2] = t->nb[1] * t->ne[1] + plane_padding;
    t->nb[3] = t->nb[2] * t->ne[2];
}
void initialize_weights(ggml_tensor * t) {
    // A modest deterministic row pool avoids repeatedly quantizing hundreds of
    // millions of values. All output rows within production-size experts select
    // distinct pool rows; expert offsets differ. No uninitialized quant blocks.
    constexpr int pool_rows = 4096;
    const size_t row_bytes = ggml_row_size(t->type, t->ne[0]);
    std::vector<unsigned char> pool(pool_rows * row_bytes);
    std::vector<float> values(static_cast<size_t>(t->ne[0]));
    std::vector<float> importance(static_cast<size_t>(t->ne[0]), 1.0f);
    for (int row = 0; row < pool_rows; ++row) {
        uint32_t seed = 0x9E3779B9U ^ (uint32_t(row + 1) * 0x85EBCA6BU);
        if (!seed) seed = 1;
        for (float & value : values) value = random_float(seed);
        const size_t wrote = ggml_quantize_chunk(t->type, values.data(), pool.data() + row * row_bytes,
                                                 0, 1, t->ne[0], importance.data());
        require(wrote == row_bytes, "unexpected quantized row size");
    }
    for (int64_t expert = 0; expert < t->ne[2]; ++expert) {
        for (int64_t row = 0; row < t->ne[1]; ++row) {
            const size_t index = static_cast<size_t>((expert * 41 + row * 3) % pool_rows);
            std::memcpy(static_cast<char *>(t->data) + expert * t->nb[2] + row * t->nb[1],
                        pool.data() + index * row_bytes, row_bytes);
        }
    }
}
void initialize_inputs(ggml_tensor * input, ggml_tensor * ids, int experts, int round) {
    std::vector<float> row(static_cast<size_t>(input->ne[0]));
    for (int64_t token = 0; token < input->ne[2]; ++token) {
        for (int64_t slot = 0; slot < input->ne[1]; ++slot) {
            uint32_t seed = 12345U + uint32_t(round * 1009 + token * 131 + slot * 17);
            for (float & value : row) value = random_float(seed);
            void * target = static_cast<char *>(input->data) + token * input->nb[2] + slot * input->nb[1];
            if (input->type == GGML_TYPE_F32) std::memcpy(target, row.data(), row.size() * sizeof(float));
            else {
                auto from_float = ggml_get_type_traits_cpu(input->type)->from_float;
                require(from_float != nullptr, "missing dot-partner quantizer");
                from_float(row.data(), target, input->ne[0]);
            }
        }
    }
    for (int64_t token = 0; token < ids->ne[1]; ++token) {
        const int duplicate_ids[8] = {0, experts - 1, 3 % experts, 2 % experts, 7 % experts,
                                     1 % experts, experts - 1, 0};
        for (int64_t slot = 0; slot < ids->ne[0]; ++slot) {
            int32_t expert = round == 0 ? int((slot * 3 + token) % experts) : duplicate_ids[slot % 8];
            if (round == 2) expert = experts - 1;
            std::memcpy(static_cast<char *>(ids->data) + token * ids->nb[1] + slot * ids->nb[0],
                        &expert, sizeof(expert));
        }
    }
}
std::vector<unsigned char> logical_output(ggml_tensor * out) {
    std::vector<unsigned char> result;
    result.reserve(static_cast<size_t>(ggml_nelements(out)) * sizeof(float));
    for (int64_t token = 0; token < out->ne[2]; ++token) {
        for (int64_t slot = 0; slot < out->ne[1]; ++slot) {
            auto * begin = static_cast<unsigned char *>(out->data) + token * out->nb[2] + slot * out->nb[1];
            for (int64_t row = 0; row < out->ne[0]; ++row) {
                float value;
                std::memcpy(&value, begin + row * sizeof(float), sizeof(value));
                require(std::isfinite(value), "nonfinite output from finite fixture inputs");
            }
            result.insert(result.end(), begin, begin + out->ne[0] * sizeof(float));
        }
    }
    require(std::any_of(result.begin(), result.end(), [](unsigned char b) { return b != sentinel; }),
            "output remained entirely unwritten");
    return result;
}
void check_output_padding(ggml_tensor * out) {
    const size_t size = ggml_nbytes(out);
    const auto * data = static_cast<const unsigned char *>(out->data);
    size_t cursor = 0;
    for (int64_t token = 0; token < out->ne[2]; ++token) {
        for (int64_t slot = 0; slot < out->ne[1]; ++slot) {
            const size_t begin = token * out->nb[2] + slot * out->nb[1];
            for (; cursor < begin; ++cursor) require(data[cursor] == sentinel, "output padding overwritten");
            cursor = begin + out->ne[0] * sizeof(float);
        }
    }
    for (; cursor < size; ++cursor) require(data[cursor] == sentinel, "output tail padding overwritten");
}
bool eligible(const Case & c) {
    return !c.reference && c.tokens == 1 &&
           (c.weight == GGML_TYPE_Q4_K || c.weight == GGML_TYPE_Q5_K || c.weight == GGML_TYPE_Q6_K);
}
size_t run_case(ggml_backend_t backend, const Case & c, bool require_coverage, std::set<int> & affinity_reported) {
    ggml_init_params init{};
    init.mem_size = 8 * ggml_tensor_overhead() + ggml_graph_overhead_custom(32, false) + 4096;
    init.no_alloc = true;
    std::unique_ptr<ggml_context, decltype(&ggml_free)> ctx(ggml_init(init), ggml_free);
    require(ctx != nullptr, "context allocation failed");
    auto * weights = ggml_new_tensor_3d(ctx.get(), c.weight, c.k, c.m, c.experts);
    auto * input = ggml_new_tensor_3d(ctx.get(), c.partner_input ? ggml_get_type_traits_cpu(c.weight)->vec_dot_type : GGML_TYPE_F32,
                                    c.k, c.input_slots, c.tokens);
    auto * ids = ggml_new_tensor_2d(ctx.get(), GGML_TYPE_I32, c.used, c.tokens);
    ggml_set_name(weights, "fixture_weights"); ggml_set_name(input, "fixture_input"); ggml_set_name(ids, "fixture_ids");
    if (c.padded) {
        padded_rows(weights, 64, 128); padded_rows(input, 64, 64);
        ids->nb[0] = 12; ids->nb[1] = ids->nb[0] * ids->ne[0] + 16;
        ids->nb[2] = ids->nb[1] * ids->ne[1]; ids->nb[3] = ids->nb[2];
    }
    auto * out = ggml_mul_mat_id(ctx.get(), weights, input, ids);
    ggml_set_name(out, "fixture_output"); ggml_set_output(out);
    if (c.padded) padded_rows(out, 64, 64);
    Buffer weight_buffer(weights), input_buffer(input), id_buffer(ids), output_buffer(out);
    ggml_backend_buffer_set_usage(weight_buffer.handle, GGML_BACKEND_BUFFER_USAGE_WEIGHTS);
    initialize_weights(weights);
    auto * graph = ggml_new_graph_custom(ctx.get(), 32, false);
    ggml_build_forward_expand(graph, out);
    ggml_backend_cpu_set_use_ref(backend, c.reference);
    size_t comparisons = 0;
    for (int threads : c.threads) {
        ggml_backend_cpu_set_n_threads(backend, threads);
        for (int round = 0; round < 3; ++round) {
            initialize_inputs(input, ids, c.experts, round);
            std::vector<unsigned char> control;
            for (int enabled = 0; enabled <= 1; ++enabled) {
                require(setenv("GGML_CPU_MOE_SINGLE_TOKEN", enabled ? "1" : "0", 1) == 0, "setenv failed");
                std::memset(out->data, sentinel, output_buffer.bytes);
                entered.store(0); reported_nth.store(0); bad_callback.store(0); expected_tensor.store(out);
                for (auto & visit : visits) visit = WorkerVisit{};
                require(ggml_backend_graph_compute(backend, graph) == GGML_STATUS_SUCCESS, "CPU graph failed");
                ggml_backend_synchronize(backend);
                require(!bad_callback.load(), "invalid/duplicate diagnostic callback");
                const auto mask = entered.load();
                const bool expected = enabled && eligible(c);
                if (!expected) require(mask == 0, "specialization entered for a negative/control case");
                if (expected && (require_coverage || mask != 0)) {
                    require(reported_nth.load() == threads, "actual worker count differs from requested count");
                    require(mask == ((1ULL << threads) - 1), "specialization coverage missing/incomplete");
                    if (affinity_reported.insert(threads).second) {
                        for (int ith = 0; ith < threads; ++ith) {
                            const auto & visit = visits[ith];
                            std::printf("AFFINITY threads=%d worker=%d observed_cpu=%d mask_status=%d allowed=%s\n",
                                threads, ith, visit.cpu, visit.affinity_status,
                                visit.affinity_status == 0 ? mask_text(visit.allowed).c_str() : "unavailable");
                        }
                    }
                }
                weight_buffer.check_guards(); input_buffer.check_guards(); id_buffer.check_guards(); output_buffer.check_guards();
                check_output_padding(out);
                auto values = logical_output(out);
                if (!enabled) {
                    if (const char * directory = std::getenv("AG1_MMID_OUTPUT_DIR")) {
                        const std::string filename = std::string(directory) + "/" + c.name + "-t" + std::to_string(threads) + "-r" + std::to_string(round) + ".f32";
                        FILE * file = std::fopen(filename.c_str(), "wb");
                        require(file != nullptr, "output artifact open failed");
                        const size_t written = std::fwrite(values.data(), 1, values.size(), file);
                        const int closed = std::fclose(file);
                        require(written == values.size() && closed == 0, "output artifact write failed");
                    }
                    control = std::move(values);
                }
                else {
                    require(values == control, std::string("exact output mismatch: ") + c.name +
                            " threads=" + std::to_string(threads) + " round=" + std::to_string(round));
                    ++comparisons;
                }
            }
        }
    }
    std::printf("PASS case=%s type=%s k=%d m=%d E=%d used=%d tokens=%d slots=%d padded=%d partner=%d ref=%d pairs=%zu\n",
        c.name, ggml_type_name(c.weight), c.k, c.m, c.experts, c.used, c.tokens, c.input_slots,
        int(c.padded), int(c.partner_input), int(c.reference), comparisons);
    return comparisons;
}
}

// Called by the optional diagnostic-only patch, once per helper worker entry.
extern "C" void ag1_mmid_single_coverage(const ggml_tensor * tensor, int ith, int nth) {
    if (tensor != expected_tensor.load() || ith < 0 || ith >= max_workers || nth < 1 || nth > max_workers || ith >= nth) {
        bad_callback.store(1); return;
    }
    const unsigned long long bit = 1ULL << ith;
    if (entered.fetch_or(bit) & bit) { bad_callback.store(1); return; }
    reported_nth.store(nth);
    visits[ith].cpu = sched_getcpu();
    visits[ith].affinity_status = sched_getaffinity(0, sizeof(cpu_set_t), &visits[ith].allowed);
}

int main(int argc, char ** argv) {
    bool require_coverage = true;
    std::string only;
    for (int i = 1; i < argc; ++i) {
        if (!std::strcmp(argv[i], "--allow-no-coverage")) require_coverage = false;
        else if (!std::strcmp(argv[i], "--case") && i + 1 < argc) only = argv[++i];
        else { std::fprintf(stderr, "Usage: %s [--allow-no-coverage] [--case name]\n", argv[0]); return 2; }
    }
    // Do not infer affinity from llama.cpp cpu-range flags. Record actual worker
    // masks via coverage callbacks; caller may set taskset/GOMP/OMP placement.
    omp_set_dynamic(0);
    std::printf("OPENMP dynamic=%d coverage_required=%d\n", omp_get_dynamic(), int(require_coverage));
    for (const char * name : {"GOMP_CPU_AFFINITY", "OMP_PLACES", "OMP_PROC_BIND", "OMP_THREAD_LIMIT"}) {
        std::printf("ENV %s=%s\n", name, std::getenv(name) ? std::getenv(name) : "<unset>");
    }
    if (!require_coverage) std::puts("NOTE: exact-equality run only; absent diagnostic entries prove no specialization coverage.");
    try {
        std::unique_ptr<ggml_backend, decltype(&ggml_backend_free)> backend(ggml_backend_cpu_init(), ggml_backend_free);
        require(backend != nullptr, "CPU backend initialization failed");
        // No backend_load_all: this fixture intentionally loads only linked CPU.
        const std::vector<Case> cases = {
            {"mxfp4-down-512", GGML_TYPE_MXFP4, 640, 2560, 512, 10, 1, 10, false, false, false, {1,6,12}},
            {"iq1m-up-512", GGML_TYPE_IQ1_M, 2560, 640, 512, 10, 1, 1, false, false, false, {1,6,12}},
            {"iq2s-up-512", GGML_TYPE_IQ2_S, 2560, 640, 512, 10, 1, 1, false, false, false, {1,6,12}},
            {"mxfp4-tail", GGML_TYPE_MXFP4, 640, 65, 16, 10, 1, 10, true, true, false, {3,12}},
            {"iq1m-tail", GGML_TYPE_IQ1_M, 256, 65, 16, 10, 1, 10, true, true, false, {3,12}},
            {"iq2s-tail", GGML_TYPE_IQ2_S, 256, 65, 16, 10, 1, 1, true, false, false, {3,12}},
            {"empty-workers", GGML_TYPE_MXFP4, 640, 1, 16, 1, 1, 1, true, false, false, {1,12}},
            {"two-tokens", GGML_TYPE_IQ1_M, 256, 64, 16, 10, 2, 10, true, false, false, {3}},
            {"prefill", GGML_TYPE_IQ2_S, 256, 64, 16, 10, 16, 1, false, false, false, {6}},
            {"reference", GGML_TYPE_MXFP4, 640, 64, 16, 10, 1, 10, false, false, true, {3}},
            {"other-quant", GGML_TYPE_Q8_0, 512, 64, 16, 10, 1, 10, false, false, false, {3}},
        };
        size_t completed = 0, pairs = 0;
        std::set<int> affinity_reported;
        for (const auto & c : cases) {
            if (!only.empty() && only != c.name) continue;
            pairs += run_case(backend.get(), c, require_coverage, affinity_reported); ++completed;
        }
        require(completed != 0, "no matching cases");
        std::printf("PASS cases=%zu exact_pairs=%zu coverage_required=%d\n", completed, pairs, int(require_coverage));
        return 0;
    } catch (const std::exception & error) {
        std::fprintf(stderr, "FAIL %s\n", error.what()); return 1;
    }
}
