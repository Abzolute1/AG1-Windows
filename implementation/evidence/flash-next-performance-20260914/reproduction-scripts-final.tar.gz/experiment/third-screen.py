import time,json
from pathlib import Path
from bench import run,EVID,ROOT
while not (EVID/'noomp-build-done.json').exists():time.sleep(3)
registration={'AG1_FLASH_REGISTER_MMAP':'1','GGML_CUDA_REGISTER_HOST':'1'}
configs=[
 {'name':'new-local-control','binary':str(ROOT/'bundle-new-register/llama-server'),'repetitions':1},
 {'name':'new-registered','binary':str(ROOT/'bundle-new-register/llama-server'),'environment':registration},
 {'name':'new-noomp-registered','binary':str(ROOT/'bundle-new-noomp/llama-server'),'environment':registration},
 {'name':'new-noomp-poll0','binary':str(ROOT/'bundle-new-noomp/llama-server'),'environment':registration,'flags':{'--poll':'0'}},
 {'name':'new-omp-passive','binary':str(ROOT/'bundle-new-register/llama-server'),'environment':{**registration,'GOMP_SPINCOUNT':'0','OMP_WAIT_POLICY':'PASSIVE'}},
 {'name':'new-pool32-cpu48','binary':str(ROOT/'bundle-new-pool/llama-server'),'environment':{**registration,'AG1_FLASH_POOL_MIB':'3000'},'flags':{'--n-cpu-moe':'48','--moe-expert-cache':'32'}},
 {'name':'new-direct-registered','binary':str(ROOT/'bundle-new-direct/llama-server'),'environment':registration,'flags':{'--lazy-mode':'on-direct'}},
]
for c in configs:
 c.setdefault('workloads',['review','prose','edit']);c.setdefault('repetitions',2);c['n_predict']=256;c['api_smoke']=True
 (ROOT/(c['name']+'.json')).write_text(json.dumps(c,indent=2));run(c)
(EVID/'third-screen-done.json').write_text(json.dumps({'status':'finished'}))
