"""Flatten CPU miss tiles while preserving the fork's GPU-cache lifecycle.

Unlike the earlier non-cache helper, this keeps begin/plan/dispatch/collect,
row masks, failure fallback, and the original scalar dot kernel unchanged.
Build and fixture checks run only between real-model inference sessions.
"""
import difflib,hashlib,json,os,shlex,shutil,subprocess
from pathlib import Path
R=Path('/home/alex/Projects/flash-next-perf-20260914')
E=Path('/home/alex/Projects/AG1/implementation/evidence/flash-next-performance-20260914')
S=Path(json.loads((E/'turbo-source-manifest.json').read_text())['source'])
B=R/'build-turbo-latest';O=R/'turbo-flat-overlay';D=R/'bundle-turbo-flat'
assert shutil.disk_usage(R).free>30*2**30
O.mkdir();shutil.copytree(R/'bundle-turbo-history',D,symlinks=True)
source=S/'ggml/src/ggml-cpu/ggml-cpu.c';before=source.read_text();after=before
start=after.index('static void ggml_compute_forward_mul_mat_id_impl(')
end=after.index('\nstatic void ggml_compute_forward_mul_mat_id(',start)
body=after[start:end]
needle='    // reset current_chunk\n'
assert body.count(needle)==1
body=body.replace(needle,'''    const char * flat_env = getenv("AG1_FLASH_FLAT_CPU_MISSES");
    const bool flat_misses = flat_env && flat_env[0] == '1' && flat_env[1] == '\\0' &&
        !params->use_ref &&
        (type == GGML_TYPE_MXFP4 || type == GGML_TYPE_IQ1_M || type == GGML_TYPE_IQ2_S) &&
        ids->type == GGML_TYPE_I32 && ids->ne[1] == 1 && ids->ne[2] == 1 && ids->ne[3] == 1 &&
        n_ids > 0 && n_ids <= MOE_CACHE_MAX_TOPK && ne01 > 0 && ne01 <= INT32_MAX &&
        ne03 == 1 && ne12 == 1 && ne13 == 1 && ne2 == 1 && ne3 == 1;

    // reset current_chunk (unused by the flat schedule)
    if (!flat_misses)
''',1)
needle='    for (int cur_a = 0; cur_a < n_as; ++cur_a) {'
assert body.count(needle)==1
body=body.replace(needle,'''    if (flat_misses) {
        // Counts and mappings were published by thread zero before the barrier.
        // GPU hits are absent; fused up/gate row masks are already applied.
        int experts[MOE_CACHE_MAX_TOPK];
        int rows[MOE_CACHE_MAX_TOPK];
        int count = 0;
        for (int expert = 0; expert < n_as; ++expert) {
            for (int row = 0; row < matrix_row_counts[expert]; ++row) {
                GGML_ASSERT(count < MOE_CACHE_MAX_TOPK);
                experts[count] = expert; rows[count] = row; ++count;
            }
        }
        const int64_t tiles = (ne01 + 15) / 16;
        const void * wdata = (src1->type == vec_dot_type) ? src1->data : params->wdata;
        const size_t row_size = ggml_row_size(vec_dot_type, ne10);
        for (int64_t task = ith; task < count * tiles; task += nth) {
            const int index = (int) (task / tiles);
            const int expert = experts[index];
            const int64_t first = (task % tiles) * 16;
            ggml_compute_forward_mul_mat_id_one_chunk(
                dst, src0, src1, ids, expert, first, MIN(first + 16, ne01),
                rows[index], rows[index] + 1,
                (const char *) src0->data + expert * nb02,
                matrix_rows, row_size, src1_cont, wdata);
        }
    } else
''' + needle,1)
after=after[:start]+body+after[end:]
patched=O/'ggml-cpu.c';patched.write_text(after)
(E/'turbo-flat-cpu-misses.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/ggml/src/ggml-cpu/ggml-cpu.c',tofile='b/ggml/src/ggml-cpu/ggml-cpu.c')))
commands=subprocess.check_output(['ninja','-C',str(B),'-t','commands','ggml-cpu'],text=True).splitlines()
obj='ggml/src/CMakeFiles/ggml-cpu.dir/ggml-cpu/ggml-cpu.c.o'
cmd=shlex.split(next(c for c in commands if obj+' -c ' in c));cmd[cmd.index('-c')+1]=str(patched)
for flag,target in [('-o',O/'ggml-cpu.c.o'),('-MF',O/'ggml-cpu.c.o.d'),('-MT',O/'ggml-cpu.c.o')]:cmd[cmd.index(flag)+1]=str(target)
cmd+=['-I'+str(S/'ggml/src/ggml-cpu')]
line=next(c for c in commands if '-o bin/libggml-cpu.so ' in c)
assert line.startswith(': && ') and line.endswith(' && :')
link=shlex.split(line[5:-5]);link[link.index(obj)]=str(O/'ggml-cpu.c.o');link[link.index('-o')+1]=str(D/'libggml-cpu.so')
for i,arg in enumerate(link):
    if arg.startswith('-Wl,--dependency-file='):link[i]='-Wl,--dependency-file='+str(O/'link.d')
    if arg.startswith('-Wl,-rpath,'):link[i]='-Wl,-rpath,$ORIGIN'
manifest={'base_source':str(S),'base_build':str(B),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
          'modified_source':str(patched),'modified_source_sha256':hashlib.sha256(patched.read_bytes()).hexdigest(),
          'compile':cmd,'link':link,'cwd':str(B),'binary':str(D/'llama-server')}
(E/'turbo-flat-build-command.json').write_text(json.dumps(manifest,indent=2))
assert not (D/'libggml-cpu.so').is_symlink() and (D/'libggml-cpu.so').stat().st_nlink == 1, 'Refusing to overwrite a shared or linked library'
with (E/'turbo-flat-build.log').open('w') as log:
    subprocess.run(cmd,cwd=B,stdout=log,stderr=subprocess.STDOUT,check=True)
    subprocess.run(link,cwd=B,stdout=log,stderr=subprocess.STDOUT,check=True)
assert hashlib.sha256(source.read_bytes()).hexdigest()==manifest['source_sha256']
manifest['status']='built';manifest['library_sha256']=hashlib.sha256((D/'libggml-cpu.so').read_bytes()).hexdigest()
(E/'turbo-flat-build-result.json').write_text(json.dumps(manifest,indent=2))

fixture=R/'test-turbo-flat'
fc=['g++-15','-O2','-std=c++17','-fopenmp','-I'+str(S/'ggml/include'),
    str(R/'test-flash-mmid.cpp'),'-L'+str(B/'bin'),'-lggml-cpu','-lggml-base','-lggml',
    '-Wl,-rpath,'+str(B/'bin'),'-o',str(fixture)]
(E/'turbo-flat-fixture-command.json').write_text(json.dumps(fc,indent=2))
with (E/'turbo-flat-fixture-build.log').open('w') as log:subprocess.run(fc,stdout=log,stderr=subprocess.STDOUT,check=True)
for label in ['base','flat']:
    out=E/('turbo-flat-fixture-'+label);out.mkdir()
    env={**os.environ,'LD_LIBRARY_PATH':str(D),'AG1_MMID_OUTPUT_DIR':str(out),
         'AG1_FLASH_FLAT_CPU_MISSES':str(int(label=='flat'))}
    with (out/'run.log').open('w') as log:
        result=subprocess.run([str(fixture),'--allow-no-coverage'],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=900)
    assert result.returncode==0, ('CPU fixture failed',label)
checks=[]
for p in sorted((E/'turbo-flat-fixture-base').glob('*.f32')):
    q=E/'turbo-flat-fixture-flat'/p.name
    checks.append({'name':p.name,'bytes':p.stat().st_size,'equal':p.read_bytes()==q.read_bytes()})
(E/'turbo-flat-fixture-result.json').write_text(json.dumps(checks,indent=2))
assert len(checks)==63 and all(x['equal'] for x in checks),'CPU scheduling changed a fixture output'
