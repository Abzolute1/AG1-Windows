import json,subprocess
from pathlib import Path
R=Path('/home/alex/Projects/flash-next-perf-20260914')
E=Path('/home/alex/Projects/AG1/implementation/evidence/flash-next-performance-20260914')
for name in ['resume-post-screen','further-source-screen','alternative-model-test']:
 with (E/(name+'-continuation-console.log')).open('w') as log:
  result=subprocess.run(['python',str(R/(name+'.py'))],stdout=log,stderr=subprocess.STDOUT)
 (E/(name+'-continuation-result.json')).write_text(json.dumps({'returncode':result.returncode}))
 if result.returncode:raise SystemExit(result.returncode)
(E/'continued-investigation-done.json').write_text(json.dumps({'status':'finished'}))
