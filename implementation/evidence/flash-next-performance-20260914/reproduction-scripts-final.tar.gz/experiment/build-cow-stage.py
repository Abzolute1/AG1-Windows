from pathlib import Path
import subprocess,json,shutil
R=Path('/home/alex/Projects/flash-next-perf-20260914');E=Path('/home/alex/Projects/AG1/implementation/evidence/flash-next-performance-20260914')
assert (E/'fourth-preparation-done.json').exists()
for name,target,base in [('stage','ggml-base','pool'),('cow','llama','register')]:
 subprocess.run(['python',str(R/('port-'+name+'.py'))],check=True)
 args=json.loads((E/(base+'-source-build.json')).read_text())['configure'];args[args.index('-S')+1]=str(R/('source-new-'+name));args[args.index('-B')+1]=str(R/('build-new-'+name))
 with (E/(name+'-build.log')).open('w') as log:
  subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,check=True)
  subprocess.run(['cmake','--build',str(R/('build-new-'+name)),'--target',target,'-j','12'],stdout=log,stderr=subprocess.STDOUT,check=True)
 bundle=R/('bundle-new-'+name);shutil.copytree(R/('bundle-new-'+base),bundle)
 for f in (R/('build-new-'+name)/'bin').glob('lib'+target+'.so*'):shutil.copy2(f,bundle/f.name,follow_symlinks=True)
 (E/(name+'-build-command.json')).write_text(json.dumps({'configure':args,'target':target,'bundle':str(bundle)},indent=2));print('built',name,flush=True)
(E/'cow-stage-build-done.json').write_text(json.dumps({'status':'built'}))
