import collections,io,json,math,struct,time,urllib.request
from pathlib import Path
R=Path('/home/alex/Projects/flash-next-perf-20260914');E=Path('/home/alex/Projects/AG1/implementation/evidence/flash-next-performance-20260914')
cat=json.loads((E/'atomic-model-catalog.json').read_text());files=[x for x in cat['siblings'] if '4.27bpw' in x['rfilename'] and x['rfilename'].endswith('.gguf')]
class MoreData(Exception):pass
def parse(data,size):
 f=io.BytesIO(data)
 def read(n):
  b=f.read(n)
  if len(b)!=n:raise MoreData()
  return b
 def u(fmt):return struct.unpack('<'+fmt,read(struct.calcsize('<'+fmt)))[0]
 def string():return read(u('Q')).decode()
 fmt={0:'B',1:'b',2:'H',3:'h',4:'I',5:'i',6:'f',7:'?',10:'Q',11:'q',12:'d'}
 def val(t):
  if t==8:return string()
  if t==9:
   typ=u('I');n=u('Q');a=[val(typ) for _ in range(n)];return a if n<256 else {'length':n,'type':typ}
  return u(fmt[t])
 assert read(4)==b'GGUF';version=u('I');nt=u('Q');nk=u('Q');meta={}
 for _ in range(nk):
  k=string();v=val(u('I'))
  if not k.startswith('tokenizer.'):meta[k]=v
 ts=[]
 for _ in range(nt):
  name=string();dims=[u('Q') for _ in range(u('I'))];typ=u('I');off=u('Q');ts.append({'name':name,'dims':dims,'type':typ,'offset':off,'parameters':math.prod(dims)})
 align=meta.get('general.alignment',32);base=(f.tell()+align-1)//align*align
 for i,t in enumerate(ts):t['bytes']=(ts[i+1]['offset'] if i+1<len(ts) else size-base)-t['offset']
 return {'metadata':meta,'header_bytes':f.tell(),'data_offset':base,'tensors':ts}
results=[]
for item in files:
 url='https://huggingface.co/AtomicChat/Qwen3.8-Flash-Next-GGUF/resolve/'+cat['sha']+'/'+item['rfilename']
 for n in [65536,1048576,16777216]:
  req=urllib.request.Request(url,headers={'Range':f'bytes=0-{n-1}'})
  with urllib.request.urlopen(req,timeout=60) as r:
   data=r.read(n);headers=dict(r.headers);status=r.status
  try:parsed=parse(data,item['size']);break
  except MoreData:
   if n==16777216:raise
 parsed.update(path=item['rfilename'],size=item['size'],sha256=item['lfs']['sha256'],range_status=status,range_response=headers.get('Content-Range'))
 results.append(parsed);print(item['rfilename'].split('/')[-1],len(parsed['tensors']),parsed['header_bytes'],flush=True)
(E/'alternative-427-remote-layout.json').write_text(json.dumps(results,indent=2))
orig=json.loads((E/'model-layout.json').read_text());a={x['name']:x for x in orig};b={t['name']:t for d in results for t in d['tensors']}
changes=[{'name':n,'original_type':a[n]['type'],'alternative_type':b[n]['type'],'original_bytes':a[n]['bytes'],'alternative_bytes':b[n]['bytes']} for n in a if n in b and (a[n]['type']!=b[n]['type'] or a[n]['dims']!=b[n]['dims'])]
summary={'remote_revision':cat['sha'],'files':len(results),'size_gib':sum(d['size'] for d in results)/2**30,'tensor_count':len(b),'names_identical':a.keys()==b.keys(),'all_shapes_identical':a.keys()==b.keys() and all(a[n]['dims']==b[n]['dims'] for n in a),'changes':changes,'original_type_counts':dict(collections.Counter(x['type'] for x in a.values())),'alternative_type_counts':dict(collections.Counter(x['type'] for x in b.values()))}
(E/'alternative-427-assessment.json').write_text(json.dumps(summary,indent=2));print(json.dumps({k:v for k,v in summary.items() if k!='changes'},indent=2));print('changed',len(changes))
