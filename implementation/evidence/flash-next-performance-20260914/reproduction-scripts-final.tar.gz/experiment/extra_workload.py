"""Additional frozen copy controls; never rewrites the baseline prompts file."""
import hashlib,json

def extend(prompts,post,path):
    frozen=path.with_name('prompts-additional.json')
    if frozen.exists():return {**prompts,**json.loads(frozen.read_text())}
    copy_source=prompts['edit']['messages'][-1]['content'].split('\n\n',1)[1]
    copy_repetitive=prompts['repetitive']['messages'][-1]['content'].split('\n\n',1)[1]
    extra={}
    for name,source in [('copy_source',copy_source),('copy_repetitive',copy_repetitive)]:
        item={'category':'G-copy-control','expected_output':source,'max_tokens':2048,
              'messages':[{'role':'system','content':'Copy exactly. Return only the complete source file, without code fences, explanation, omissions, or additional whitespace.'},
                          {'role':'user','content':'Return this source file unchanged, in full.\n\n'+source}]}
        item['prompt']=post('/apply-template',{'messages':item['messages'],'chat_template_kwargs':{'enable_thinking':False}})['prompt']
        item['tokens']=post('/tokenize',{'content':item['prompt'],'add_special':False})['tokens']
        item['sha256']=hashlib.sha256(item['prompt'].encode()).hexdigest();extra[name]=item
    frozen.write_text(json.dumps(extra,indent=2));return {**prompts,**extra}
