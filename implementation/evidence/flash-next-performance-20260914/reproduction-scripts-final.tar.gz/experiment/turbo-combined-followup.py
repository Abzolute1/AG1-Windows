"""Combine only measured cache candidates; still provisional screen results."""
import json,statistics
from bench import ROOT as R,EVID as E,run
available=[]
for p in (E/'runs').glob('turbo-followup-*/result.json'):
 d=json.loads(p.read_text())
 if d['status']=='passed' and d.get('api_smoke',{}).get('tool_call_pass') and all(x.get('quality_content_pass',False) for x in d['requests'] if x['workload']=='edit') and '--spec-type' not in d['config'].get('flags',{}) and any(x['workload']=='prose' for x in d['requests']):available.append(d)
assert available
def rate(d,w):return statistics.median((x['timings']['predicted_n']-1)*1000/x['timings']['predicted_ms'] for x in d['requests'] if x['workload']==w)
top_prose=max(rate(d,'prose') for d in available)
near_fastest=[d for d in available if rate(d,'prose')>=.97*top_prose]
best=max(near_fastest,key=lambda d:statistics.median(x['timings']['prompt_per_second'] for x in d['requests'] if x['workload']=='review'));base=best['config']
(E/'turbo-combined-selection.json').write_text(json.dumps({'source':best['name'],'criterion':'highest median review prefill among valid non-speculative cache followups within3% of fastest prose; prioritizes prefill without choosing a tiny prose fluctuation; provisional screen selection only','fastest_prose':top_prose},indent=2))
def launch(c):
 (R/(c['name']+'.json')).write_text(json.dumps(c,indent=2));return run(c)
results=[]
for label,env in [('control',{}),('min256',{'GGML_CUDA_MOE_CACHE_MIN_EXPERT_KB':'256'})]:
 c={**base,'name':'turbo-combined-'+label,'environment':{**base['environment'],**env},
    'workloads':['review','prose','edit'],'repetitions':2,'api_smoke':True}
 result=launch(c)
 if result['status']=='passed' and result.get('api_smoke',{}).get('tool_call_pass') and all(x.get('quality_content_pass',False) for x in result['requests'] if x['workload']=='edit'):results.append(result)
# Test a mix of permanently GPU-resident layers and a smaller dynamic cache.
# All-CPU expert placement gives the largest cache but was poor on exact edits.
for cpu,cache,reserve in [(42,1024,512),(44,3072,1024),(46,4480,1024)]:
 c={**base,'name':f'turbo-combined-cpu{cpu}-cache{cache}',
    'flags':{**base['flags'],'--n-cpu-moe':str(cpu),'--moe-cache':str(cache)},
    'environment':{**base['environment'],'GGML_CUDA_MOE_CACHE_RESERVE_MB':str(reserve)},
    'workloads':['review','prose','edit'],'repetitions':2,'api_smoke':True}
 result=launch(c)
 if result['status']=='passed' and result.get('api_smoke',{}).get('tool_call_pass') and all(x.get('quality_content_pass',False) for x in result['requests'] if x['workload']=='edit'):results.append(result)
best=max(results,key=lambda d:rate(d,'prose'));base=best['config']
for threads in [24,12]:
 c={**base,'name':'turbo-combined-ngram4-t'+str(threads),
    'flags':{**base['flags'],'--threads-batch':str(threads),'--cpu-range-batch':f'0-{threads-1}',
      '--spec-type':'ngram-mod','--spec-ngram-mod-n-max':'4','--spec-ngram-mod-n-min':'2','--spec-ngram-mod-n-match':'24'},
    'workloads':['prose','edit','repetitive'],'repetitions':2,'api_smoke':True}
 launch(c)
# Long drafts exceed the cache's row mask, so its existing safe bypass runs
# those verification batches on the ordinary backend. Test this policy rather
# than widening masks or changing verification correctness speculatively.
c={**base,'name':'turbo-combined-ngram16-t12',
   'flags':{**base['flags'],'--threads-batch':'12','--cpu-range-batch':'0-11',
      '--spec-type':'ngram-mod','--spec-ngram-mod-n-max':'16','--spec-ngram-mod-n-min':'2','--spec-ngram-mod-n-match':'24'},
   'workloads':['prose','edit','repetitive'],'repetitions':2,'api_smoke':True}
launch(c)
(E/'turbo-combined-followup-done.json').write_text(json.dumps({'status':'finished'}))
