import json,subprocess,shutil,time,os,hashlib
from pathlib import Path
R=Path('/home/alex/Projects/flash-next-perf-20260914');E=Path('/home/alex/Projects/AG1/implementation/evidence/flash-next-performance-20260914')
def call(cmd,label,env=None):
 print(label,flush=True)
 with (E/(label+'.log')).open('w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True,env=env)
out=E/'flat-fixture-cpu-flat-corrected';out.mkdir()
env=os.environ.copy();env['LD_LIBRARY_PATH']=str(R/'bundle-new-cpu-flat');env['AG1_MMID_OUTPUT_DIR']=str(out)
call([str(R/'test-flash-mmid'),'--allow-no-coverage'],'flat-fixture-cpu-flat-corrected',env)
a=E/'flat-fixture-register';checks=[]
for p in a.glob('*.f32'):
 q=out/p.name;checks.append({'name':p.name,'bytes':p.stat().st_size,'equal':p.read_bytes()==q.read_bytes()})
assert checks and all(x['equal'] for x in checks)
(E/'flat-fixture-result.json').write_text(json.dumps({'checks':checks,'status':'bit-identical'},indent=2))
base=json.loads((E/'cow-build-command.json').read_text())['configure']
s=(R/'fifth-preparation.py').read_text();exec(s[s.index('# Full CUDA build:'):])
