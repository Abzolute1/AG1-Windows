from pathlib import Path
import subprocess,json,shutil,time
R=Path('/home/alex/Projects/flash-next-perf-20260914');E=Path('/home/alex/Projects/AG1/implementation/evidence/flash-next-performance-20260914')
while not (E/'source-stage-done.json').exists():time.sleep(3)
args=json.loads((E/'register-source-build.json').read_text())['configure']
args[args.index('-B')+1]=str(R/'build-new-noomp');args += ['-DGGML_OPENMP=OFF']
with (E/'noomp-build.log').open('w') as log:
 subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,check=True)
 subprocess.run(['cmake','--build',str(R/'build-new-noomp'),'--target','ggml-cpu','-j','12'],stdout=log,stderr=subprocess.STDOUT,check=True)
bundle=R/'bundle-new-noomp';shutil.copytree(R/'bundle-new-register',bundle)
shutil.copy2(R/'build-new-noomp/bin/libggml-cpu.so',bundle/'libggml-cpu.so')
(E/'noomp-build-done.json').write_text(json.dumps({'args':args,'status':'built'}))
