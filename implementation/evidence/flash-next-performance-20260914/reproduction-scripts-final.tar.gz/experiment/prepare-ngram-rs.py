"""Opt-in recurrent rollback snapshots for ngram-mod on the experimental build.

Stock need_n_rs_seq enables them for MTP/Eagle-style drafts but not ngram-mod,
so hybrid targets save a host checkpoint before each nonempty n-gram proposal.
This experiment uses the existing exact snapshot/rollback machinery instead.
"""
import difflib,hashlib,json,os,shlex,shutil,subprocess
from pathlib import Path
R=Path('/home/alex/Projects/flash-next-perf-20260914')
E=Path('/home/alex/Projects/AG1/implementation/evidence/flash-next-performance-20260914')
S=R/'unsloth-new-source/llama.cpp-b10909-mix-bea84f7';B=R/'build-new-ada'
O=R/'ngram-rs-overlay';D=R/'bundle-new-ngram-rs'
assert shutil.disk_usage(R).free>30*2**30
O.mkdir();D.mkdir()
for p in (B/'bin').iterdir():
    if p.name=='llama-server' or '.so' in p.name:
        if p.is_symlink():(D/p.name).symlink_to(os.readlink(p))
        elif p.is_file():shutil.copy2(p,D/p.name)
source=S/'common/common.cpp';before=source.read_text()
needle='    cparams.n_rs_seq          = params.speculative.need_n_rs_seq();'
assert before.count(needle)==1
after=before.replace(needle,needle+'''
    const char * ngram_rs = std::getenv("AG1_FLASH_NGRAM_RS");
    if (ngram_rs && ngram_rs[0] == '1' && ngram_rs[1] == '\\0' &&
            std::find(params.speculative.types.begin(), params.speculative.types.end(),
                COMMON_SPECULATIVE_TYPE_NGRAM_MOD) != params.speculative.types.end()) {
        if (params.speculative.ngram_mod.n_max < 1 || params.speculative.ngram_mod.n_max > 64) {
            throw std::runtime_error("experimental ngram rollback depth outside validated bound");
        }
        cparams.n_rs_seq = std::max(cparams.n_rs_seq, (uint32_t) params.speculative.ngram_mod.n_max);
    }''',1)
patched=O/'common.cpp';patched.write_text(after)
(E/'ngram-recurrent-snapshots.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/common/common.cpp',tofile='b/common/common.cpp')))
commands=subprocess.check_output(['ninja','-C',str(B),'-t','commands','llama-server'],text=True).splitlines()
obj='common/CMakeFiles/llama-common.dir/common.cpp.o'
cmd=shlex.split(next(c for c in commands if obj+' -c ' in c));cmd[cmd.index('-c')+1]=str(patched)
for flag,target in [('-o',O/'common.cpp.o'),('-MF',O/'common.cpp.o.d'),('-MT',O/'common.cpp.o')]:cmd[cmd.index(flag)+1]=str(target)
cmd+=['-I'+str(S/'common')]
line=next(c for c in commands if '-o bin/libllama-common.so.0.4.0 ' in c)
assert line.startswith(': && ') and line.endswith(' && :')
link=shlex.split(line[5:-5]);link[link.index(obj)]=str(O/'common.cpp.o')
link[link.index('-o')+1]=str(D/'libllama-common.so.0.4.0')
for i,arg in enumerate(link):
    if arg.startswith('-Wl,--dependency-file='):link[i]='-Wl,--dependency-file='+str(O/'link.d')
    if arg.startswith('-Wl,-rpath,'):link[i]='-Wl,-rpath,$ORIGIN'
manifest={'base_revision':'329b6160f513915f1c607dbfae3d5ce864a64a4f','base_source':str(S),'base_build':str(B),
          'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'modified_source':str(patched),
          'modified_source_sha256':hashlib.sha256(patched.read_bytes()).hexdigest(),
          'compile':cmd,
          'link':link,'cwd':str(B),'binary':str(D/'llama-server')}
(E/'ngram-rs-build-command.json').write_text(json.dumps(manifest,indent=2))
assert not (D/'libllama-common.so.0.4.0').is_symlink() and (D/'libllama-common.so.0.4.0').stat().st_nlink == 1, 'Refusing to overwrite a shared or linked library'
with (E/'ngram-rs-build.log').open('w') as log:
    subprocess.run(cmd,cwd=B,stdout=log,stderr=subprocess.STDOUT,check=True)
    subprocess.run(link,cwd=B,stdout=log,stderr=subprocess.STDOUT,check=True)
assert hashlib.sha256(source.read_bytes()).hexdigest()==manifest['source_sha256']
manifest['status']='built';manifest['library_sha256']=hashlib.sha256((D/'libllama-common.so.0.4.0').read_bytes()).hexdigest()
(E/'ngram-rs-build-result.json').write_text(json.dumps(manifest,indent=2))
