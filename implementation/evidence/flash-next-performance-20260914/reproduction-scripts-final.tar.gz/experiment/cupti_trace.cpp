#include <cupti.h>
#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <map>
#include <mutex>
#include <string>
#include <tuple>
#include <time.h>

struct Counter { uint64_t count=0, duration=0, bytes=0; };
struct Trace {
    std::mutex mutex;
    std::map<std::tuple<int,uint64_t,std::string>,Counter> bins;
    std::string directory;
    uint64_t stamp=0, monotonic=0, dropped=0;
    bool enabled=false;
};
static Trace & state() { static Trace * s=new Trace; return *s; }
static void add(int kind,uint64_t start,uint64_t end,uint64_t bytes,const char * name) {
    if (!start || end<start) return;
    auto & s=state();
    std::lock_guard<std::mutex> lock(s.mutex);
    auto & c=s.bins[{kind,start/250000000,name ? name : "unknown"}];
    ++c.count;c.duration+=end-start;c.bytes+=bytes;
}
static void CUPTIAPI requested(uint8_t ** buffer,size_t * size,size_t * maximum) {
    *size=2*1024*1024;*buffer=(uint8_t *)malloc(*size);*maximum=0;
    if (!*buffer) std::abort();
}
static void CUPTIAPI completed(CUcontext context,uint32_t stream,uint8_t * buffer,size_t,size_t valid) {
    CUpti_Activity * record=nullptr;
    while (cuptiActivityGetNextRecord(buffer,valid,&record)==CUPTI_SUCCESS) {
        if (record->kind==CUPTI_ACTIVITY_KIND_CONCURRENT_KERNEL || record->kind==CUPTI_ACTIVITY_KIND_KERNEL) {
            const auto * k=(const CUpti_ActivityKernel12 *)record;
            add(1,k->start,k->end,0,k->name);
        } else if (record->kind==CUPTI_ACTIVITY_KIND_MEMCPY) {
            const auto * m=(const CUpti_ActivityMemcpy6 *)record;
            const std::string name="copy_kind_"+std::to_string(m->copyKind);
            add(2,m->start,m->end,m->bytes,name.c_str());
        } else if (record->kind==CUPTI_ACTIVITY_KIND_RUNTIME || record->kind==CUPTI_ACTIVITY_KIND_DRIVER) {
            const auto * a=(const CUpti_ActivityAPI *)record;
            const char * name=nullptr;
            cuptiGetCallbackName(record->kind==CUPTI_ACTIVITY_KIND_RUNTIME ? CUPTI_CB_DOMAIN_RUNTIME_API : CUPTI_CB_DOMAIN_DRIVER_API,a->cbid,&name);
            add(3,a->start,a->end,0,name);
        }
    }
    size_t dropped=0;
    if (cuptiActivityGetNumDroppedRecords(context,stream,&dropped)==CUPTI_SUCCESS) {
        auto & s=state();std::lock_guard<std::mutex> lock(s.mutex);s.dropped+=dropped;
    }
    free(buffer);
}
static void finish() {
    auto & s=state();if (!s.enabled) return;
    cuptiActivityFlushAll(1);
    std::lock_guard<std::mutex> lock(s.mutex);
    FILE * out=fopen((s.directory+"/cupti-activity.tsv").c_str(),"w");
    if (!out) return;
    fprintf(out,"kind\tbucket_ns\tcount\tduration_ns\tbytes\tsymbol\n");
    for (const auto & entry:s.bins) {
        const auto & [kind,bucket,name]=entry.first;const auto & c=entry.second;
        fprintf(out,"%d\t%llu\t%llu\t%llu\t%llu\t%s\n",kind,(unsigned long long)(bucket*250000000),(unsigned long long)c.count,(unsigned long long)c.duration,(unsigned long long)c.bytes,name.c_str());
    }
    fclose(out);
    out=fopen((s.directory+"/cupti-anchor.json").c_str(),"w");
    if (out) {
        fprintf(out,"{\"cupti_ns\":%llu,\"monotonic_ns\":%llu,\"dropped_records\":%llu}\n",(unsigned long long)s.stamp,(unsigned long long)s.monotonic,(unsigned long long)s.dropped);fclose(out);
    }
}
__attribute__((constructor)) static void initialize() {
    const char * dir=getenv("AG1_PERF_TRACE_DIR");if (!dir) return;
    auto & s=state();s.directory=dir;
    if (cuptiActivityRegisterCallbacks(requested,completed)!=CUPTI_SUCCESS) return;
    cuptiGetTimestamp(&s.stamp);timespec t{};clock_gettime(CLOCK_MONOTONIC,&t);s.monotonic=(uint64_t)t.tv_sec*1000000000+t.tv_nsec;
    for (auto kind:{CUPTI_ACTIVITY_KIND_CONCURRENT_KERNEL,CUPTI_ACTIVITY_KIND_MEMCPY,CUPTI_ACTIVITY_KIND_RUNTIME,CUPTI_ACTIVITY_KIND_DRIVER}) {
        const auto result=cuptiActivityEnable(kind);
        if (result!=CUPTI_SUCCESS) fprintf(stderr,"AG1 diagnostic CUPTI enable kind %d failed: %d\n",(int)kind,(int)result);
    }
    s.enabled=true;atexit(finish);
}
