import json,subprocess,time,hashlib,urllib.request,tarfile,shutil
from pathlib import Path
R=Path('/home/alex/Projects/flash-next-perf-20260914');E=Path('/home/alex/Projects/AG1/implementation/evidence/flash-next-performance-20260914')
src=Path(json.loads((E/'turbo-source-manifest.json').read_text())['source'])
free=shutil.disk_usage(R).free
assert free > 30*2**30, 'Insufficient disk reserve for isolated build'
print('Starting isolated fork build; free GiB',free/2**30,flush=True)
base=json.loads((E/'cow-build-command.json').read_text())['configure'];build=R/'build-turbo-latest'
cmd=base.copy();cmd[cmd.index('-S')+1]=str(src);cmd[cmd.index('-B')+1]=str(build);cmd.remove('-DGGML_CUDA=OFF');cmd.remove('-DLLAMA_BUILD_TESTS=OFF')
cmd+=['-DCMAKE_C_COMPILER=/usr/bin/gcc-15','-DCMAKE_CXX_COMPILER=/usr/bin/g++-15','-DCMAKE_CUDA_HOST_COMPILER=/usr/bin/g++-15','-DCMAKE_CUDA_COMPILER=/opt/cuda/bin/nvcc','-DCMAKE_CUDA_ARCHITECTURES=89','-DGGML_CUDA=ON','-DGGML_CUDA_GRAPHS=ON','-DGGML_CUDA_FA_ALL_QUANTS=ON','-DGGML_CUDA_NCCL=OFF','-DLLAMA_BUILD_TESTS=ON']
(E/'turbo-build-command.json').write_text(json.dumps({'configure':cmd},indent=2))
try:
 with (E/'turbo-configure.log').open('w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
 print('Building TurboQuant for sm89',flush=True)
 with (E/'turbo-build.log').open('w') as f:subprocess.run(['cmake','--build',str(build),'--target','llama-server','test-moe-cache','test-backend-ops','test-turbo-quant','-j8'],stdout=f,stderr=subprocess.STDOUT,check=True)
 result={'status':'built','binary':str(build/'bin/llama-server')}
except subprocess.CalledProcessError as e:result={'status':'failed','error':str(e)}
(E/'turbo-build-result.json').write_text(json.dumps(result,indent=2));(E/'turbo-preparation-done.json').write_text(json.dumps(result));print(result,flush=True)
