import argparse,collections,hashlib,json,re,sqlite3
from pathlib import Path
ROOT=Path('/home/alex/Projects/AG1');E=ROOT/'implementation/evidence/flash-next-performance-20260914/ag1';W=ROOT/'.local/p14-long-horizon/ag1flash-20260914'
parser=argparse.ArgumentParser();parser.add_argument('--combined-lifecycle',action='store_true');parser.add_argument('--label-suffix',default='');args=parser.parse_args()
rows=[]
def answer(v):
 a=[m for m in v['details']['messages'] if m['role']=='assistant'];return '\n'.join(b.get('text','') for b in a[-1]['blocks'] if b['kind']=='text')
for arm in ['original','candidate']:
 label=arm+args.label_suffix
 o=E/label;r=json.loads((o/'result.json').read_text());results={}
 for task in ['chat','edit','web']:
  v=json.loads((o/(task+'-view.json')).read_text());text=answer(v);(o/(task+'-answer.md')).write_text(text+'\n')
  db=sqlite3.connect('file:'+str(W/label/'state/store/storage.sqlite')+'?mode=ro',uri=True)
  journal=[json.loads(raw) for raw, in db.execute('select normalized from entries where session=? order by ordinal',(v['snapshot']['scope']['session'],))];db.close()
  prefix={'chat':'Answer directly without using tools.','edit':'In the attached project, read services.json.','web':'Use webSearch once to find Python documentation'}[task]
  def content(message):
   val=message.get('content',[])
   return val if isinstance(val,str) else '\n'.join(x.get('text','') for x in val if x.get('type')=='text')
  messages=[x['message'] for x in journal if x.get('type')=='message']
  first=next(i for i,x in enumerate(messages) if x.get('role')=='user' and content(x).startswith(prefix))
  last=next((i for i in range(first+1,len(messages)) if messages[i].get('role')=='user'),len(messages));messages=messages[first:last]
  (o/(task+'-messages.json')).write_text(json.dumps(messages,indent=2)+'\n')
  tools=[{'name':m.get('toolName'),'failed':bool(m.get('isError'))} for m in messages if m.get('role')=='toolResult']
  counts=dict(collections.Counter(x['name'] for x in tools))
  results[task]={'answer':text,'whitespace_word_count':len(text.split()),'journal_tool_result_counts':counts,'failed_tools':[x['name'] for x in tools if x['failed']],'error':v['error'],'native_terminal':v['details']['activity'].get('last_terminal'),'task_status':v['details']['task'].get('status'),'latest_assistant_usage':v['details']['activity'].get('latest_assistant_usage')}
  if task=='chat':
   try:results[task]['exact_answer_pass']=json.loads(text)=={'answer':323}
   except (ValueError,TypeError):results[task]['exact_answer_pass']=False
  if task=='web':
   results[task]['web_tool_execution_pass']=counts.get('webSearch')==1 and counts.get('webFetch')==1 and not any(x['failed'] for x in tools)
   results[task]['under_100_words']=len(text.split())<=100
   results[task]['official_citation_present']='docs.python.org/3/library/time.html' in text
 before=(o/'services-before.json').read_text();expected=before.replace('"svc-047": {\n    "timeout_ms": 450,','"svc-047": {\n    "timeout_ms": 875,');actual=(W/label/'workspace/services.json').read_text();assert expected!=before
 r['independent_edit_exact_pass']=actual==expected;r['scored_tasks']=results
 checks={'driver_completed':r.get('status')=='completed',
         'tasks_completed_without_timeout_or_error':all(not t.get('timed_out') and not t.get('error') and not t.get('pending') for t in r['tests']),
         'chat_exact':results['chat']['exact_answer_pass'],
         'edit_exact':r['independent_edit_exact_pass'],
         'checker_preserved':r.get('checker_preserved',False),
         'web_tools':results['web']['web_tool_execution_pass'],
         'web_length':results['web']['under_100_words'],
         'web_citation':results['web']['official_citation_present'],
         'new_chat_reuses_backend':r.get('new_chat_reuses_backend',False),
         'backend_survived':r.get('backend_survived_all_tasks',False),
         'normal_quit':r.get('normal_app_quit',False),
         'backend_cleaned_up':not r.get('remaining_model_processes',[])}
 rows.append({'arm':arm,'label':label,'checks':checks,'all_checks_pass':all(checks.values()),'report':r});print(arm,checks,flush=True)
lifecycle=[]
for arm in ['original','candidate']:
 label=arm+args.label_suffix if args.combined_lifecycle else arm+'-lifecycle'+args.label_suffix;o=E/label
 r=json.loads((o/'result.json').read_text())
 before=answer(json.loads((o/'before-cancel-view.json').read_text())).strip()
 after=answer(json.loads((o/'after-cancel-view.json').read_text())).strip()
 try:recovered=json.loads(after)=={'recovered':True,'answer':323}
 except (ValueError,TypeError):recovered=False
 checks={'driver_completed':r.get('status')=='completed','before_cancel_exact':before=='323',
         'after_cancel_exact':recovered,'stop_settled':bool(r.get('stop')) and not r['stop'].get('error') and not r['stop'].get('pending'),
         'post_stop_healthy':r.get('post_stop_healthy',False),
         'backend_survived':r.get('backend_survived_all_tasks',False),
         'normal_quit':r.get('normal_app_quit',False),
         'backend_cleaned_up':not r.get('remaining_model_processes',[])}
 lifecycle.append({'arm':arm,'label':label,'checks':checks,'all_checks_pass':all(checks.values()),'report':r})
 print(label,checks,flush=True)
(E/'scored-results.json').write_text(json.dumps({'note':'Full tasks plus cancellation/recovery per arm, combined in each desktop session when requested. Diagnostic end-to-end timings, not a statistical model benchmark. Native views are bounded; first-assistant-block timing is not a reliable token metric. Mechanical checks do not replace manual assessment of answers and native terminal results.','combined_lifecycle':args.combined_lifecycle,'all_checks_pass':all(x['all_checks_pass'] for x in rows+lifecycle),'runs':rows,'lifecycle':lifecycle},indent=2)+'\n')
