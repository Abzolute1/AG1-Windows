"""Prepare private AG1 captures only after inference queues stop.

Usage: python prepare.py /absolute/path/to/winning-bench-config.json
Never changes production profiles, runtime paths, or model files.
"""
import copy, hashlib, json, os, subprocess, sys
from pathlib import Path

ROOT=Path('/home/alex/Projects/AG1')
R=ROOT/'.local/ag1-flash-validation-20260914'
E=ROOT/'implementation/evidence/flash-next-performance-20260914/ag1'
def sha(p):
    with Path(p).open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()
def save(p,x):
    p.write_text(json.dumps(x,indent=2)+'\n');p.chmod(0o600)
    return {'path':str(p),'sha256':sha(p)}

candidate=json.loads(Path(sys.argv[1]).read_text())
assert not candidate.get('remove'), 'Placement/removal profiles need explicit launch adaptation'
assert '--model' not in candidate.get('flags',{}), 'This capture covers the primary model; alternative weights require explicit material/identity adaptation'
assert not candidate.get('cupti') and not candidate.get('perf')
# Capturing hashes reads all shards; this must not overlap timed inference.
for p in Path('/proc').iterdir():
    if not p.name.isdigit():continue
    try:name=(p/'exe').resolve(strict=True).name
    except OSError:continue
    assert name not in ['llama-server','llama-bench','nvcc','ninja','cc1plus'], (p.name,name)
E.mkdir(parents=True,exist_ok=True)
source=json.loads(Path('/home/alex/.local/state/ag1/desktop/configuration/runtime-configuration-vision-20260909.json').read_text())['request']
model=next(m for m in source['models'] if 'Flash-Next' in m['model_id']);mid=model['model_id']
profiles=json.loads(Path(source['profile']['path']).read_text())
cfgbase=json.loads((ROOT/'.local/chat-launcher-recovery-20260914/probe-config.json').read_text())
assert cfgbase.get('fixture') is False, 'Actual AG1 validation requires the real provider, never fixture mode'
originalroot=Path(model['expected']['command']).parent
weightdir=Path(model['model_path']).parent
weights=[x for x in model['materials'] if Path(x['path']).parent==weightdir]
assert len(weights)==28 and all(x['kind']=='weight' for x in weights)
fieldmap={'--batch-size':'batchSize','--ubatch-size':'ubatchSize','--threads':'decodeThreads',
          '--threads-batch':'batchThreads','--n-cpu-moe':'nCpuMoe','--ctx-size':'contextWindow',
          '--cache-type-k':'cacheTypeK','--cache-type-v':'cacheTypeV','--fit':'fit',
          '--fit-target':'fitTarget','--n-gpu-layers':'nGpuLayers','--load-mode':'loadMode',
          '--spec-type':'specType'}
integerfields={'batchSize','ubatchSize','decodeThreads','batchThreads','nCpuMoe','contextWindow'}
for arm in ['original','candidate']:
    d=R/arm;d.mkdir(mode=0o700)
    c={} if arm=='original' else candidate
    profile=copy.deepcopy(profiles['models'][mid]);m=copy.deepcopy(model)
    env=json.loads(Path(source['inherited_environment']['path']).read_text())
    for key in list(env):
        if key.startswith(('GGML_','LLAMA_ARG_','LLAMA_MOE_','LLAMA_MMAP_','GOMP_','OMP_','AG1_FLASH_','TURBO_')) or key in ['LD_PRELOAD','LD_LIBRARY_PATH']:env.pop(key)
    env['LLAMA_CPP_PORT']='18436'
    profile['serverPath']=c.get('binary',model['expected']['command'])
    profile['libPath']=str(Path(profile['serverPath']).parent)
    profile['environment']=c.get('environment',{})
    args=copy.deepcopy(model['expected']['args'])
    args=args[:-len(profile['extraArgs'])]
    flags=c.get('flags',{})
    for flag,field in fieldmap.items():
        if flag in flags:profile[field]=int(flags[flag]) if field in integerfields else str(flags[flag])
    assert profile['contextWindow']==90000 and profile['cacheTypeK']==profile['cacheTypeV']=='q8_0'
    profile['contextBatchTiers']=[{'maxContextWindow':90000,'batchSize':profile['batchSize'],
                                  'ubatchSize':int(flags.get('--ubatch-size',1024))}]
    def replace(flag,value):
        i=args.index(flag);args[i+1]=str(value)
    replace('--port',18436)
    for flag,field in fieldmap.items():
        if flag in flags and flag in args:replace(flag,profile[field])
    replace('--cpu-range',f"0-{profile['decodeThreads']-1}")
    replace('--cpu-range-batch',f"0-{profile['batchThreads']-1}")
    for flag,nextflag in [('--load-mode','--parallel'),('--spec-type','--fit')]:
        field=fieldmap[flag]
        if field in profile and flag not in args:
            i=args.index(nextflag);args[i:i]=[flag,str(profile[field])]
    extras=profile['extraArgs'].copy()
    for flag,value in flags.items():
        if flag in fieldmap:continue
        if flag in ['--cpu-range','--cpu-range-batch']:
            assert str(value)==args[args.index(flag)+1], 'Non-default affinity needs explicit adaptation'
            continue
        if flag in extras:extras[extras.index(flag)+1]=str(value)
        else:extras += [flag,str(value)]
    extras += c.get('extra',[]);profile['extraArgs']=extras;args+=extras
    system_materials=[x for x in model['materials'] if x['kind']!='weight' and not x['path'].startswith('/home/alex/')]
    if arm=='original':
        runtime=[x for x in model['materials'] if Path(x['path']).parent==originalroot]
    else:
        lib=Path(profile['libPath'])
        runtime=[{'path':str(p),'sha256':sha(p),'kind':'executable' if p.name=='llama-server' else 'library'}
                 for p in sorted(set([Path(profile['serverPath']),*lib.glob('lib*.so*')])) if p.is_file()]
    extra_weights=[]
    if '--spec-draft-model' in flags:
        draft_path=str(flags['--spec-draft-model'])
        draft=next((x for x in model['materials'] if x['kind']=='weight' and x['path']==draft_path),None)
        assert draft is not None, 'Draft head must be an existing preserved material or receive a separate reviewed capture'
        extra_weights.append(draft)
    m['materials']=system_materials+runtime+weights+extra_weights
    expectedenv={**env,**profile['environment'],'LD_LIBRARY_PATH':profile['libPath']}
    m['expected'].update(command=profile['serverPath'],args=args,environment=expectedenv)
    req={**copy.deepcopy(source),'models':[m],
         'profile':save(d/'profiles.json',{'version':1,'models':{mid:profile}}),
         'inherited_environment':save(d/'environment.json',env),'additional_inputs':{}}
    save(d/'import-request.json',req)
    with (d/'capture.stdout').open('w') as out,(d/'capture.stderr').open('w') as err:
        result=subprocess.run(['/opt/ag1/current/bin/ag1-cutover','capture-runtime',str(d/'import-request.json'),str(d/'capture.json')],stdout=out,stderr=err,timeout=1200)
    assert result.returncode==0, 'Private capture failed; inspect private stderr: '+arm
    receipt=json.loads((d/'capture.stdout').read_text());save(d/'capture-receipt.json',receipt)
    cfg=copy.deepcopy(cfgbase);cfg['models']=[next(x for x in cfg['models'] if x['id']==mid)]
    # Use the core's canonical profile representation so Resolver's exact
    # catalog comparison agrees after the persisted thinking control is replayed.
    thinking=cfg['models'][0]['thinking']
    thinking['modes']=[{'id':v,'nativeValue':v} if isinstance(v,str) else v for v in thinking['modes']]
    thinking.pop('default',None)
    cfg['models'][0]['baseUrl']='http://127.0.0.1:18436/v1'
    cfg.update(selected=mid,credentials={},credential_env=None,extensions=None,packages=None,max_generations=12,policy_mode='autonomous')
    settings=json.loads(Path(cfg['imported']['settings']['path']).read_text())
    settings['defaultModel']=mid
    cfg['imported']={'settings':save(d/'settings.json',settings),'credentials':None}
    cfg['runtime']['capture']=receipt;cfg['runtime']['exclusive_gpu']=False
    save(d/'config.json',cfg)
    save(E/(arm+'-launch.json'),{'binary':profile['serverPath'],'library_directory':profile['libPath'],
         'args':args,'selected_environment':profile['environment'],'model':mid,
         'configuration_capture_sha256':receipt['sha256'],'scope':'Private AG1 capture; all 28 original shards unchanged.'})
    print('Captured',arm,flush=True)
save(E/'setup.json',{'ag1_release':str(Path('/opt/ag1/current').resolve()),'model':mid,'private_root':str(R),
                    'port':18436,'screen_capture':False,'candidate_bench_config':candidate})
