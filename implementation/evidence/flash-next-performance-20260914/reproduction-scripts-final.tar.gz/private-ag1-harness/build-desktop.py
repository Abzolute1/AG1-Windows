"""Build the current desktop with a private DOM broker after benchmark work stops."""
import hashlib
import json
import os
import shutil
import subprocess
from pathlib import Path

ROOT = Path('/home/alex/Projects/AG1')
R = ROOT/'.local/ag1-flash-validation-20260914'
E = ROOT/'implementation/evidence/flash-next-performance-20260914/ag1'
for proc in Path('/proc').iterdir():
    if not proc.name.isdigit():
        continue
    try:
        name = (proc/'exe').resolve(strict=True).name
    except OSError:
        continue
    assert name not in {'llama-server', 'llama-bench', 'nvcc', 'ninja', 'cc1plus', 'rustc'}, (proc.name, name)
destination = R/'desktop-build'
destination.mkdir()
E.mkdir(parents=True, exist_ok=True)
target = ROOT/'.local/p14-target'
command = ['cargo', 'build', '--offline', '--locked', '--manifest-path', 'product/Cargo.toml',
           '--release', '-p', 'ag1-desktop', '--bin', 'ag1-desktop', '--features', 'visual-test', '-j', '12']
environment = {**os.environ, 'CARGO_TARGET_DIR': str(target), 'CARGO_INCREMENTAL': '0'}
manifest = {'command': command, 'cwd': str(ROOT),
            'build_environment': {k: environment[k] for k in ['CARGO_TARGET_DIR', 'CARGO_INCREMENTAL']},
            'scope': 'Current-source Tauri/WebKit desktop with private visual-test DOM broker; installed process host, real provider and tools. Not the untouched installed desktop executable.'}
(E/'desktop-build-command.json').write_text(json.dumps(manifest, indent=2))
with (E/'desktop-build.log').open('x') as log:
    subprocess.run(command, cwd=ROOT, env=environment, stdout=log, stderr=subprocess.STDOUT, check=True)
binary = destination/'ag1-desktop'
shutil.copy2(target/'release/ag1-desktop', binary)
with binary.open('rb') as f:
    manifest['sha256'] = hashlib.file_digest(f, 'sha256').hexdigest()
manifest['binary'] = str(binary)
manifest['renderer_inputs'] = {str(p.relative_to(ROOT/'product/apps/desktop/dist')): hashlib.sha256(p.read_bytes()).hexdigest()
                               for p in sorted((ROOT/'product/apps/desktop/dist').rglob('*')) if p.is_file()}
manifest['status'] = 'built'
(E/'desktop-build.json').write_text(json.dumps(manifest, indent=2))
print('Built private desktop:', binary, flush=True)
