import argparse,json,os,shutil,subprocess
from pathlib import Path
parser=argparse.ArgumentParser();parser.add_argument('--reuse-prepared-app',action='store_true');parser.add_argument('--label-suffix',default='');parser.add_argument('--arms',nargs='+',choices=['original','candidate'],default=['original','candidate']);options=parser.parse_args()
ROOT=Path('/home/alex/Projects/AG1');R=ROOT/'.local/ag1-flash-validation-20260914';W=ROOT/'.local/p14-long-horizon/ag1flash-20260914';W.mkdir(mode=0o700,exist_ok=options.reuse_prepared_app)
if options.reuse_prepared_app:
 assert (R/'authority').is_dir() and (R/'app/ag1-desktop').is_file() and (R/'app/ag1-process-host').is_file()
else:
 (R/'authority').mkdir(mode=0o700);(R/'app').mkdir();shutil.copy2(R/'desktop-build/ag1-desktop',R/'app/ag1-desktop');shutil.copy2('/opt/ag1/current/bin/ag1-process-host',R/'app/ag1-process-host')
# The custom-protocol build embeds the current source renderer; preserve its exact input files too.
if not options.reuse_prepared_app:shutil.copytree(ROOT/'product/apps/desktop/dist',R/'app/renderer')
prefix=['/usr/bin/bwrap','--die-with-parent','--unshare-pid','--ro-bind','/','/','--proc','/proc','--dev-bind','/dev','/dev','--bind',str(R),str(R),'--bind',str(W),str(W),'--bind',str(R/'authority'),'/home/alex/.local/state/ag1/authority-v1','--tmpfs','/tmp','--']
for arm in options.arms:
 label=arm+options.label_suffix
 if label!=arm:(R/label).mkdir(mode=0o700)
 assert len(str(R/label/'control.sock').encode())<108
 d=W/label;d.mkdir(mode=0o700);shutil.copyfile(R/arm/'config.json',d/'config.json');(d/'config.json').chmod(0o600)
 for name,args in [('init',['--init',str(d/'workspace')]),('admit',['--workspace',str(d/'workspace'),'--state',str(d/'state'),'--config',str(d/'config.json'),'--export',str(d/'initial.html')])]:
  p=subprocess.run(prefix+['/opt/ag1/current/bin/ag1-cli']+args,capture_output=True,timeout=240)
  (R/label/(name+'.stdout')).write_bytes(p.stdout);(R/label/(name+'.stderr')).write_bytes(p.stderr)
  assert p.returncode==0,(label,name,p.stderr.decode()[:300])
 print('Desktop workspace admitted',label,flush=True)
