# Combined chat presentation cleanup

Status: planned combined pass. Existing activity summaries, thought controls and change/output/GitHub cards must be preserved and reused. Read the [task index and shared rules](README.md); do not begin implementation solely because this file exists.

## Intended result

Everyday results should be readable directly in the conversation or through one useful review/details entry point. Failures and pending decisions stay easy to find. Exact arguments, raw output and diagnostic records remain available when needed.

## Remaining tasks

- [ ] Inspect the current conversation presentation after artifact/review and MCP work. Identify actual repeated nesting and unnecessary controls; do not replace existing working summaries without a demonstrated problem.
- [ ] Consolidate successful work into concise activity summaries and useful output/change cards. Reduce repeated Activity → tool → Arguments → Output nesting for normal results.
- [ ] Keep failures, uncertain effects and pending approvals immediately discoverable. Preserve exact technical arguments/raw logs on demand and avoid falsely presenting failed or merely accepted operations as completed work.
- [ ] Preserve thought visibility controls, streaming/call pairing, copy fidelity and virtualized long-history behavior. Bound rendering and avoid repeated large-content hydration.
- [ ] Preserve accessibility, keyboard/focus behavior, chat position and drafts as cards and panels open, close or update.
- [ ] Review empty/loading/error/cancelled states and terminology across artifacts, local changes, GitHub, MCP and approvals. The visible result must agree with the native outcome and the assistant's action.
- [ ] Check wide/narrow layouts, long names/logs, multiple concurrent/pending activities and mixed results using focused frontend and native fixtures.

## Acceptance

Users can understand the main result and any required decision without opening debug records. Failure details and exact source remain accessible. Existing streaming, history, thought, approval, artifact, GitHub and MCP behavior survives the presentation changes.

Capture a current native conversation example with screenshots and inspect it for unnecessary nested controls. Run appropriate regressions, build/install at a major verified checkpoint, and report what remains for [combined final verification](04-FINAL-VERIFICATION.md).
