Latest desktop repair: [monitor refresh-rate clock](../implementation/DISPLAY-REFRESH-20260913.md), installed systemwide. NVIDIA/WebKit fallback now uses native Wayland GTK frame timing: controlled probe 165 FPS; actual AG1 Settings scroll median 6 ms. Restart AG1.

Latest MCP repair: [pagination and Discover loading](../implementation/MCP-DISCOVER-LOADING-20260913.md), installed systemwide. Bounded listing summaries fix oversized page failures; retained public display data and concurrent icon fetching improve reopening. 27 focused checks passed. Restart AG1.

Latest MCP UI: [additional readability pass](../implementation/MCP-DISCOVER-READABILITY-20260913.md), installed systemwide. 52 px icons, 19 px names, 17 px descriptions, 15 px metadata and slightly more row padding. Restart AG1.

Latest MCP sizing: [larger icons and text](../implementation/MCP-DISCOVER-SCALE-20260913.md), installed systemwide. Icons are 48 px; names 18 px; descriptions 16 px. Restart AG1.

Latest MCP UI: [readable rows and persistent details pane](../implementation/MCP-DISCOVER-ROWS-20260913.md) is complete and installed systemwide. Both launchers use the new build; restart AG1.

Latest MCP fix: [publisher icons and readable rows](../implementation/MCP-DISCOVER-ICONS-20260913.md) is installed systemwide and per-user. Restart AG1.

Latest MCP UI: [Discover desktop redesign](../implementation/MCP-DISCOVER-UI-20260913.md) is complete and installed for this user. Restart AG1. The same verified build is installed systemwide.

Latest UI change: [compact response workflow](../implementation/WORKFLOW-UI-20260911.md) is installed and verified. One expandable work section, descriptive tool rows, and routine GitHub results tucked into their rows. 50 tests and nine isolated visual states passed. Restart AG1.

Latest UI change: [Markdown readability](../implementation/MARKDOWN-READABILITY-20260911.md) is installed: tighter lists, stronger inline code, syntax highlighting and per-block copy buttons. Restart AG1; existing messages benefit too.

Latest: [model interface consolidation](08-INTERFACE-CONSOLIDATION.md) is installed and verified. New chats use fewer default tools, automatic observation projection, typed evidence operations and specialist discovery. 23 focused tests, a packaged native workflow and a bounded real Luna check passed. Restart AG1 and start a new chat for the preferred defaults.

Earlier repair: [GitHub bypass approvals](../implementation/GITHUB-BYPASS-20260911.md) now honors explicit chat bypass; installed and verified.

Latest styling update: [brighter desktop text](../implementation/DESKTOP-TEXT-CONTRAST-20260911.md) is installed and verified. Reopen AG1 to load it.

Latest: the [surgical](06-ASTRA-SURGICAL-INTERFACE.md) and all six [deeper Astra interface fixes](07-ASTRA-DEEPER-INTERFACE.md) are complete and installed. Final live workflows passed with Luna and Qwen35B; Qwen corrected one missing argument. See the [handoff and limits](../implementation/ASTRA-DEEPER-INTERFACE-20260911.md).

Current: GitHub usability repair is installed and passed the requested fresh Qwen live test; see [acceptance](../implementation/GITHUB-USABILITY.md). [OpenAI subscription models](05-OPENAI-OAUTH-MODELS.md) are also installed and live verified. [Core MCP integration](../implementation/MCP-INTEGRATION-ACCEPTANCE.md) is complete and installed as a normal production release on 2026-09-13. Restart AG1. The acceptance record lists supported behavior, explicit compatibility limits and final evidence.

# Remaining work

Updated: 2026-09-13. This is the current task index, replacing the former root plan and combined artifact/GitHub/MCP plan.

**Status: MCP core phases A–F complete and installed.** GitHub repair and OpenAI subscription model integration remain completed. Other feature tasks, the real-model audit and duration programme remain paused.

## Task files and order

| Order | Task | Current state | Completion target |
| --- | --- | --- | --- |
| 1 | [Artifact and change-review closeout](01-ARTIFACT-REVIEW.md) | Panel, receipts, cards and single-operation Undo exist; reconcile remaining presentation and current native coverage | Truthful, usable review and output flows with verified preservation and explicit limits |
| 2 | [MCP client, manager and discovery](02-MCP-INTEGRATION.md) | Core A–F complete and installed on 2026-09-13; [acceptance and limits](../implementation/MCP-INTEGRATION-ACCEPTANCE.md) | Delivered within the documented Linux/protocol/setup compatibility boundary |
| 3 | [Chat cleanup](03-CHAT-CLEANUP.md) | Combined pass remains; reuse existing activity and card work | Clear primary results and approvals with technical details available on demand |
| 4 | [Combined regression, visual and bounded live verification](04-FINAL-VERIFICATION.md) | Combined final pass remains | Evidence for the finished feature set on the exact final build, followed by checkpoint installation and handoff |

The order carries forward the former plan. Task 1 begins by checking what already exists, not rebuilding completed features. Tasks 1–3 provide the implementation to verify in task 4. Each task also needs its own relevant checks as it progresses.

The MCP plan treats native management and discovery through an existing public registry ecosystem as core requirements. Its A–F phases separate protocol foundation, AG1 integration, authentication/trust, manager UI, discovery and acceptance. Registry backend/hosting work is excluded; optional enhancements are listed separately. MCP resumed on 2026-09-12 and core integration completed on 2026-09-13. The user’s unattended MCP request is fulfilled within the documented compatibility boundary. Other paused tasks remain outside that request.

## Completed GitHub work

GitHub was reopened after practical model calls exposed discovery/execution mismatches. The [current repair](../implementation/GITHUB-MODEL-REPAIR.md) supersedes the earlier completion claim for model usability. Read [github.md](../github.md) for usage, the [capability matrix](../implementation/P14-GITHUB-CAPABILITIES.md) for coverage, and the [final acceptance report](../implementation/P14-GITHUB-FINAL-20260911.md) for exact evidence.

The installed GitHub checkpoint is `/opt/ag1/releases/8bf70ba10402450a82054ea118f2b0b1`, desktop SHA `e3d18956c55b5fca782e34ec0c23a2815103e2e9a315066c99119af1b69cc6b5`. It passed 220 frontend tests, 77 GitHub units, 44 related native contracts and 12 desktop audits. All 1,142 installed payload files and the receipt were verified. These are dated checkpoint results, not automatic acceptance of later changes.

## Shared working rules

- Preserve existing tracked/untracked work, user projects, chat state and retained evidence. Do not reset/clean the worktree or rewrite frozen expectations.
- Reuse the shared native authority, folder grants, effect receipts and account/server identity boundaries. Model text, tool-result JSON and renderer state cannot manufacture authority.
- Use owned fixtures and isolated scratch projects. Do not mutate real GitHub accounts/repositories, trigger paid CI, or disclose private information to an external MCP server without explicit authority for that action.
- Use isolated native candidates and a separate embedded renderer. Never overwrite a binary referenced by accepted evidence. Private native displays must be authenticated, and owned children must be stopped and reaped.
- Rust work uses `CARGO_TARGET_DIR=/home/alex/Projects/AG1/.local/p14-target`, `CARGO_INCREMENTAL=0`, and `--offline --locked --manifest-path product/Cargo.toml`. Never rebuild `product/target/release/ag1-process-host` in place.
- Preserve model profiles, tuned llama.cpp backends, weights, launch/request settings and native-host configuration. The [GitHub acceptance report](../implementation/P14-GITHUB-FINAL-20260911.md) links the latest protected-hash verification. Runtime authority and rollback rules remain in the [cutover guide](../product/clients/CUTOVER.md).
- When implementation is resumed, retain the user's checkpoint preference: build and install the normal production distribution after each major verified checkpoint, then give a short summary of remaining work and effort. Diagnostic binaries are not installable production checkpoints.
- Bounded real-model testing was authorized for the final feature audit, but remains paused with that task. No eight-hour or substitute 24-hour run is authorized by these task files. Keep the separate duration hold intact.
- Seven frozen comparison failures were reproduced unchanged at the historical GitHub checkpoint: five core and two platform. The MCP B1 continuation reproduced six core failures before editing and with identical assertion bodies afterward (22 passes); see its baseline comparison evidence. Retain historical evidence, rerun relevant comparisons when needed, and distinguish old mismatches from new failures.

## Separate release backlog

The broader P14 release programme has additional unfinished work: partially completed matched model comparisons, model debrief/context-quality runs, review of an isolated shell-hint draft, packaged performance, duration, Windows/macOS, signing and final release acceptance. It is not silently folded into this feature task list or authorized by the documentation cleanup.

Its governing requirements remain in the [P14 release phase](../phases/P14-release-and-long-horizon-gates.md). The [release resume record](../implementation/P14-RESUME-HANDOFF.md) retains exact partial-run custody and remaining gates. Its candidate, process and workstation observations are historical and must be reconciled against current evidence before any future execution. The original [roadmap](../ROADMAP.md), [phase index](../phases/README.md), architecture documents, runtime-preservation records and machine completion manifests remain useful references.

## Documentation cleanup

Removed from the active tree after migrating their remaining requirements:

- `plan.md`: mixed historical checkpoint log and obsolete continuation instructions; replaced by this index and the four task files.
- `implementation/P14-ARTIFACTS-GITHUB-MCP-GOAL.md`: combined plan with stale unchecked items; replaced by focused task files, the artifact checkpoint record and completed GitHub documentation.
- `implementation/P14-GITHUB-HANDOFF-20260910.md`: pre-completion GitHub resume instructions; superseded by the final acceptance report and capability matrix.

Useful artifact history is summarized in the [artifact/review checkpoint record](../implementation/P14-ARTIFACT-REVIEW-CHECKPOINT.md). GitHub checkpoint reports, failed-run evidence, release handoffs, rollback guides, product documentation, licences and machine-bound phase records were retained.

Exact pre-cleanup documents and hashes are preserved in [the recovery archive](../.local/plan-doc-cleanup-20260911-wgz0foyz/original-documents.tar.gz) and [manifest](../.local/plan-doc-cleanup-20260911-wgz0foyz/manifest.json). This local backup is ignored by Git; preserve it if moving the workspace. It is recovery material, not another active plan.
