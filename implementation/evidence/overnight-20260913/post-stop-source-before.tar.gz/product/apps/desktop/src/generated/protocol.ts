// Generated from ag1-protocol Rust DTOs. Run protocol-codegen; do not edit.
export type JsonValue = number | string | boolean | Array<JsonValue> | { [key in string]: JsonValue } | null;
export type WorkspaceId = string;
export type SessionId = string;
export type BranchId = string;
export type OperationId = string;
export type ArtifactId = string;
export type CommandId = string;
export type InstanceId = string;
export type SubscriptionId = string;
export type ApprovalId = string;
export type Sequence = string;
export type Version = { major: number, minor: number, schema: string, };
export type ProtocolError = { "code": "incompatible_version" } | { "code": "malformed", detail: string, } | { "code": "oversize", limit: number, use_artifact: boolean, } | { "code": "queue_full", queue: string, capacity: number, } | { "code": "unavailable", family: string, } | { "code": "stale_context" } | { "code": "command_conflict" } | { "code": "invalid_approval" } | { "code": "not_found" } | { "code": "resync_required" } | { "code": "capacity", resource: string, };
export type Scope = { workspace: WorkspaceId, session: SessionId, instance: InstanceId, epoch: Sequence, };
export type CommandEnvelope = { version: Version, id: CommandId, scope: Scope, expected_revision: Sequence, command: Command, extension?: unknown, };
export type PromptInput = { "kind": "inline", text: string, } | { "kind": "artifact", artifact: ArtifactId, } | { "kind": "message_artifact", artifact: ArtifactId, };
export type Command = { "kind": "prompt", input: PromptInput, } | { "kind": "cancel", operation: OperationId, } | { "kind": "approve", binding: ApprovalBinding, allow: boolean, } | { "kind": "command_result", command: CommandId, } | { "kind": "artifact_read", artifact: ArtifactId, offset: Sequence, limit: number, } | { "kind": "project", action: string, args: JsonValue, } | { "kind": "session", action: string, args: JsonValue, } | { "kind": "task", action: string, args: JsonValue, } | { "kind": "plan", action: string, args: JsonValue, } | { "kind": "files", action: string, args: JsonValue, } | { "kind": "artifacts", action: string, args: JsonValue, } | { "kind": "memory", action: string, args: JsonValue, } | { "kind": "model", action: string, args: JsonValue, } | { "kind": "runtime", action: string, args: JsonValue, } | { "kind": "diagnostics", action: string, args: JsonValue, };
export type ApprovalBinding = { id: ApprovalId, operation: OperationId, argument_sha256: string, scope: Scope, revision: Sequence, expires_ms: Sequence, };
export type OperationStatus = "queued" | "completed" | "cancelled" | "failed";
export type OperationView = { operation: OperationId, status: OperationStatus, };
export type CommandResult = { "kind": "accepted", operation: OperationId, } | { "kind": "settled", operation: OperationView, } | { "kind": "artifact_page", artifact: ArtifactId, offset: Sequence, base64: string, next: Sequence | null, } | { "kind": "rejected", error: ProtocolError, };
export type Reply = { id: CommandId, scope: Scope, watermark: Sequence, result: CommandResult, };
export type Snapshot = { fake: boolean, scope: Scope, branch: BranchId, revision: Sequence, watermark: Sequence, queued: Array<OperationId>, last_terminal: OperationView | null, };
export type Event = { scope: Scope, sequence: Sequence, revision: Sequence, operation: OperationView, };
export type Cursor = { scope: Scope, after: Sequence, };
export type Delivery = { "kind": "events", events: Array<Event>, cursor: Cursor, more: boolean, } | { "kind": "progress", scope: Scope, operation: OperationId, tick: Sequence, text: string, } | { "kind": "gap", snapshot: Snapshot, };
export type Subscription = { id: SubscriptionId, snapshot: Snapshot, };
export type Handshake = { version: Version, scope: Scope, fake: boolean, capabilities: Array<string>, };
export type BridgeMessage = { id: string, role: string, text: string, evidence: string, };
export type BridgeQuestion = { binding: ApprovalBinding, title: string, kind: string, options: Array<string>, evidence: string, truncated: boolean, };
export type BridgeSnapshot = { version: Version, scope: Scope, revision: Sequence, watermark: Sequence, workspace_path: string, status: string, active_operation: OperationId | null, messages: Array<BridgeMessage>, message_count: number, pending: Array<BridgeQuestion>, model: string, diagnostic: string | null, session_file: string | null, fixture_provider: boolean, };
export type BridgeFrame = { "kind": "snapshot", snapshot: BridgeSnapshot, } | { "kind": "reply", id: CommandId, scope: Scope, revision: Sequence, durable: boolean, status: string, data: JsonValue, } | { "kind": "progress", scope: Scope, operation: OperationId, text: string, } | { "kind": "fatal", detail: string, };
export type MessageBlock = { "kind": "text", text: string, } | { "kind": "thinking", text: string, } | { "kind": "tool", name: string, call_id: string, arguments: JsonValue, } | { "kind": "attachment", media_type: string, reference: string, } | { "kind": "unknown", value: JsonValue, };
export type ClientMessage = { id: string, role: string, blocks: Array<MessageBlock>, 
/**
 * Execution identity, independent of result arrival order or display text.
 */
tool?: ToolResultIdentity, };
export type ToolResultIdentity = { call_id: string, name: string, failed: boolean, };
export type ClientDetails = { authority: string, messages: Array<ClientMessage>, task: JsonValue, context: JsonValue, artifacts: Array<JsonValue>, memory: JsonValue, activity: JsonValue, models: Array<JsonValue>, capabilities: Array<string>, };
export type ClientView = { snapshot: BridgeSnapshot, error: string | null, progress: string, details: ClientDetails, };
export type WireMessage = { "type": "handshake", "data": Handshake } | { "type": "command", "data": CommandEnvelope } | { "type": "result", "data": Reply } | { "type": "snapshot", "data": Snapshot } | { "type": "delivery", "data": Delivery } | { "type": "subscription", "data": Subscription } | { "type": "cursor", "data": Cursor } | { "type": "error", "data": ProtocolError } | { "type": "bridge", "data": BridgeFrame } | { "type": "client", "data": ClientView };
