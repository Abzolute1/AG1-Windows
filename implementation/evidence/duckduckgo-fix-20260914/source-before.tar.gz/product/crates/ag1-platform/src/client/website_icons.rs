//! Optional public favicon decoration, bound to an existing web-tool result.
//! Never fetch from the renderer, send search text/credentials, or alter tool evidence.
use super::*;
use crate::web_http::{SystemResolver, WebPolicy, WebResolver};
use std::{collections::{HashSet, VecDeque}, net::SocketAddr, sync::LazyLock, time::Instant};
use reqwest::Url;

pub(super) fn sources(entry: &Value) -> Vec<Value> {
    let m=&entry["message"];
    if m["role"]!="toolResult" || m["isError"]==true {return vec![];}
    let details=&m["details"];
    let urls:Vec<_>=match m["toolName"].as_str() {
        Some("webSearch")=>details["sourceUrls"].as_array().into_iter().flatten().filter_map(Value::as_str).take(4).collect(),
        Some("webFetch")=>details["finalUrl"].as_str().or_else(||details["url"].as_str()).into_iter().collect(),
        _=>return vec![],
    };
    let mut seen=HashSet::new();
    urls.into_iter().filter_map(|raw| {
        if raw.len()>2048 {return None;}
        let url=Url::parse(raw).ok()?;
        if !matches!(url.scheme(),"http"|"https") || !url.username().is_empty() || url.password().is_some() || !seen.insert(url.to_string()) {return None;}
        let title=details["results"].as_array().into_iter().flatten().find(|row|row["url"]==raw).and_then(|row|row["title"].as_str()).unwrap_or_else(||url.host_str().unwrap_or("Webpage"));
        Some(json!({"url":url.as_str(),"title":title.chars().take(240).collect::<String>()}))
    }).collect()
}
fn origin(raw:&str)->Result<Url> {
    let mut url=Url::parse(raw).map_err(|_|DomainError::PermissionDenied)?;
    if !matches!(url.scheme(),"http"|"https") || !url.username().is_empty() || url.password().is_some() || url.port().is_some() {return Err(DomainError::PermissionDenied);}
    url.set_scheme("https").map_err(|_|DomainError::PermissionDenied)?;
    url.set_path("/");url.set_query(None);url.set_fragment(None);Ok(url)
}
#[derive(Default)]
struct Cache { values:VecDeque<(String,Option<String>,Instant)>, inflight:HashSet<String>, requests:VecDeque<Instant> }
static CACHE:LazyLock<Mutex<Cache>>=LazyLock::new(||Mutex::new(Cache::default()));
pub(super) fn icon(raw:&str)->Result<Option<String>> {
    let root=origin(raw)?;let key=root.to_string();let now=Instant::now();
    {
        let mut c=CACHE.lock().map_err(|_|DomainError::Conflict)?;
        c.values.retain(|(_,_,until)|*until>now);
        if let Some((_,data,_))=c.values.iter().find(|(k,_,_)|k==&key) {return Ok(data.clone());}
        c.requests.retain(|t|now.duration_since(*t)<Duration::from_secs(60));
        if c.inflight.len()>=4 || c.inflight.contains(&key) || c.requests.len()>=60 {return Ok(None);}
        c.inflight.insert(key.clone());c.requests.push_back(now);
    }
    let data=fetch(root).ok();
    let mut c=CACHE.lock().map_err(|_|DomainError::Conflict)?;c.inflight.remove(&key);
    let ttl=if data.is_some(){3600}else{300};c.values.push_back((key,data.clone(),Instant::now()+Duration::from_secs(ttl)));
    while c.values.len()>128 {c.values.pop_front();}
    Ok(data)
}
fn fetch(root:Url)->Result<String> {
    let runtime=tokio::runtime::Builder::new_current_thread().enable_all().build().map_err(|_|DomainError::Unavailable("icon runtime".into()))?;
    runtime.block_on(async {tokio::time::timeout(Duration::from_secs(6),async {
        for path in ["favicon.ico","apple-touch-icon.png"] {
            let mut url=root.join(path).map_err(|_|DomainError::PermissionDenied)?;
            for redirects in 0..=2 {
                if url.scheme()!="https" || url.port_or_known_default()!=Some(443) || !url.username().is_empty() || url.password().is_some() {break;}
                let host=url.host_str().ok_or(DomainError::PermissionDenied)?;
                let addresses=SystemResolver.resolve(host,443).await?;WebPolicy::default().validate(url.as_str(),&addresses)?;
                let addresses:Vec<_>=addresses.into_iter().map(|ip|SocketAddr::new(ip,443)).collect();
                let client=reqwest::Client::builder().no_proxy().no_gzip().no_brotli().no_deflate().redirect(reqwest::redirect::Policy::none()).retry(reqwest::retry::never()).pool_max_idle_per_host(0).connect_timeout(Duration::from_secs(2)).timeout(Duration::from_secs(3)).resolve_to_addrs(host,&addresses).build().map_err(|_|DomainError::Unavailable("icon TLS".into()))?;
                let response=client.get(url.clone()).header("accept","image/*").header("user-agent","AG1/0.1").send().await;
                let Ok(mut response)=response else {break;};
                let h=response.headers();
                if h.len()>64 || h.iter().map(|(k,v)|k.as_str().len()+v.as_bytes().len()).sum::<usize>()>16384 || h.get("content-encoding").is_some_and(|v|v!="identity") {break;}
                if response.status().is_redirection() && redirects<2 {
                    let Some(next)=h.get("location").and_then(|v|v.to_str().ok()).and_then(|v|url.join(v).ok()) else {break;};url=next;continue;
                }
                if response.status()!=200 || response.content_length().is_some_and(|n|n>128*1024) {break;}
                let mut bytes=Vec::new();
                while let Some(chunk)=response.chunk().await.map_err(|_|DomainError::Unavailable("icon body".into()))? {
                    if bytes.len()+chunk.len()>128*1024 {return Err(DomainError::LimitExceeded("icon bytes".into()));}bytes.extend_from_slice(&chunk);
                }
                if let Ok(data)=crate::image_tools::website_icon(&bytes) {return Ok(data);}
                break;
            }
        }
        Err(DomainError::NotFound)
    }).await.map_err(|_|DomainError::TimedOut)?})
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn sources_are_bounded_to_successful_native_web_results() {
        let mut e=json!({"message":{"role":"toolResult","toolName":"webSearch","details":{"sourceUrls":["https://example.com/a?q=x","javascript:alert(1)","https://secret@example.com/","https://example.com/a?q=x"],"results":[{"url":"https://example.com/a?q=x","title":"Example source"}]}}});
        assert_eq!(sources(&e),vec![json!({"url":"https://example.com/a?q=x","title":"Example source"})]);
        e["message"]["isError"]=json!(true);assert!(sources(&e).is_empty());e["message"]["isError"]=json!(false);e["message"]["toolName"]=json!("bash");assert!(sources(&e).is_empty());
    }
    #[test]
    fn icons_strip_page_paths_queries_and_reject_private_networks() {
        assert_eq!(origin("http://example.com/private?q=secret#fragment").unwrap().as_str(),"https://example.com/");
        for raw in ["file:///tmp/icon","https://user:secret@example.com/","https://example.com:8443/a"] {assert!(origin(raw).is_err());}
        for ip in ["127.0.0.1","10.0.0.1","169.254.169.254","::1"] {assert!(WebPolicy::default().validate("https://example.com/favicon.ico",&[ip.parse().unwrap()]).is_err());}
    }
    #[test]
    fn favicon_decode_returns_only_bounded_png_and_refuses_active_content() {
        use image::{DynamicImage,ImageFormat};use std::io::Cursor;
        for format in [ImageFormat::Png,ImageFormat::Ico] {
            let mut bytes=Cursor::new(Vec::new());DynamicImage::new_rgba8(32,32).write_to(&mut bytes,format).unwrap();
            assert!(crate::image_tools::website_icon(bytes.get_ref()).unwrap().starts_with("data:image/png;base64,"));
        }
        for bad in [b"<svg onload='alert(1)'/>".as_slice(),b"<html>error</html>",b"\x89PNG\r\n\x1a\n"] {assert!(crate::image_tools::website_icon(bad).is_err());}
    }
}
